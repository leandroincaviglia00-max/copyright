/**
 * Turns local decisions into an ordered, resumable list of Spotify writes.
 * Safety ordering: create playlists → ADD to destinations → (verify source
 * snapshot) → REMOVE from source → re-insert kept duplicates. If anything
 * fails midway, songs have been copied before they are ever removed.
 */
import { chunk, uid } from "../lib/async";
import type { ReviewSession, TargetRef } from "./types";

export const LATER_REF = "later";
export const BATCH = 100;

export type StepType = "create" | "add" | "remove" | "readd";
export type StepStatus = "pending" | "done" | "failed" | "uncertain";

export interface ApplyStep {
  id: string;
  type: StepType;
  /** playlist id, or a TargetRef resolved at run time */
  target: TargetRef;
  uris: string[];
  position?: number;
  create?: { name: string; description: string; public: boolean };
  status: StepStatus;
  error?: string;
}

export interface ApplyJournal {
  id: string;
  sessionId: string;
  playlistId: string;
  playlistName: string;
  createdAt: number;
  finishedAt?: number;
  baseSnapshot: string;
  /** snapshot we expect the source to have before the next source write */
  expectedSnapshot: string;
  resolved: Record<TargetRef, string>;
  targetNames: Record<TargetRef, string>;
  steps: ApplyStep[];
  /** For "restore removed songs" */
  removed: { uri: string; name: string; artist: string; position: number }[];
  warnings: string[];
}

export interface PlanSummary {
  removeSongs: number;
  addsByTarget: { target: TargetRef; name: string; count: number }[];
  creates: string[];
  requests: number;
  warnings: string[];
}

export interface PlanContext {
  laterPlaylistId?: string | null;
  playlistNames: Record<string, string>;
}

const isEditableUri = (u: string | null): u is string => !!u && (u.startsWith("spotify:track:") || u.startsWith("spotify:episode:"));

export function planApply(s: ReviewSession, ctx: PlanContext, now = Date.now()): { journal: ApplyJournal; summary: PlanSummary } {
  const steps: ApplyStep[] = [];
  const warnings: string[] = [];
  const targetNames: Record<string, string> = { ...ctx.playlistNames };
  const resolved: Record<string, string> = {};
  if (ctx.laterPlaylistId) resolved[LATER_REF] = ctx.laterPlaylistId;
  targetNames[LATER_REF] = "Sift · Later";

  const adds = new Map<TargetRef, string[]>();
  const removedKeys = new Set<string>();
  let skippedLocal = 0;

  for (const key of s.order) {
    const d = s.decisions[key];
    const e = s.entries[key];
    if (!d || !e || d.kind === "keep") continue;
    if (!isEditableUri(e.uri)) {
      skippedLocal++;
      continue;
    }
    if (d.kind === "remove" || (d.kind === "move" && !d.keepInSource)) removedKeys.add(key);
    if (d.kind === "move") {
      for (const t of d.targets) {
        if (t === s.playlistId) continue;
        const list = adds.get(t) ?? [];
        if (!list.includes(e.uri)) list.push(e.uri);
        adds.set(t, list);
      }
    }
  }
  if (skippedLocal) warnings.push(`${skippedLocal} local file or unsupported item(s) can't be changed through the Spotify API and will be left as they are.`);

  // 1. creates
  const creates: string[] = [];
  for (const t of adds.keys()) {
    if (resolved[t]) continue;
    if (t === LATER_REF) {
      steps.push(step("create", t, [], { create: { name: "Sift · Later", description: "Songs saved for later while sorting with Sift.", public: false } }));
      creates.push("Sift · Later");
    } else if (t.startsWith("new:")) {
      const p = s.pendingPlaylists.find((x) => x.tempId === t);
      if (!p) {
        warnings.push("A destination playlist draft went missing; those songs were skipped.");
        adds.delete(t);
        continue;
      }
      if (p.createdId) resolved[t] = p.createdId;
      else {
        steps.push(step("create", t, [], { create: { name: p.name, description: p.description, public: p.public } }));
        creates.push(p.name);
      }
      targetNames[t] = p.name;
    }
  }

  // 2. additions (non-destructive first)
  for (const [t, uris] of adds) for (const c of chunk(uris, BATCH)) steps.push(step("add", t, c));

  // 3. removals: DELETE removes *every* occurrence of a URI, so partial duplicate removals
  //    are handled by removing the URI then re-inserting the kept copies.
  const occ = new Map<string, string[]>();
  for (const key of s.order) {
    const u = s.entries[key]?.uri;
    if (u) occ.set(u, [...(occ.get(u) ?? []), key]);
  }
  const removeUris: string[] = [];
  const partial = new Set<string>();
  for (const [u, keys] of occ) {
    const r = keys.filter((k) => removedKeys.has(k));
    if (!r.length) continue;
    removeUris.push(u);
    if (r.length < keys.length) partial.add(u);
  }
  for (const c of chunk(removeUris, BATCH)) steps.push(step("remove", s.playlistId, c));

  // 4. re-insert kept copies of partially removed duplicates at their final index
  const finalOrder = s.order.filter((k) => !removedKeys.has(k));
  finalOrder.forEach((k, idx) => {
    const u = s.entries[k].uri;
    if (u && partial.has(u)) steps.push(step("readd", s.playlistId, [u], { position: idx }));
  });

  const removed = [...removedKeys].map((k) => ({ uri: s.entries[k].uri as string, name: s.entries[k].name, artist: s.entries[k].artist, position: s.entries[k].position }));

  const journal: ApplyJournal = {
    id: uid(),
    sessionId: s.id,
    playlistId: s.playlistId,
    playlistName: s.playlistName,
    createdAt: now,
    baseSnapshot: s.snapshotId,
    expectedSnapshot: s.snapshotId,
    resolved,
    targetNames,
    steps,
    removed,
    warnings,
  };
  const summary: PlanSummary = {
    removeSongs: removedKeys.size,
    addsByTarget: [...adds].map(([target, uris]) => ({ target, name: targetNames[target] ?? "Playlist", count: uris.length })),
    creates,
    requests: steps.length,
    warnings,
  };
  return { journal, summary };
}

function step(type: StepType, target: TargetRef, uris: string[], extra: Partial<ApplyStep> = {}): ApplyStep {
  return { id: uid(), type, target, uris, status: "pending", ...extra };
}

/** Build a journal that puts removed songs back (appended, original order). */
export function planRestore(prev: ApplyJournal, now = Date.now()): ApplyJournal {
  const uris = [...prev.removed].sort((a, b) => a.position - b.position).map((r) => r.uri);
  return {
    ...prev,
    id: uid(),
    createdAt: now,
    finishedAt: undefined,
    steps: chunk(uris, BATCH).map((c) => step("add", prev.playlistId, c)),
    removed: [],
    warnings: [],
  };
}

export function isFinished(j: ApplyJournal) {
  return j.steps.every((s) => s.status === "done");
}
