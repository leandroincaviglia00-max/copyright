/**
 * Pure review-session state machine. No I/O: every function returns a new
 * session so it is trivially undoable, persistable and testable.
 */
import { uid } from "../lib/async";
import type { PlaylistEntry } from "../playlists/model";
import type { Counts, Decision, DecisionRecord, EntrySnapshot, HistoryEntry, QueueFilter, ReviewSession } from "./types";

const HISTORY_LIMIT = 5000;

export function snapshotEntries(entries: PlaylistEntry[]): Record<string, EntrySnapshot> {
  const out: Record<string, EntrySnapshot> = {};
  for (const e of entries) out[e.key] = { key: e.key, uri: e.uri, name: e.name, artist: e.artists.map((a) => a.name).join(", "), position: e.position };
  return out;
}

export function createSession(
  p: { id: string; name: string; image: string | null; snapshotId: string },
  entries: PlaylistEntry[],
  now = Date.now(),
): ReviewSession {
  return {
    version: 1,
    id: uid(),
    playlistId: p.id,
    playlistName: p.name,
    playlistImage: p.image,
    snapshotId: p.snapshotId,
    createdAt: now,
    updatedAt: now,
    lastSyncedAt: now,
    order: entries.map((e) => e.key),
    entries: snapshotEntries(entries),
    decisions: {},
    history: [],
    future: [],
    cursorKey: entries[0]?.key ?? null,
    filter: "all",
    lens: null,
    pendingPlaylists: [],
    skips: {},
    status: "reviewing",
  };
}

export function decisionMatches(d: DecisionRecord | undefined, f: QueueFilter): boolean {
  switch (f) {
    case "all":
    case "lens":
      return true;
    case "undecided":
      return !d;
    default:
      return d?.kind === f;
  }
}

export function queue(s: ReviewSession): string[] {
  const base = s.filter === "lens" && s.lens ? s.lens.keys.filter((k) => k in s.entries) : s.order;
  if (s.filter === "all" || s.filter === "lens") return base;
  return base.filter((k) => decisionMatches(s.decisions[k], s.filter));
}

export function current(s: ReviewSession): string | null {
  const q = queue(s);
  if (!q.length) return null;
  if (s.cursorKey && q.includes(s.cursorKey)) return s.cursorKey;
  return q[0];
}

/** The position of the current card in the visible queue (0-based) and its length. */
export function position(s: ReviewSession): { index: number; length: number } {
  const q = queue(s);
  const c = current(s);
  return { index: c ? q.indexOf(c) : q.length, length: q.length };
}

function nextAfter(before: ReviewSession, after: ReviewSession, key: string): string | null {
  const oldQ = queue(before);
  const idx = oldQ.indexOf(key);
  const newQ = queue(after);
  // walk forward from the old position; prefer undecided cards when reviewing "all"
  const tail = oldQ.slice(idx + 1).filter((k) => newQ.includes(k));
  if (after.filter === "all" || after.filter === "lens") {
    const firstUndecided = tail.find((k) => !after.decisions[k]);
    if (firstUndecided) return firstUndecided;
  }
  return tail[0] ?? null;
}

function pushHistory(h: HistoryEntry[], e: HistoryEntry) {
  const out = h.length >= HISTORY_LIMIT ? h.slice(h.length - HISTORY_LIMIT + 1) : h.slice();
  out.push(e);
  return out;
}

export function decide(s: ReviewSession, key: string, d: Decision, now = Date.now()): ReviewSession {
  if (!(key in s.entries)) return s;
  const prev = s.decisions[key] ?? null;
  const next: DecisionRecord = { ...d, at: now } as DecisionRecord;
  const after: ReviewSession = {
    ...s,
    decisions: { ...s.decisions, [key]: next },
    history: pushHistory(s.history, { key, prev, next, at: now }),
    future: [],
    updatedAt: now,
    status: "reviewing",
  };
  return { ...after, cursorKey: nextAfter(s, after, key) };
}

function applyRecord(dec: Record<string, DecisionRecord>, key: string, r: DecisionRecord | null) {
  const out = { ...dec };
  if (r) out[key] = r;
  else delete out[key];
  return out;
}

export function canUndo(s: ReviewSession) {
  return s.history.length > 0;
}
export function canRedo(s: ReviewSession) {
  return s.future.length > 0;
}

export function undo(s: ReviewSession, now = Date.now()): ReviewSession {
  const last = s.history[s.history.length - 1];
  if (!last) return s;
  return {
    ...s,
    decisions: applyRecord(s.decisions, last.key, last.prev),
    history: s.history.slice(0, -1),
    future: [...s.future, last],
    cursorKey: last.key,
    // make sure the undone card is visible even if the filter would hide it
    filter: decisionMatches(last.prev ?? undefined, s.filter) ? s.filter : "all",
    updatedAt: now,
  };
}

export function redo(s: ReviewSession, now = Date.now()): ReviewSession {
  const e = s.future[s.future.length - 1];
  if (!e) return s;
  const after: ReviewSession = {
    ...s,
    decisions: applyRecord(s.decisions, e.key, e.next),
    history: [...s.history, e],
    future: s.future.slice(0, -1),
    updatedAt: now,
  };
  return { ...after, cursorKey: nextAfter(s, after, e.key) };
}

export function skip(s: ReviewSession, key: string, now = Date.now()): ReviewSession {
  const q = queue(s);
  const i = q.indexOf(key);
  const next = q[i + 1] ?? q[0] ?? null;
  return { ...s, skips: { ...s.skips, [key]: (s.skips[key] ?? 0) + 1 }, cursorKey: next, updatedAt: now };
}

export function goTo(s: ReviewSession, key: string): ReviewSession {
  return key in s.entries ? { ...s, cursorKey: key } : s;
}

export function jumpToUndecided(s: ReviewSession): ReviewSession {
  const q = queue(s);
  const c = current(s);
  const from = c ? q.indexOf(c) : 0;
  const found = [...q.slice(from), ...q.slice(0, from)].find((k) => !s.decisions[k]);
  if (found) return { ...s, cursorKey: found };
  const any = s.order.find((k) => !s.decisions[k]);
  return any ? { ...s, filter: "all", lens: null, cursorKey: any } : s;
}

export function setFilter(s: ReviewSession, filter: QueueFilter, lens: ReviewSession["lens"] = null): ReviewSession {
  const next: ReviewSession = { ...s, filter, lens: filter === "lens" ? lens : null };
  const q = queue(next);
  return { ...next, cursorKey: q.find((k) => !next.decisions[k]) ?? q[0] ?? null };
}

export function restart(s: ReviewSession, now = Date.now()): ReviewSession {
  return { ...s, decisions: {}, history: [], future: [], filter: "all", lens: null, cursorKey: s.order[0] ?? null, updatedAt: now, status: "reviewing" };
}

export function counts(s: ReviewSession): Counts {
  const c: Counts = { total: s.order.length, keep: 0, remove: 0, move: 0, undecided: 0, byTarget: {} };
  for (const k of s.order) {
    const d = s.decisions[k];
    if (!d) c.undecided++;
    else if (d.kind === "move") {
      c.move++;
      for (const t of d.targets) c.byTarget[t] = (c.byTarget[t] ?? 0) + 1;
    } else c[d.kind]++;
  }
  return c;
}

/** Decisions per minute, measured on bursts (gaps > 2 min are treated as breaks). */
export function reviewPace(s: ReviewSession): number | null {
  const ts = s.history.map((h) => h.at).sort((a, b) => a - b);
  if (ts.length < 5) return null;
  let active = 0;
  let intervals = 0;
  for (let i = 1; i < ts.length; i++) {
    const gap = ts[i] - ts[i - 1];
    if (gap <= 120_000) {
      active += gap;
      intervals++;
    }
  }
  return active > 0 && intervals >= 3 ? intervals / (active / 60_000) : null;
}
