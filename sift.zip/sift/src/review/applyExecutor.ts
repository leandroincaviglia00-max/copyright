import type { PlaylistService } from "../playlists/playlistService";
import type { SpotifyApi } from "../spotify/api/endpoints";
import { SpotifyApiError, describeApiError } from "../spotify/api/errors";
import type { ApplyJournal, ApplyStep } from "./applyPlanner";

export type RunResult =
  | { status: "done"; journal: ApplyJournal }
  | { status: "conflict"; journal: ApplyJournal; remoteSnapshot: string }
  | { status: "paused"; journal: ApplyJournal; error: SpotifyApiError | Error; message: string };

export interface ExecutorDeps {
  api: SpotifyApi;
  playlists: Pick<PlaylistService, "uris">;
  /** Persist after every step so a refresh/crash can resume safely. */
  persist: (j: ApplyJournal) => Promise<void> | void;
  onProgress?: (done: number, total: number, step: ApplyStep) => void;
  /** Called when a `create` step resolves a new playlist. */
  onCreated?: (tempRef: string, playlistId: string) => void;
}

export interface RunOptions {
  signal?: AbortSignal;
  /** Don't add songs that are already in the destination. Default true. */
  skipExisting?: boolean;
  /** User explicitly chose to continue despite an external change. */
  acceptSnapshot?: string;
}

export async function runJournal(input: ApplyJournal, deps: ExecutorDeps, opts: RunOptions = {}): Promise<RunResult> {
  let j: ApplyJournal = structuredClone(input);
  if (opts.acceptSnapshot) j.expectedSnapshot = opts.acceptSnapshot;
  const skipExisting = opts.skipExisting ?? true;
  const existing = new Map<string, Set<string>>();
  const total = j.steps.length;
  let sourceChecked = false;

  const save = async (next: ApplyJournal) => {
    j = next;
    await deps.persist(j);
  };
  const patch = (id: string, p: Partial<ApplyStep>) => ({ ...j, steps: j.steps.map((s) => (s.id === id ? { ...s, ...p } : s)) });
  const resolve = (t: string) => j.resolved[t] ?? (t.startsWith("new:") || t === "later" ? null : t);

  for (const st of j.steps) {
    if (st.status === "done") continue;
    if (opts.signal?.aborted) return paused(new Error("Cancelled"), "Apply paused. Nothing is lost; resume any time.");
    try {
      if (st.type === "create") {
        const created = await deps.api.createPlaylist(st.create!);
        await save({ ...patch(st.id, { status: "done" }), resolved: { ...j.resolved, [st.target]: created.id } });
        deps.onCreated?.(st.target, created.id);
        existing.set(created.id, new Set());
      } else if (st.type === "add") {
        const target = resolve(st.target);
        if (!target) throw new Error("Destination playlist was never created.");
        let uris = st.uris;
        if (skipExisting || st.status === "uncertain") {
          if (!existing.has(target)) existing.set(target, await deps.playlists.uris(target, opts.signal));
          const have = existing.get(target)!;
          uris = uris.filter((u) => !have.has(u));
        }
        if (uris.length) {
          const res = await deps.api.addItems(target, uris, st.position);
          uris.forEach((u) => existing.get(target)?.add(u));
          if (target === j.playlistId) j = { ...j, expectedSnapshot: res.snapshot_id };
        }
        await save(patch(st.id, { status: "done", error: undefined }));
      } else {
        // remove / readd touch the SOURCE playlist → check for external edits first
        if (!sourceChecked) {
          const meta = await deps.api.playlistMeta(j.playlistId, opts.signal);
          if (meta.snapshot_id !== j.expectedSnapshot) {
            return { status: "conflict", journal: j, remoteSnapshot: meta.snapshot_id };
          }
          sourceChecked = true;
        }
        if (st.type === "readd" && st.status === "uncertain") {
          const have = await deps.playlists.uris(j.playlistId, opts.signal);
          if (st.uris.every((u) => have.has(u))) {
            const m = await deps.api.playlistMeta(j.playlistId, opts.signal);
            await save({ ...patch(st.id, { status: "done", error: undefined }), expectedSnapshot: m.snapshot_id });
            continue;
          }
        }
        const res =
          st.type === "remove"
            ? await deps.api.removeItems(j.playlistId, st.uris, j.expectedSnapshot)
            : await deps.api.addItems(j.playlistId, st.uris, st.position);
        await save({ ...patch(st.id, { status: "done", error: undefined }), expectedSnapshot: res.snapshot_id });
      }
      deps.onProgress?.(j.steps.filter((s) => s.status === "done").length, total, st);
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      // A failed POST may or may not have landed; verify before retrying.
      const uncertain = st.type !== "remove" && err instanceof SpotifyApiError && (err.kind === "network" || err.kind === "server");
      await save(patch(st.id, { status: uncertain ? "uncertain" : "failed", error: err.message }));
      if (err instanceof SpotifyApiError && err.kind === "conflict") {
        const meta = await deps.api.playlistMeta(j.playlistId).catch(() => null);
        return { status: "conflict", journal: j, remoteSnapshot: meta?.snapshot_id ?? "" };
      }
      return paused(err, describeApiError(err, st.type === "create" ? "creating a playlist" : "updating the playlist"));
    }
  }
  await save({ ...j, finishedAt: Date.now() });
  return { status: "done", journal: j };

  function paused(error: Error, message: string): RunResult {
    return { status: "paused", journal: j, error, message };
  }
}
