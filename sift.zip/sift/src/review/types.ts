/** 'later' = the user's private "Sift · Later" crate; 'new:<id>' = playlist created at apply time. */
export type TargetRef = string;

export type Decision =
  | { kind: "keep" }
  | { kind: "remove" }
  | { kind: "move"; targets: TargetRef[]; keepInSource: boolean };

export type DecisionRecord = Decision & { at: number };

export interface HistoryEntry {
  key: string;
  prev: DecisionRecord | null;
  next: DecisionRecord | null;
  at: number;
}

export type QueueFilter = "all" | "undecided" | "keep" | "remove" | "move" | "lens";

export interface PendingPlaylist {
  tempId: TargetRef; // "new:xyz"
  name: string;
  description: string;
  public: boolean;
  /** Filled in once it exists on Spotify. */
  createdId?: string;
}

export interface EntrySnapshot {
  key: string;
  uri: string | null;
  name: string;
  artist: string;
  position: number;
}

export interface ReviewSession {
  version: 1;
  id: string;
  playlistId: string;
  playlistName: string;
  playlistImage: string | null;
  snapshotId: string;
  createdAt: number;
  updatedAt: number;
  lastSyncedAt: number;
  order: string[];
  /** light copy of entries so a session is readable/exportable without the cache */
  entries: Record<string, EntrySnapshot>;
  decisions: Record<string, DecisionRecord>;
  history: HistoryEntry[];
  future: HistoryEntry[];
  cursorKey: string | null;
  filter: QueueFilter;
  lens: { id: string; label: string; keys: string[] } | null;
  pendingPlaylists: PendingPlaylist[];
  skips: Record<string, number>;
  status: "reviewing" | "applying" | "applied";
}

export interface Counts {
  total: number;
  keep: number;
  remove: number;
  move: number;
  undecided: number;
  byTarget: Record<TargetRef, number>;
}
