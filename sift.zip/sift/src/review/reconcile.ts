import type { PlaylistEntry } from "../playlists/model";
import { snapshotEntries } from "./reviewEngine";
import type { EntrySnapshot, ReviewSession } from "./types";

export interface ReconcileReport {
  changed: boolean;
  addedExternally: EntrySnapshot[];
  removedExternally: EntrySnapshot[];
  /** decisions that pointed at songs no longer in the playlist */
  droppedDecisions: { entry: EntrySnapshot; kind: string }[];
}

/**
 * Merge a fresh copy of the playlist into a session without losing any
 * decision that still applies. Keys are `${uri}::${occurrence}` so reorders
 * made elsewhere don't disturb decisions.
 */
export function reconcile(s: ReviewSession, fresh: PlaylistEntry[], snapshotId: string, now = Date.now()): { session: ReviewSession; report: ReconcileReport } {
  const nextEntries = snapshotEntries(fresh);
  const oldKeys = new Set(s.order);
  const newKeys = new Set(fresh.map((e) => e.key));
  const addedExternally = fresh.filter((e) => !oldKeys.has(e.key)).map((e) => nextEntries[e.key]);
  const removedExternally = s.order.filter((k) => !newKeys.has(k)).map((k) => s.entries[k]);
  const droppedDecisions = removedExternally.filter((e) => s.decisions[e.key]).map((e) => ({ entry: e, kind: s.decisions[e.key].kind }));

  const decisions = { ...s.decisions };
  for (const k of Object.keys(decisions)) if (!newKeys.has(k)) delete decisions[k];
  const keep = (k: string) => newKeys.has(k);

  const session: ReviewSession = {
    ...s,
    snapshotId,
    order: fresh.map((e) => e.key),
    entries: nextEntries,
    decisions,
    history: s.history.filter((h) => keep(h.key)),
    future: s.future.filter((h) => keep(h.key)),
    lens: s.lens ? { ...s.lens, keys: s.lens.keys.filter(keep) } : null,
    cursorKey: s.cursorKey && keep(s.cursorKey) ? s.cursorKey : (fresh.find((e) => !decisions[e.key])?.key ?? null),
    lastSyncedAt: now,
    updatedAt: now,
  };
  return {
    session,
    report: { changed: addedExternally.length > 0 || removedExternally.length > 0 || snapshotId !== s.snapshotId, addedExternally, removedExternally, droppedDecisions },
  };
}
