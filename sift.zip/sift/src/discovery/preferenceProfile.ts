import { decadeOf } from "../lib/format";
import type { Candidate, Verdict } from "./types";

interface Tally {
  like: number;
  reject: number;
}
export interface PreferenceProfile {
  version: 1;
  artists: Record<string, Tally & { name: string; kept: number; removed: number }>;
  genres: Record<string, Tally>;
  decades: Record<string, Tally>;
  /** discovery verdict per track uri */
  seen: Record<string, Exclude<Verdict, "skip">>;
  skips: Record<string, number>;
  totals: { shown: number; like: number; reject: number; later: number; skip: number };
  /** which playlists liked songs were added to */
  destinations: Record<string, number>;
}

export const emptyProfile = (): PreferenceProfile => ({
  version: 1,
  artists: {},
  genres: {},
  decades: {},
  seen: {},
  skips: {},
  totals: { shown: 0, like: 0, reject: 0, later: 0, skip: 0 },
  destinations: {},
});

const bump = (t: Tally | undefined, v: "like" | "reject"): Tally => ({ like: (t?.like ?? 0) + (v === "like" ? 1 : 0), reject: (t?.reject ?? 0) + (v === "reject" ? 1 : 0) });

export function recordDiscovery(p: PreferenceProfile, c: Candidate, v: Verdict): PreferenceProfile {
  const next: PreferenceProfile = structuredClone(p);
  next.totals.shown++;
  next.totals[v]++;
  if (v === "skip") {
    next.skips[c.uri] = (next.skips[c.uri] ?? 0) + 1;
    return next;
  }
  next.seen[c.uri] = v;
  const polarity = v === "reject" ? "reject" : "like"; // "later" counts as mild interest
  for (const a of c.artists) {
    if (!a.id) continue;
    const cur = next.artists[a.id] ?? { name: a.name, like: 0, reject: 0, kept: 0, removed: 0 };
    next.artists[a.id] = { ...cur, ...bump(cur, polarity) };
  }
  for (const g of c.genres ?? []) next.genres[g] = bump(next.genres[g], polarity);
  const d = decadeOf(c.album.year);
  if (d) next.decades[d] = bump(next.decades[d], polarity);
  return next;
}

/** Review swipes also teach the profile (kept vs removed artists). */
export function recordReview(p: PreferenceProfile, artists: { id: string | null; name: string }[], kind: "keep" | "remove" | "move", genresByArtist: Record<string, string[]> = {}): PreferenceProfile {
  const next: PreferenceProfile = structuredClone(p);
  for (const a of artists) {
    if (!a.id) continue;
    const cur = next.artists[a.id] ?? { name: a.name, like: 0, reject: 0, kept: 0, removed: 0 };
    if (kind === "remove") cur.removed++;
    else cur.kept++;
    next.artists[a.id] = cur;
    for (const g of genresByArtist[a.id] ?? []) next.genres[g] = bump(next.genres[g], kind === "remove" ? "reject" : "like");
  }
  return next;
}

/** -1..1 affinity from explicit feedback only. */
export function artistAffinity(p: PreferenceProfile, id: string | null) {
  if (!id) return 0;
  const a = p.artists[id];
  if (!a) return 0;
  const pos = a.like + a.kept * 0.5;
  const neg = a.reject + a.removed * 0.75;
  return (pos - neg) / (pos + neg + 1);
}
export function tallyAffinity(t?: Tally) {
  if (!t) return 0;
  return (t.like - t.reject) / (t.like + t.reject + 1);
}
