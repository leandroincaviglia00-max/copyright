import type { PlaylistEntry } from "../playlists/model";
import { buildDna } from "./dna";
import { recordDiscovery, type PreferenceProfile } from "./preferenceProfile";
import { rankAll } from "./ranker";
import type { MetadataSource } from "./sources/types";
import type { Candidate, MusicDNA, Ranked, Verdict } from "./types";

const LOW_WATER = 6;

/** Orchestrates DNA → candidates → ranking → feedback. UI-agnostic. */
export class DiscoveryEngine {
  dna: MusicDNA | null = null;
  private pool: Candidate[] = [];
  private queue: Ranked[] = [];
  private exclude = new Set<string>();
  private round = 0;
  private filling: Promise<void> | null = null;
  exhausted = false;

  constructor(private sources: MetadataSource[], public profile: PreferenceProfile) {}

  async analyze(p: { id: string; name: string }, entries: PlaylistEntry[], signal?: AbortSignal): Promise<MusicDNA> {
    const tracks = entries.filter((e) => e.kind === "track");
    tracks.forEach((t) => t.uri && this.exclude.add(t.uri));
    const counts = new Map<string, { id: string; name: string; n: number }>();
    for (const t of tracks) for (const a of t.artists) if (a.id) counts.set(a.id, { id: a.id, name: a.name, n: (counts.get(a.id)?.n ?? 0) + 1 });
    const top = [...counts.values()].sort((a, b) => b.n - a.n).slice(0, 25);
    const tags: Record<string, string[]> = {};
    for (const s of this.sources) {
      if (!s.artistTags) continue;
      const t = await s.artistTags(top, signal);
      for (const [id, g] of Object.entries(t)) tags[id] = Array.from(new Set([...(tags[id] ?? []), ...g]));
    }
    this.genreByArtist = tags;
    this.dna = buildDna(p, entries, tags);
    return this.dna;
  }

  genreByArtist: Record<string, string[]> = {};

  peek(n = 3): Ranked[] {
    return this.queue.slice(0, n);
  }

  async fill(signal?: AbortSignal) {
    if (!this.dna) throw new Error("analyze() first");
    if (this.filling) return this.filling;
    this.filling = (async () => {
      for (let tries = 0; tries < 3 && this.queue.length < LOW_WATER * 2; tries++) {
        const found: Candidate[] = [];
        for (const s of this.sources) {
          try {
            found.push(...(await s.candidates({ dna: this.dna!, profile: this.profile, exclude: this.exclude, round: this.round, signal })));
          } catch {
            /* a single failing source must not kill discovery */
          }
        }
        this.round++;
        // attach genres for primary artists where we have them; fetch a few more
        const need = found.map((c) => c.artists[0]).filter((a) => a?.id && !(a.id in this.genreByArtist)).slice(0, 8) as { id: string; name: string }[];
        for (const s of this.sources) if (s.artistTags && need.length) Object.assign(this.genreByArtist, await s.artistTags(need, signal).catch(() => ({})));
        for (const c of found) {
          const g = c.artists[0]?.id ? this.genreByArtist[c.artists[0].id] : undefined;
          if (g?.length) c.genres = g;
        }
        const known = new Set(this.pool.map((c) => c.uri));
        this.pool.push(...found.filter((c) => !known.has(c.uri)));
        this.rerank();
        if (!found.length && tries === 2) this.exhausted = true;
      }
    })().finally(() => (this.filling = null));
    return this.filling;
  }

  rerank() {
    if (!this.dna) return;
    const inQueue = rankAll(this.pool, this.dna, this.profile, this.exclude);
    this.queue = inQueue;
  }

  /** Record a verdict, adapt ranking, top up in the background. */
  decide(c: Candidate, v: Verdict): PreferenceProfile {
    this.profile = recordDiscovery(this.profile, c, v);
    if (v !== "skip") {
      this.exclude.add(c.uri);
      this.pool = this.pool.filter((x) => x.uri !== c.uri);
    } else {
      // move skipped to the back
      this.pool = [...this.pool.filter((x) => x.uri !== c.uri), c];
    }
    this.rerank();
    if (v === "skip") this.queue = [...this.queue.filter((r) => r.candidate.uri !== c.uri), ...this.queue.filter((r) => r.candidate.uri === c.uri)];
    if (this.queue.length < LOW_WATER) void this.fill();
    return this.profile;
  }

  /** Put a candidate back (undo). */
  restore(c: Candidate, prev: PreferenceProfile) {
    this.profile = prev;
    this.exclude.delete(c.uri);
    if (!this.pool.some((x) => x.uri === c.uri)) this.pool.unshift(c);
    this.rerank();
    this.queue = [...this.queue.filter((r) => r.candidate.uri === c.uri), ...this.queue.filter((r) => r.candidate.uri !== c.uri)];
  }
}
