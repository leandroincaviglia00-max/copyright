import type { Candidate, MusicDNA } from "../types";
import type { PreferenceProfile } from "../preferenceProfile";

/**
 * Pluggable metadata/candidate sources. Spotify catalog is the only one
 * shipped; others (e.g. MusicBrainz tags, Last.fm similar artists) can be
 * added by implementing this interface, subject to their own terms.
 */
export interface MetadataSource {
  id: string;
  label: string;
  /** optional: extra tags per Spotify artist id */
  artistTags?(artistIds: { id: string; name: string }[], signal?: AbortSignal): Promise<Record<string, string[]>>;
  candidates(ctx: SourceContext): Promise<Candidate[]>;
}

export interface SourceContext {
  dna: MusicDNA;
  profile: PreferenceProfile;
  exclude: Set<string>;
  round: number;
  signal?: AbortSignal;
  random?: () => number;
}
