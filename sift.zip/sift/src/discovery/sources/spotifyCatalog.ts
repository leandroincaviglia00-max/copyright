import { mapLimit } from "../../lib/async";
import { pickImage } from "../../playlists/model";
import type { KV } from "../../persistence/kv";
import type { SpotifyApi } from "../../spotify/api/endpoints";
import type { SpAlbumRef, SpTrack } from "../../spotify/api/types";
import { artistAffinity } from "../preferenceProfile";
import type { Candidate, CandidateSource } from "../types";
import type { MetadataSource, SourceContext } from "./types";

const DAY = 86_400_000;
const yearOf = (d?: string | null) => (d && /^\d{4}/.test(d) ? Number(d.slice(0, 4)) : null);

export function trackToCandidate(t: SpTrack | (Omit<SpTrack, "album"> & { album?: SpAlbumRef }), source: CandidateSource, seed: Candidate["seed"], albumOverride?: SpAlbumRef): Candidate | null {
  if (!t?.id || !t.uri || t.is_playable === false) return null;
  const album = albumOverride ?? (t as SpTrack).album;
  return {
    uri: t.uri,
    id: t.id,
    name: t.name,
    artists: (t.artists ?? []).map((a) => ({ id: a.id, name: a.name, url: a.external_urls?.spotify })),
    album: {
      name: album?.name ?? "",
      image: pickImage(album?.images, 600),
      releaseDate: album?.release_date ?? null,
      year: yearOf(album?.release_date),
      url: album?.external_urls?.spotify,
    },
    durationMs: t.duration_ms,
    previewUrl: t.preview_url ?? null,
    url: t.external_urls?.spotify,
    source,
    seed,
  };
}

/** Uses only current, non-deprecated catalog endpoints: search, artist, artist albums, album tracks. */
export class SpotifyCatalogSource implements MetadataSource {
  id = "spotify";
  label = "Spotify catalog";
  constructor(private api: SpotifyApi, private kv: KV, private hasHistory: () => boolean) {}

  /** GET /artists/{id} one by one (batch endpoint removed). Cached 7 days. */
  async artistTags(artists: { id: string; name: string }[], signal?: AbortSignal) {
    const out: Record<string, string[]> = {};
    await mapLimit(artists, 3, async (a) => {
      const key = `cache.artist.${a.id}`;
      const hit = await this.kv.get<{ at: number; genres: string[] }>(key);
      if (hit && Date.now() - hit.at < 7 * DAY) {
        out[a.id] = hit.genres;
        return;
      }
      try {
        const full = await this.api.artist(a.id, signal);
        out[a.id] = full.genres ?? [];
        await this.kv.set(key, { at: Date.now(), genres: out[a.id] });
      } catch {
        out[a.id] = [];
      }
    });
    return out;
  }

  async candidates(ctx: SourceContext): Promise<Candidate[]> {
    const rnd = ctx.random ?? Math.random;
    const { dna, profile } = ctx;
    // seed artists: playlist heavyweights, boosted by what the user said yes to
    const seeds = dna.artists
      .map((a) => ({ ...a, w: a.count * (1 + artistAffinity(profile, a.id)) }))
      .filter((a) => artistAffinity(profile, a.id) > -0.5)
      .sort((a, b) => b.w - a.w);
    const liked = Object.entries(profile.artists)
      .filter(([, v]) => v.like > 0)
      .map(([id, v]) => ({ id, name: v.name, count: 0, w: v.like * 2 }));
    const pool = [...seeds.slice(0, 12), ...liked.slice(0, 6)];
    const pick = <T,>(arr: T[], n: number) => [...arr].sort(() => rnd() - 0.5).slice(0, n);
    const chosen = pick(pool.slice(0, 10 + ctx.round * 2), 3);

    const jobs: Promise<Candidate[]>[] = [];
    for (const a of chosen) {
      jobs.push(this.deepCuts(a.id, a.name, ctx));
      jobs.push(this.collabs(a.id, a.name, ctx));
    }
    const genres = dna.genres.slice(0, 6);
    if (genres.length) {
      const g = genres[Math.floor(rnd() * genres.length)].name;
      jobs.push(this.search(`genre:"${g}"`, "genre", { genre: g }, Math.floor(rnd() * 4) * 10, ctx));
      const topDecade = [...dna.decades].sort((a, b) => b.count - a.count)[0];
      if (topDecade) {
        const y = Number(topDecade.decade.slice(0, 4));
        jobs.push(this.search(`genre:"${g}" year:${y}-${y + 9}`, "era_genre", { genre: g, decade: topDecade.decade }, 0, ctx));
      }
    }
    if (this.hasHistory() && ctx.round === 0) jobs.push(this.topTracks(ctx));
    const results = await Promise.allSettled(jobs);
    const seen = new Set<string>();
    const out: Candidate[] = [];
    for (const r of results)
      if (r.status === "fulfilled")
        for (const c of r.value)
          if (!seen.has(c.uri) && !ctx.exclude.has(c.uri)) {
            seen.add(c.uri);
            out.push(c);
          }
    return out;
  }

  private async deepCuts(artistId: string, artistName: string, ctx: SourceContext) {
    const rnd = ctx.random ?? Math.random;
    const albums = await this.api.artistAlbums(artistId, 0, ctx.signal);
    const picks = [...albums.items].sort(() => rnd() - 0.5).slice(0, 2);
    const out: Candidate[] = [];
    for (const al of picks) {
      if (!al.id) continue;
      const tracks = await this.api.albumTracks(al.id, ctx.signal);
      const fresh = tracks.items.filter((t) => !ctx.exclude.has(t.uri)).sort(() => rnd() - 0.5).slice(0, 2);
      for (const t of fresh) {
        const c = trackToCandidate(t, "deep_cut", { artistId, artistName }, al);
        if (c) out.push(c);
      }
    }
    return out;
  }

  private async collabs(artistId: string, artistName: string, ctx: SourceContext) {
    const res = await this.api.searchTracks(`artist:"${artistName}"`, Math.floor((ctx.random ?? Math.random)() * 3) * 10, ctx.signal);
    const inDna = new Set(ctx.dna.artists.map((a) => a.id));
    return res.tracks.items
      .filter((t) => t.artists.some((a) => a.id === artistId) && t.artists.some((a) => a.id && !inDna.has(a.id)))
      .map((t) => trackToCandidate(t, "collab", { artistId, artistName }))
      .filter(Boolean) as Candidate[];
  }

  private async search(q: string, source: CandidateSource, seed: Candidate["seed"], offset: number, ctx: SourceContext) {
    const res = await this.api.searchTracks(q, offset, ctx.signal);
    return res.tracks.items.map((t) => trackToCandidate(t, source, seed)).filter(Boolean) as Candidate[];
  }

  private async topTracks(ctx: SourceContext) {
    const res = await this.api.topTracks("medium_term", ctx.signal);
    return res.items.map((t) => trackToCandidate(t, "top_tracks", {})).filter(Boolean) as Candidate[];
  }
}
