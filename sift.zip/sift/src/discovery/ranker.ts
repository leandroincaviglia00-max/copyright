/**
 * Transparent, rule-based ranking. Every point of score comes from a named,
 * user-visible reason; there is no opaque model and no similarity %.
 */
import { decadeOf } from "../lib/format";
import { artistAffinity, tallyAffinity, type PreferenceProfile } from "./preferenceProfile";
import type { Candidate, MusicDNA, Ranked, Reason } from "./types";

export function rank(c: Candidate, dna: MusicDNA, p: PreferenceProfile): Ranked {
  const reasons: Reason[] = [];
  const inPlaylist = new Map(dna.artists.map((a) => [a.id, a]));
  const primary = c.artists[0];

  // 1. artist presence in the reference playlist
  const known = c.artists.map((a) => (a.id ? inPlaylist.get(a.id) : undefined)).filter(Boolean) as MusicDNA["artists"];
  if (known.length) {
    const top = known.sort((a, b) => b.count - a.count)[0];
    const w = Math.min(3, 1 + Math.log2(1 + top.count) * 0.6);
    reasons.push({ code: "artist_in_playlist", text: `${top.name} has ${top.count} song${top.count === 1 ? "" : "s"} in ${dna.playlistName}`, weight: w });
  } else {
    reasons.push({ code: "new_artist", text: "An artist you don't have here yet", weight: 0.4 });
  }

  // 2. collaboration bridge
  if (c.source === "collab" && c.seed.artistName) {
    const other = c.artists.find((a) => a.id !== c.seed.artistId && !(a.id && inPlaylist.has(a.id)));
    if (other) reasons.push({ code: "collab_bridge", text: `${other.name} alongside ${c.seed.artistName}`, weight: 1.2 });
  }

  // 3. genre overlap (only when Spotify supplied genres)
  if (c.genres?.length && dna.genres.length) {
    const dnaG = new Map(dna.genres.map((g) => [g.name, g.weight]));
    const shared = c.genres.filter((g) => dnaG.has(g));
    if (shared.length) {
      const maxW = dna.genres[0].weight || 1;
      const w = Math.min(2.5, shared.reduce((s, g) => s + (dnaG.get(g)! / maxW), 0) * 1.5);
      reasons.push({ code: "genre_overlap", text: `Shares ${shared.slice(0, 2).join(" & ")} with this playlist`, weight: w });
    }
  } else if (c.seed.genre) {
    reasons.push({ code: "genre_overlap", text: `Tagged ${c.seed.genre}, a thread in this playlist`, weight: 1 });
  }

  // 4. era fit
  const d = decadeOf(c.album.year);
  if (d && dna.size) {
    const hit = dna.decades.find((x) => x.decade === d);
    if (hit && hit.count / dna.size >= 0.15) reasons.push({ code: "era_fit", text: `From the ${d}, where ${Math.round((hit.count / dna.size) * 100)}% of this playlist lives`, weight: 0.8 * (hit.count / dna.size) * 3 });
  }

  // 5. explicit feedback
  const aff = Math.max(...c.artists.map((a) => artistAffinity(p, a.id)), -1);
  if (aff > 0.2) reasons.push({ code: "artist_liked", text: `You've been saying yes to ${primary.name}`, weight: 2 * aff });
  let penalty = 0;
  if (aff < -0.2) penalty += 3 * -aff;
  const gAff = (c.genres ?? []).map((g) => tallyAffinity(p.genres[g]));
  const gBest = gAff.length ? Math.max(...gAff) : 0;
  const gWorst = gAff.length ? Math.min(...gAff) : 0;
  if (gBest > 0.3) reasons.push({ code: "genre_liked", text: `More ${c.genres![gAff.indexOf(gBest)]}, which you keep liking`, weight: gBest * 1.5 });
  if (gWorst < -0.3) penalty += -gWorst * 1.5;
  if (d) penalty += Math.max(0, -tallyAffinity(p.decades[d])) * 1;
  penalty += (p.skips[c.uri] ?? 0) * 0.8;

  if (c.source === "top_tracks") reasons.push({ code: "top_listen", text: "One of your most-played songs, not in this playlist", weight: 1.5 });

  const score = reasons.reduce((s, r) => s + r.weight, 0) - penalty;
  const strong = reasons.filter((r) => r.code !== "new_artist" && r.weight >= 1).length;
  const tier: Ranked["tier"] = known.length && strong >= 2 ? "Close to home" : strong >= 1 ? "Next door" : "Wildcard";
  return { candidate: c, score, reasons: reasons.sort((a, b) => b.weight - a.weight), tier };
}

/** Rank, then interleave so one seed artist can't flood the queue. */
export function rankAll(cs: Candidate[], dna: MusicDNA, p: PreferenceProfile, exclude: Set<string>): Ranked[] {
  const ranked = cs.filter((c) => !exclude.has(c.uri) && !p.seen[c.uri]).map((c) => rank(c, dna, p));
  ranked.sort((a, b) => b.score - a.score);
  const out: Ranked[] = [];
  const perArtist = new Map<string, number>();
  const deferred: Ranked[] = [];
  for (const r of ranked) {
    const k = r.candidate.artists[0]?.id ?? r.candidate.artists[0]?.name ?? "?";
    const n = perArtist.get(k) ?? 0;
    if (n >= 2) deferred.push(r);
    else {
      perArtist.set(k, n + 1);
      out.push(r);
    }
  }
  return [...out, ...deferred];
}
