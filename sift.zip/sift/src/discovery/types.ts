import type { ArtistLite } from "../playlists/model";

export type CandidateSource = "deep_cut" | "collab" | "genre" | "era_genre" | "top_tracks";

export interface Candidate {
  uri: string;
  id: string;
  name: string;
  artists: ArtistLite[];
  album: { name: string; image: string | null; releaseDate: string | null; year: number | null; url?: string };
  durationMs: number;
  previewUrl: string | null;
  url?: string;
  source: CandidateSource;
  /** what produced it: the seed artist/genre/era */
  seed: { artistId?: string; artistName?: string; genre?: string; decade?: string };
  /** primary-artist genres when Spotify provides them (deprecated field; often empty) */
  genres?: string[];
}

export interface MusicDNA {
  playlistId: string;
  playlistName: string;
  size: number;
  artists: { id: string; name: string; count: number }[];
  albums: { id: string; name: string; count: number }[];
  decades: { decade: string; count: number }[];
  genres: { name: string; weight: number }[];
  clusters: { label: string; artists: string[] }[];
  /** share of top artists we actually got genre data for (0..1) */
  genreCoverage: number;
  explicitShare: number;
  medianDurationMs: number;
  builtAt: number;
}

export type Verdict = "like" | "reject" | "later" | "skip";

export interface Reason {
  code: "artist_in_playlist" | "artist_liked" | "collab_bridge" | "genre_overlap" | "era_fit" | "genre_liked" | "top_listen" | "new_artist";
  text: string;
  weight: number;
}

export interface Ranked {
  candidate: Candidate;
  score: number;
  reasons: Reason[];
  /** plain-language tier derived from which signals fired; never a fake % */
  tier: "Close to home" | "Next door" | "Wildcard";
}
