import { decadeOf } from "../lib/format";
import type { PlaylistEntry } from "../playlists/model";
import type { MusicDNA } from "./types";

/**
 * Build a Music DNA from metadata we are allowed to use: artists, albums,
 * release dates, explicit flag, durations, and (where Spotify still returns
 * them) artist genres. No audio features, no ML training.
 */
export function buildDna(
  p: { id: string; name: string },
  entries: PlaylistEntry[],
  artistGenres: Record<string, string[]>,
  now = Date.now(),
): MusicDNA {
  const tracks = entries.filter((e) => e.kind === "track");
  const artistCount = new Map<string, { id: string; name: string; count: number }>();
  const albumCount = new Map<string, { id: string; name: string; count: number }>();
  const decades = new Map<string, number>();
  let explicit = 0;
  for (const t of tracks) {
    for (const a of t.artists) {
      if (!a.id) continue;
      const x = artistCount.get(a.id) ?? { id: a.id, name: a.name, count: 0 };
      x.count++;
      artistCount.set(a.id, x);
    }
    if (t.albumId) {
      const x = albumCount.get(t.albumId) ?? { id: t.albumId, name: t.albumName, count: 0 };
      x.count++;
      albumCount.set(t.albumId, x);
    }
    const d = decadeOf(t.releaseYear);
    if (d) decades.set(d, (decades.get(d) ?? 0) + 1);
    if (t.explicit) explicit++;
  }
  const artists = [...artistCount.values()].sort((a, b) => b.count - a.count);

  // genres weighted by how many songs each artist contributes
  const genreW = new Map<string, number>();
  let covered = 0;
  const topForCoverage = artists.slice(0, 30);
  for (const a of topForCoverage) {
    const gs = artistGenres[a.id];
    if (gs?.length) covered++;
    for (const g of gs ?? []) genreW.set(g, (genreW.get(g) ?? 0) + a.count);
  }
  const genres = [...genreW].map(([name, weight]) => ({ name, weight })).sort((a, b) => b.weight - a.weight);

  // clusters: artists grouped under their strongest shared genre
  const clusters: MusicDNA["clusters"] = [];
  const used = new Set<string>();
  for (const g of genres.slice(0, 8)) {
    const members = artists.filter((a) => !used.has(a.id) && artistGenres[a.id]?.includes(g.name)).slice(0, 6);
    if (members.length >= 2) {
      members.forEach((m) => used.add(m.id));
      clusters.push({ label: g.name, artists: members.map((m) => m.name) });
    }
  }

  const durs = tracks.map((t) => t.durationMs).sort((a, b) => a - b);
  return {
    playlistId: p.id,
    playlistName: p.name,
    size: tracks.length,
    artists,
    albums: [...albumCount.values()].filter((a) => a.count > 1).sort((a, b) => b.count - a.count),
    decades: [...decades].map(([decade, count]) => ({ decade, count })).sort((a, b) => a.decade.localeCompare(b.decade)),
    genres,
    clusters,
    genreCoverage: topForCoverage.length ? covered / topForCoverage.length : 0,
    explicitShare: tracks.length ? explicit / tracks.length : 0,
    medianDurationMs: durs.length ? durs[Math.floor(durs.length / 2)] : 0,
    builtAt: now,
  };
}
