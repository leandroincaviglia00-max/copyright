/**
 * Smart cleanup "lenses": each returns an ordered subset of entry keys plus an
 * honest description of the data it relies on. Lenses whose data isn't
 * available (e.g. listening history without the opt-in scope) say so instead
 * of guessing. No listening statistics are ever invented.
 */
import { normalizeTitle } from "../lib/format";
import type { PlaylistEntry } from "../playlists/model";
import type { PreferenceProfile } from "../discovery/preferenceProfile";
import type { ReviewSession } from "../review/types";

export interface ListeningData {
  recentUris: Set<string>; // last ≤50 plays (Spotify's limit)
  topTrackUris: Set<string>; // top tracks across short/medium/long term
  topArtistIds: Set<string>; // top artists across short/medium/long term
}

export interface LensResult {
  id: string;
  label: string;
  blurb: string;
  keys: string[];
  needs?: "history";
  available: boolean;
}

export interface LensInput {
  entries: PlaylistEntry[];
  session: ReviewSession;
  profile: PreferenceProfile;
  listening: ListeningData | null;
  genresByArtist: Record<string, string[]>;
  now?: number;
}

const YEAR = 365.25 * 86_400_000;

export function duplicateGroups(entries: PlaylistEntry[]): string[][] {
  const groups = new Map<string, string[]>();
  for (const e of entries) {
    if (e.kind !== "track" && e.kind !== "unavailable") continue;
    const sig = e.isrc ? `isrc:${e.isrc}` : `t:${normalizeTitle(e.name)}|${(e.artists[0]?.name ?? "").toLowerCase()}`;
    groups.set(sig, [...(groups.get(sig) ?? []), e.key]);
  }
  return [...groups.values()].filter((g) => g.length > 1);
}

export function computeLenses(i: LensInput): LensResult[] {
  const now = i.now ?? Date.now();
  const tracks = i.entries.filter((e) => e.kind === "track" || e.kind === "unavailable");
  const lenses: LensResult[] = [];

  const dups = duplicateGroups(i.entries).flat();
  lenses.push({ id: "duplicates", label: "Duplicates", blurb: "Same recording (ISRC) or same title + artist, side by side.", keys: dups, available: true });

  const byArtist = new Map<string, string[]>();
  for (const t of tracks) {
    const a = t.artists[0]?.id ?? t.artists[0]?.name;
    if (a) byArtist.set(a, [...(byArtist.get(a) ?? []), t.key]);
  }
  lenses.push({
    id: "one_offs",
    label: "One-song artists",
    blurb: "Artists who appear exactly once in this playlist.",
    keys: [...byArtist.values()].filter((k) => k.length === 1).flat(),
    available: true,
  });

  const dated = tracks.filter((t) => t.addedAt && now - t.addedAt > 2 * YEAR).sort((a, b) => (a.addedAt ?? 0) - (b.addedAt ?? 0));
  lenses.push({ id: "old_adds", label: "Added 2+ years ago", blurb: "Oldest additions first, from Spotify's added-at date.", keys: dated.map((t) => t.key), available: true });

  const rejectedArtists = new Set(
    Object.entries(i.profile.artists)
      .filter(([, v]) => v.removed + v.reject >= 2 && v.removed + v.reject > v.kept + v.like)
      .map(([id]) => id),
  );
  const rejectedGenres = new Set(Object.entries(i.profile.genres).filter(([, v]) => v.reject >= 3 && v.reject > v.like * 2).map(([g]) => g));
  const similar = tracks.filter((t) => {
    if (i.session.decisions[t.key]) return false;
    return t.artists.some((a) => a.id && (rejectedArtists.has(a.id) || (i.genresByArtist[a.id] ?? []).some((g) => rejectedGenres.has(g))));
  });
  lenses.push({
    id: "like_rejected",
    label: "Like ones you cut",
    blurb: "Undecided songs by artists (or genres) you've repeatedly removed or rejected.",
    keys: similar.map((t) => t.key),
    available: true,
  });

  const skipped = tracks.filter((t) => (i.session.skips[t.key] ?? 0) >= 2).sort((a, b) => (i.session.skips[b.key] ?? 0) - (i.session.skips[a.key] ?? 0));
  lenses.push({ id: "skipped", label: "Skipped in Sift", blurb: "Songs you've passed over twice or more without deciding (Sift only, not Spotify).", keys: skipped.map((t) => t.key), available: true });

  const unplayable = i.entries.filter((e) => e.kind !== "track");
  lenses.push({ id: "unplayable", label: "Unavailable & local", blurb: "Greyed-out, local, episode or unknown items.", keys: unplayable.map((e) => e.key), available: true });

  const L = i.listening;
  lenses.push({
    id: "not_recent",
    label: "Not in recent plays",
    blurb: "Not among your last 50 plays or your Spotify top tracks. That's the only history Spotify shares.",
    keys: L ? tracks.filter((t) => t.uri && !L.recentUris.has(t.uri) && !L.topTrackUris.has(t.uri)).map((t) => t.key) : [],
    needs: "history",
    available: !!L,
  });
  lenses.push({
    id: "rare_artists",
    label: "Artists outside your top",
    blurb: "Artists absent from your Spotify top artists (4 weeks, 6 months, all time).",
    keys: L ? tracks.filter((t) => !t.artists.some((a) => a.id && L.topArtistIds.has(a.id))).map((t) => t.key) : [],
    needs: "history",
    available: !!L,
  });
  return lenses;
}
