import type { SpImage, SpPlaylist, SpPlaylistItem, SpTrack, SpEpisode } from "../spotify/api/types";

export type EntryKind = "track" | "episode" | "local" | "unavailable" | "unknown";

export interface ArtistLite {
  id: string | null;
  name: string;
  url?: string;
}

/** A single slot in a playlist, normalised for the UI + engines. */
export interface PlaylistEntry {
  /** Stable across reorders: `${uri}::${nth occurrence}` */
  key: string;
  position: number;
  uri: string | null;
  kind: EntryKind;
  id: string | null;
  name: string;
  artists: ArtistLite[];
  albumName: string;
  albumId: string | null;
  albumUrl?: string;
  image: string | null;
  imageSmall: string | null;
  releaseDate: string | null;
  releaseYear: number | null;
  durationMs: number;
  explicit: boolean;
  previewUrl: string | null;
  isPlayable: boolean;
  url?: string;
  isrc: string | null;
  addedAt: number | null;
  addedBy: string | null;
}

export interface PlaylistSummary {
  id: string;
  name: string;
  description: string;
  image: string | null;
  total: number;
  ownerId: string;
  ownerName: string;
  isPublic: boolean | null;
  collaborative: boolean;
  snapshotId: string;
  url?: string;
  uri: string;
  /** Since Feb 2026 only owners/collaborators can read a playlist's items. */
  readable: boolean;
  editable: boolean;
}

export function pickImage(imgs: SpImage[] | null | undefined, target: number): string | null {
  if (!imgs?.length) return null;
  const sorted = [...imgs].sort((a, b) => (a.width ?? 640) - (b.width ?? 640));
  return (sorted.find((i) => (i.width ?? 640) >= target) ?? sorted[sorted.length - 1]).url;
}

export function toSummary(p: SpPlaylist, meId: string): PlaylistSummary {
  const owned = p.owner?.id === meId;
  const access = owned || p.collaborative;
  return {
    id: p.id,
    name: p.name,
    description: p.description ?? "",
    image: pickImage(p.images, 300),
    total: p.items?.total ?? p.tracks?.total ?? 0,
    ownerId: p.owner?.id ?? "",
    ownerName: p.owner?.display_name ?? p.owner?.id ?? "Unknown",
    isPublic: p.public,
    collaborative: p.collaborative,
    snapshotId: p.snapshot_id,
    url: p.external_urls?.spotify,
    uri: p.uri,
    readable: access,
    editable: access,
  };
}

const yearOf = (d?: string | null) => (d && /^\d{4}/.test(d) ? Number(d.slice(0, 4)) : null);

export function toEntries(raw: SpPlaylistItem[], startPosition = 0, seen = new Map<string, number>()): PlaylistEntry[] {
  return raw.map((r, i) => {
    const position = startPosition + i;
    const it = (r.item ?? r.track ?? null) as SpTrack | SpEpisode | { type: string; uri?: string; name?: string } | null;
    const uri = it?.uri ?? null;
    const n = uri ? (seen.get(uri) ?? 0) : 0;
    if (uri) seen.set(uri, n + 1);
    const key = uri ? `${uri}::${n}` : `pos::${position}`;
    const base = {
      key,
      position,
      uri,
      addedAt: r.added_at ? Date.parse(r.added_at) || null : null,
      addedBy: r.added_by?.id ?? null,
    };
    if (it && it.type === "track") {
      const t = it as SpTrack;
      const local = r.is_local || !!t.is_local || uri?.startsWith("spotify:local:");
      return {
        ...base,
        kind: local ? "local" : t.is_playable === false ? "unavailable" : "track",
        id: t.id,
        name: t.name || "Untitled",
        artists: (t.artists ?? []).map((a) => ({ id: a.id, name: a.name, url: a.external_urls?.spotify })),
        albumName: t.album?.name ?? "",
        albumId: t.album?.id ?? null,
        albumUrl: t.album?.external_urls?.spotify,
        image: pickImage(t.album?.images, 600),
        imageSmall: pickImage(t.album?.images, 64),
        releaseDate: t.album?.release_date ?? null,
        releaseYear: yearOf(t.album?.release_date),
        durationMs: t.duration_ms ?? 0,
        explicit: !!t.explicit,
        previewUrl: t.preview_url ?? null,
        isPlayable: !local && t.is_playable !== false,
        url: t.external_urls?.spotify,
        isrc: t.external_ids?.isrc ?? null,
      } satisfies PlaylistEntry;
    }
    if (it && it.type === "episode") {
      const e = it as SpEpisode;
      return {
        ...base,
        kind: "episode",
        id: e.id,
        name: e.name,
        artists: [{ id: null, name: e.show?.name ?? "Podcast" }],
        albumName: e.show?.name ?? "Episode",
        albumId: null,
        image: pickImage(e.images ?? e.show?.images, 600),
        imageSmall: pickImage(e.images ?? e.show?.images, 64),
        releaseDate: e.release_date ?? null,
        releaseYear: yearOf(e.release_date),
        durationMs: e.duration_ms ?? 0,
        explicit: !!e.explicit,
        previewUrl: null,
        isPlayable: true,
        url: e.external_urls?.spotify,
        isrc: null,
      } satisfies PlaylistEntry;
    }
    return {
      ...base,
      kind: "unknown",
      id: null,
      name: (it as { name?: string } | null)?.name ?? "Unsupported item",
      artists: [],
      albumName: "",
      albumId: null,
      image: null,
      imageSmall: null,
      releaseDate: null,
      releaseYear: null,
      durationMs: 0,
      explicit: false,
      previewUrl: null,
      isPlayable: false,
      isrc: null,
    } satisfies PlaylistEntry;
  });
}
