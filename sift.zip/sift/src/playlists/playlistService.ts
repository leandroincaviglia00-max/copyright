import { mapLimit } from "../lib/async";
import type { KV } from "../persistence/kv";
import type { SpotifyApi } from "../spotify/api/endpoints";
import { LIMITS } from "../spotify/api/endpoints";
import { SpotifyApiError } from "../spotify/api/errors";
import type { SpPlaylistItem } from "../spotify/api/types";
import { toEntries, toSummary, type PlaylistEntry, type PlaylistSummary } from "./model";

export interface LoadedPlaylist {
  summary: PlaylistSummary;
  entries: PlaylistEntry[];
  snapshotId: string;
  fetchedAt: number;
  fromCache: boolean;
}

interface CacheRecord {
  snapshotId: string;
  fetchedAt: number;
  raw: SpPlaylistItem[];
}

const cacheKey = (id: string) => `cache.items.${id}`;

export class PlaylistService {
  constructor(private api: SpotifyApi, private kv: KV, private meId: () => string) {}

  async library(signal?: AbortSignal): Promise<PlaylistSummary[]> {
    const all = await this.api.allMyPlaylists(signal);
    return all.map((p) => toSummary(p, this.meId()));
  }

  async summary(id: string, signal?: AbortSignal): Promise<PlaylistSummary> {
    const meta = await this.api.playlistMeta(id, signal);
    return toSummary({ ...meta, tracks: null } as never, this.meId());
  }

  /**
   * Loads every item via GET /playlists/{id}/items. Uses the cached copy when
   * the snapshot is unchanged, so large playlists aren't re-downloaded.
   */
  async load(
    id: string,
    opts: { signal?: AbortSignal; force?: boolean; onProgress?: (loaded: number, total: number) => void } = {},
  ): Promise<LoadedPlaylist> {
    const summary = await this.summary(id, opts.signal);
    if (!summary.readable) {
      throw new SpotifyApiError("forbidden", "Only the owner or collaborators can open this playlist (Spotify, Feb 2026).", 403);
    }
    const cached = opts.force ? undefined : await this.kv.get<CacheRecord>(cacheKey(id));
    if (cached && cached.snapshotId === summary.snapshotId) {
      return { summary, entries: toEntries(cached.raw), snapshotId: summary.snapshotId, fetchedAt: cached.fetchedAt, fromCache: true };
    }
    const raw = await this.fetchAllRaw(id, opts);
    const fetchedAt = Date.now();
    // Re-read the snapshot: if it moved mid-download, the pages may be inconsistent.
    const after = await this.api.playlistMeta(id, opts.signal);
    if (after.snapshot_id !== summary.snapshotId) return this.load(id, { ...opts, force: true });
    await this.kv.set<CacheRecord>(cacheKey(id), { snapshotId: summary.snapshotId, fetchedAt, raw });
    return { summary: { ...summary, total: raw.length }, entries: toEntries(raw), snapshotId: summary.snapshotId, fetchedAt, fromCache: false };
  }

  async fetchAllRaw(id: string, opts: { signal?: AbortSignal; onProgress?: (l: number, t: number) => void } = {}) {
    const first = await this.api.playlistItemsPage(id, 0, opts.signal);
    const total = first.total;
    const pages: SpPlaylistItem[][] = [first.items];
    let loaded = first.items.length;
    opts.onProgress?.(loaded, total);
    const offsets: number[] = [];
    for (let off = LIMITS.playlistItemsPage; off < total; off += LIMITS.playlistItemsPage) offsets.push(off);
    const rest = await mapLimit(offsets, 4, async (off) => {
      const p = await this.api.playlistItemsPage(id, off, opts.signal);
      loaded += p.items.length;
      opts.onProgress?.(loaded, total);
      return p.items;
    });
    pages.push(...rest);
    return pages.flat();
  }

  /** URIs only; used to avoid adding duplicates to a destination. */
  async uris(id: string, signal?: AbortSignal): Promise<Set<string>> {
    const fields = "total,next,items(item(uri))";
    const first = await this.api.playlistItemsPage(id, 0, signal, fields);
    const set = new Set<string>();
    const add = (items: SpPlaylistItem[]) => items.forEach((i) => (i.item?.uri ? set.add(i.item.uri) : null));
    add(first.items);
    const offsets: number[] = [];
    for (let off = LIMITS.playlistItemsPage; off < first.total; off += LIMITS.playlistItemsPage) offsets.push(off);
    await mapLimit(offsets, 4, async (off) => add((await this.api.playlistItemsPage(id, off, signal, fields)).items));
    return set;
  }

  invalidate(id: string) {
    return this.kv.del(cacheKey(id));
  }
}
