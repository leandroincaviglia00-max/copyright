import { useSyncExternalStore } from "react";

export type Route =
  | { name: "home" }
  | { name: "callback" }
  | { name: "library" }
  | { name: "review"; id: string }
  | { name: "summary"; id: string }
  | { name: "discover"; id?: string }
  | { name: "stats" }
  | { name: "sessions" };

export function parse(path: string): Route {
  const p = path.replace(/\/+$/, "") || "/";
  let m: RegExpMatchArray | null;
  if (p === "/") return { name: "home" };
  if (p === "/callback") return { name: "callback" };
  if (p === "/library") return { name: "library" };
  if (p === "/stats") return { name: "stats" };
  if (p === "/sessions") return { name: "sessions" };
  if ((m = p.match(/^\/review\/([^/]+)\/summary$/))) return { name: "summary", id: decodeURIComponent(m[1]) };
  if ((m = p.match(/^\/review\/([^/]+)$/))) return { name: "review", id: decodeURIComponent(m[1]) };
  if ((m = p.match(/^\/discover(?:\/([^/]+))?$/))) return { name: "discover", id: m[1] ? decodeURIComponent(m[1]) : undefined };
  return { name: "library" };
}

const listeners = new Set<() => void>();
const notify = () => listeners.forEach((l) => l());
if (typeof window !== "undefined") window.addEventListener("popstate", notify);

export function navigate(path: string, replace = false) {
  if (replace) history.replaceState(null, "", path);
  else history.pushState(null, "", path);
  window.scrollTo(0, 0);
  notify();
}

export function useRoute(): Route {
  const path = useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
    () => location.pathname,
  );
  return parse(path);
}
