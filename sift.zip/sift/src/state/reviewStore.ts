import { create } from "zustand";
import { recordReview } from "../discovery/preferenceProfile";
import { uid } from "../lib/async";
import type { PlaylistEntry, PlaylistSummary } from "../playlists/model";
import { planApply, planRestore, type ApplyJournal, type PlanSummary } from "../review/applyPlanner";
import { runJournal } from "../review/applyExecutor";
import { reconcile, type ReconcileReport } from "../review/reconcile";
import * as E from "../review/reviewEngine";
import type { Decision, DecisionRecord, QueueFilter, ReviewSession } from "../review/types";
import { exportSession, parseImport, downloadJson } from "../persistence/sessionRepo";
import { describeApiError, SpotifyApiError } from "../spotify/api/errors";
import { useApp } from "./appStore";
import { services } from "./services";

export type ApplyPhase =
  | { phase: "idle" }
  | { phase: "running"; done: number; total: number; label: string }
  | { phase: "conflict"; journal: ApplyJournal; remoteSnapshot: string }
  | { phase: "paused"; journal: ApplyJournal; message: string }
  | { phase: "done"; journal: ApplyJournal; at: number };

interface ReviewState {
  playlist: PlaylistSummary | null;
  entries: Map<string, PlaylistEntry>;
  list: PlaylistEntry[];
  session: ReviewSession | null;
  load: { state: "idle" | "loading" | "ready" | "error"; loaded: number; total: number; error?: string; readOnly?: boolean };
  remoteChanged: boolean;
  reconcileReport: ReconcileReport | null;
  apply: ApplyPhase;
  pendingJournal: ApplyJournal | null;
  lastApplied: ApplyJournal | null;

  open(id: string): Promise<void>;
  close(): void;
  decide(d: Decision, key?: string): void;
  undo(): void;
  redo(): void;
  skip(): void;
  goTo(key: string): void;
  jumpToUndecided(): void;
  setFilter(f: QueueFilter, lens?: ReviewSession["lens"]): void;
  restart(): void;
  addPendingPlaylist(p: { name: string; description: string; public: boolean }): string;
  checkRemote(): Promise<void>;
  resync(): Promise<void>;
  dismissReport(): void;
  plan(): { journal: ApplyJournal; summary: PlanSummary } | null;
  applyChanges(opts?: { acceptSnapshot?: string; journal?: ApplyJournal }): Promise<void>;
  discardPending(): Promise<void>;
  restoreLast(): Promise<void>;
  exportJson(): void;
  importJson(text: string): Promise<void>;
}

let abort: AbortController | null = null;
const writer = () => services().repo.writer(250);
let write: ReturnType<typeof writer> | null = null;
const persist = (s: ReviewSession) => {
  write ??= writer();
  write(s);
};
if (typeof window !== "undefined") {
  const flush = () => write?.flush();
  window.addEventListener("pagehide", flush);
  document.addEventListener("visibilitychange", () => document.visibilityState === "hidden" && flush());
}

export const useReview = create<ReviewState>((set, get) => {
  const update = (fn: (s: ReviewSession) => ReviewSession) => {
    const s = get().session;
    if (!s) return;
    const next = fn(s);
    if (next === s) return;
    set({ session: next });
    persist(next);
  };

  const indexEntries = (list: PlaylistEntry[]) => new Map(list.map((e) => [e.key, e]));

  async function refreshFromSpotify(force: boolean) {
    const { playlists } = services();
    const s = get().session;
    const pid = get().playlist?.id ?? s?.playlistId;
    if (!pid) return;
    const loaded = await playlists.load(pid, { force, onProgress: (l, t) => set({ load: { ...get().load, loaded: l, total: t } }) });
    const cur = get().session;
    if (!cur) return;
    const { session, report } = reconcile(cur, loaded.entries, loaded.snapshotId);
    set({
      playlist: loaded.summary,
      list: loaded.entries,
      entries: indexEntries(loaded.entries),
      session: { ...session, lastSyncedAt: Date.now() },
      remoteChanged: false,
      reconcileReport: report.changed && (report.addedExternally.length || report.removedExternally.length) ? report : null,
    });
    persist(get().session!);
    useApp.getState().upsertPlaylist(loaded.summary);
  }

  return {
    playlist: null,
    entries: new Map(),
    list: [],
    session: null,
    load: { state: "idle", loaded: 0, total: 0 },
    remoteChanged: false,
    reconcileReport: null,
    apply: { phase: "idle" },
    pendingJournal: null,
    lastApplied: null,

    async open(id) {
      if (get().session?.playlistId === id && get().load.state === "ready") return;
      abort?.abort();
      abort = new AbortController();
      const { playlists, repo } = services();
      set({ load: { state: "loading", loaded: 0, total: 0 }, session: null, list: [], entries: new Map(), apply: { phase: "idle" }, reconcileReport: null, remoteChanged: false });
      try {
        const loaded = await playlists.load(id, { signal: abort.signal, onProgress: (l, t) => set({ load: { state: "loading", loaded: l, total: t } }) });
        let session = await repo.latestFor(id);
        let report: ReconcileReport | null = null;
        if (session) {
          const r = reconcile(session, loaded.entries, loaded.snapshotId);
          session = r.session;
          if (r.report.addedExternally.length || r.report.removedExternally.length) report = r.report;
        } else {
          session = E.createSession({ id, name: loaded.summary.name, image: loaded.summary.image, snapshotId: loaded.snapshotId }, loaded.entries);
        }
        session = { ...session, playlistName: loaded.summary.name, playlistImage: loaded.summary.image, lastSyncedAt: loaded.fromCache ? session.lastSyncedAt : Date.now() };
        const [pendingJournal, lastApplied] = await Promise.all([repo.loadJournal(id), repo.loadLastApplied(id)]);
        set({
          playlist: loaded.summary,
          list: loaded.entries,
          entries: indexEntries(loaded.entries),
          session,
          reconcileReport: report,
          pendingJournal: pendingJournal && !pendingJournal.finishedAt ? pendingJournal : null,
          lastApplied: lastApplied ?? null,
          load: { state: "ready", loaded: loaded.entries.length, total: loaded.entries.length, readOnly: !loaded.summary.editable },
        });
        persist(session);
        useApp.getState().upsertPlaylist(loaded.summary);
      } catch (e) {
        if (e instanceof SpotifyApiError && e.kind === "aborted") return;
        set({ load: { state: "error", loaded: 0, total: 0, error: describeApiError(e, "opening this playlist") } });
      }
    },

    close() {
      abort?.abort();
      write?.flush();
    },

    decide(d, key) {
      const s = get().session;
      const k = key ?? (s ? E.current(s) : null);
      if (!s || !k) return;
      const entry = get().entries.get(k);
      update((x) => E.decide(x, k, d));
      if (entry) {
        const app = useApp.getState();
        app.setProfile(recordReview(app.profile, entry.artists, d.kind));
      }
    },
    undo: () => update((s) => E.undo(s)),
    redo: () => update((s) => E.redo(s)),
    skip() {
      const s = get().session;
      const k = s && E.current(s);
      if (k) update((x) => E.skip(x, k));
    },
    goTo: (key) => update((s) => E.goTo(s, key)),
    jumpToUndecided: () => update((s) => E.jumpToUndecided(s)),
    setFilter: (f, lens = null) => update((s) => E.setFilter(s, f, lens)),
    restart: () => update((s) => E.restart(s)),

    addPendingPlaylist(p) {
      const tempId = `new:${uid()}`;
      update((s) => ({ ...s, pendingPlaylists: [...s.pendingPlaylists, { tempId, ...p }] }));
      return tempId;
    },

    async checkRemote() {
      const s = get().session;
      if (!s || get().apply.phase === "running") return;
      try {
        const meta = await services().api.playlistMeta(s.playlistId);
        set({ remoteChanged: meta.snapshot_id !== s.snapshotId });
      } catch {
        /* silent; we'll try again */
      }
    },

    async resync() {
      try {
        await refreshFromSpotify(true);
        useApp.getState().toast({ text: "Synced with Spotify", tone: "success" });
      } catch (e) {
        useApp.getState().toast({ text: describeApiError(e, "syncing"), tone: "error" });
      }
    },

    dismissReport: () => set({ reconcileReport: null }),

    plan() {
      const s = get().session;
      if (!s) return null;
      const app = useApp.getState();
      const names = Object.fromEntries(app.library.map((p) => [p.id, p.name]));
      return planApply(s, { laterPlaylistId: app.settings.laterPlaylistId, playlistNames: names });
    },

    async applyChanges(opts = {}) {
      const s = get().session;
      if (!s || get().playlist?.editable === false) return;
      const { repo, api, playlists } = services();
      const app = useApp.getState();
      const journal = opts.journal ?? get().pendingJournal ?? get().plan()?.journal;
      if (!journal) return;
      await repo.saveJournal(journal);
      set({ pendingJournal: journal, apply: { phase: "running", done: 0, total: journal.steps.length, label: "Starting…" } });
      update((x) => ({ ...x, status: "applying" }));
      const labels = { create: "Creating playlist", add: "Adding songs", remove: "Removing songs", readd: "Restoring kept duplicates" } as const;
      const res = await runJournal(
        journal,
        {
          api,
          playlists,
          persist: (j) => repo.saveJournal(j),
          onProgress: (done, total, st) => set({ apply: { phase: "running", done, total, label: labels[st.type] } }),
          onCreated: (ref, id) => {
            if (ref === "later") app.setSettings({ laterPlaylistId: id });
            update((x) => ({ ...x, pendingPlaylists: x.pendingPlaylists.map((p) => (p.tempId === ref ? { ...p, createdId: id } : p)) }));
          },
        },
        { skipExisting: app.settings.skipExisting, acceptSnapshot: opts.acceptSnapshot },
      );
      if (res.status === "conflict") {
        set({ apply: { phase: "conflict", journal: res.journal, remoteSnapshot: res.remoteSnapshot }, pendingJournal: res.journal });
        update((x) => ({ ...x, status: "reviewing" }));
        return;
      }
      if (res.status === "paused") {
        set({ apply: { phase: "paused", journal: res.journal, message: res.message }, pendingJournal: res.journal });
        update((x) => ({ ...x, status: "reviewing" }));
        return;
      }
      await repo.saveLastApplied(res.journal);
      await repo.clearJournal(res.journal.playlistId);
      // Applied moves become keeps so they aren't re-sent next time.
      update((x) => ({
        ...x,
        status: "reviewing",
        decisions: Object.fromEntries(
          Object.entries(x.decisions).map(([k, d]): [string, DecisionRecord] => [k, d.kind === "move" && d.keepInSource ? { kind: "keep", at: d.at } : d]),
        ),
        history: [],
        future: [],
      }));
      set({ pendingJournal: null, lastApplied: res.journal, apply: { phase: "done", journal: res.journal, at: Date.now() } });
      await playlists.invalidate(res.journal.playlistId);
      try {
        await refreshFromSpotify(true);
      } catch (e) {
        app.toast({ text: describeApiError(e, "refreshing after apply"), tone: "error" });
      }
      set({ reconcileReport: null });
      void app.loadLibrary(true);
    },

    async discardPending() {
      const s = get().session;
      if (!s) return;
      await services().repo.clearJournal(s.playlistId);
      set({ pendingJournal: null, apply: { phase: "idle" } });
    },

    async restoreLast() {
      const last = get().lastApplied;
      if (!last || !last.removed.length) return;
      const j = planRestore(last);
      await get().applyChanges({ journal: j });
      if (get().apply.phase === "done") {
        await services().repo.saveLastApplied({ ...last, removed: [] });
        set({ lastApplied: { ...last, removed: [] } });
        useApp.getState().toast({ text: `Put ${last.removed.length} songs back`, tone: "success" });
      }
    },

    exportJson() {
      const s = get().session;
      if (!s) return;
      downloadJson(`sift-${s.playlistName.replace(/[^\w-]+/g, "_")}-${new Date().toISOString().slice(0, 10)}.json`, exportSession(s));
    },

    async importJson(text) {
      const imported = parseImport(text);
      const cur = get().session;
      if (!cur || imported.playlistId !== cur.playlistId) throw new Error("That export belongs to a different playlist. Open that playlist first.");
      const { session, report } = reconcile({ ...imported, id: cur.id }, get().list, cur.snapshotId);
      set({ session, reconcileReport: report.droppedDecisions.length ? report : null });
      persist(session);
    },
  };
});
