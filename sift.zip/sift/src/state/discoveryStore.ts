import { create } from "zustand";
import { DiscoveryEngine } from "../discovery/engine";
import type { PreferenceProfile } from "../discovery/preferenceProfile";
import type { Candidate, MusicDNA, Ranked, Verdict } from "../discovery/types";
import { chunk } from "../lib/async";
import { describeApiError } from "../spotify/api/errors";
import { useApp } from "./appStore";
import { services } from "./services";

interface Decided {
  candidate: Candidate;
  verdict: Verdict;
  prevProfile: PreferenceProfile;
  at: number;
}

interface DiscoveryState {
  refId: string | null;
  refName: string;
  phase: "idle" | "analyzing" | "ready" | "error";
  error: string | null;
  dna: MusicDNA | null;
  stack: Ranked[];
  liked: Candidate[];
  later: Candidate[];
  history: Decided[];
  destinationId: string | null; // null → create "Sift · Discoveries"
  saving: boolean;
  exhausted: boolean;

  start(playlistId: string): Promise<void>;
  decide(v: Verdict): void;
  undo(): void;
  setDestination(id: string | null): void;
  saveLiked(): Promise<void>;
}

let engine: DiscoveryEngine | null = null;

export const useDiscovery = create<DiscoveryState>((set, get) => {
  const sync = () => set({ stack: engine?.peek(3) ?? [], exhausted: !!engine?.exhausted && !(engine?.peek(1).length) });
  return {
    refId: null,
    refName: "",
    phase: "idle",
    error: null,
    dna: null,
    stack: [],
    liked: [],
    later: [],
    history: [],
    destinationId: null,
    saving: false,
    exhausted: false,

    async start(id) {
      if (get().refId === id && get().phase !== "error") return;
      const { playlists, catalog } = services();
      const app = useApp.getState();
      set({ refId: id, phase: "analyzing", error: null, dna: null, stack: [], liked: [], later: [], history: [] });
      try {
        const loaded = await playlists.load(id);
        set({ refName: loaded.summary.name, destinationId: loaded.summary.editable ? id : null });
        engine = new DiscoveryEngine([catalog], app.profile);
        const dna = await engine.analyze(loaded.summary, loaded.entries);
        set({ dna });
        await engine.fill();
        set({ phase: "ready" });
        sync();
      } catch (e) {
        set({ phase: "error", error: describeApiError(e, "analysing this playlist") });
      }
    },

    decide(v) {
      const top = get().stack[0];
      if (!engine || !top) return;
      const prevProfile = engine.profile;
      const profile = engine.decide(top.candidate, v);
      useApp.getState().setProfile(profile);
      const c = top.candidate;
      set({
        history: [...get().history, { candidate: c, verdict: v, prevProfile, at: Date.now() }],
        liked: v === "like" ? [...get().liked, c] : get().liked,
        later: v === "later" ? [...get().later, c] : get().later,
      });
      sync();
      // background refills land asynchronously
      setTimeout(sync, 1500);
      setTimeout(sync, 4000);
    },

    undo() {
      const h = get().history;
      const last = h[h.length - 1];
      if (!engine || !last) return;
      engine.restore(last.candidate, last.prevProfile);
      useApp.getState().setProfile(last.prevProfile);
      set({
        history: h.slice(0, -1),
        liked: get().liked.filter((c) => c.uri !== last.candidate.uri),
        later: get().later.filter((c) => c.uri !== last.candidate.uri),
      });
      sync();
    },

    setDestination: (id) => set({ destinationId: id }),

    async saveLiked() {
      const { api, playlists } = services();
      const app = useApp.getState();
      const { liked, later } = get();
      if (!liked.length && !later.length) return;
      set({ saving: true });
      try {
        let dest = get().destinationId;
        if (liked.length && !dest) {
          const p = await api.createPlaylist({ name: "Sift · Discoveries", description: `Found with Sift, seeded by “${get().refName}”.`, public: false });
          dest = p.id;
          set({ destinationId: dest });
        }
        const push = async (target: string, cs: Candidate[]) => {
          const have = await playlists.uris(target);
          const uris = cs.map((c) => c.uri).filter((u) => !have.has(u));
          for (const c of chunk(uris, 100)) await api.addItems(target, c);
          await playlists.invalidate(target);
          return uris.length;
        };
        let added = 0;
        if (liked.length && dest) added += await push(dest, liked);
        if (later.length) {
          let laterId = app.settings.laterPlaylistId;
          if (!laterId) {
            laterId = (await api.createPlaylist({ name: "Sift · Later", description: "Songs saved for later while sorting with Sift.", public: false })).id;
            app.setSettings({ laterPlaylistId: laterId });
          }
          added += await push(laterId, later);
        }
        set({ liked: [], later: [] });
        app.toast({ text: `Added ${added} song${added === 1 ? "" : "s"} on Spotify`, tone: "success" });
        void app.loadLibrary(true);
      } catch (e) {
        app.toast({ text: describeApiError(e, "saving discoveries"), tone: "error" });
      } finally {
        set({ saving: false });
      }
    },
  };
});
