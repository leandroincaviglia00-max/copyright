/** Composition root: every service is constructed exactly once here. */
import { config } from "../config/env";
import { SpotifyCatalogSource } from "../discovery/sources/spotifyCatalog";
import { PlaybackController } from "../playback/playbackController";
import { PlaylistService } from "../playlists/playlistService";
import { createKV } from "../persistence/kv";
import { SessionRepo } from "../persistence/sessionRepo";
import { AuthService } from "../spotify/auth/authService";
import { HISTORY_SCOPES } from "../spotify/auth/scopes";
import { SpotifyClient } from "../spotify/api/client";
import { SpotifyApi } from "../spotify/api/endpoints";

let meId = "";
export const setMeId = (id: string) => (meId = id);
export const getMeId = () => meId;

function build() {
  const cfg = config();
  const auth = new AuthService({
    clientId: cfg.clientId,
    redirectUri: cfg.redirectUri,
    storage: window.localStorage,
    pendingStorage: window.sessionStorage,
  });
  const rateListeners = new Set<(ms: number) => void>();
  const client = new SpotifyClient({ auth, onRateLimit: (ms) => rateListeners.forEach((l) => l(ms)) });
  const api = new SpotifyApi(client);
  const kv = createKV();
  const repo = new SessionRepo(kv);
  const playlists = new PlaylistService(api, kv, getMeId);
  const playback = new PlaybackController(api, () => auth.getAccessToken(), cfg.playerName);
  const catalog = new SpotifyCatalogSource(api, kv, () => auth.hasScopes(HISTORY_SCOPES));
  return { cfg, auth, client, api, kv, repo, playlists, playback, catalog, rateListeners };
}

export type Services = ReturnType<typeof build>;
let instance: Services | null = null;
export function services(): Services {
  if (!instance) instance = build();
  return instance;
}
