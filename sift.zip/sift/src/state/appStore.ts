import { create } from "zustand";
import { emptyProfile, type PreferenceProfile } from "../discovery/preferenceProfile";
import type { ListeningData } from "../cleanup/smartFilters";
import type { PlaylistSummary } from "../playlists/model";
import { describeApiError } from "../spotify/api/errors";
import { HISTORY_SCOPES } from "../spotify/auth/scopes";
import { getMeId, services, setMeId } from "./services";

export interface Settings {
  theme: "dark" | "light";
  autoplayNext: boolean;
  /** 0 = from the top, 0.3 = skip ahead to ~30% */
  startAt: number;
  skipExisting: boolean;
  laterPlaylistId: string | null;
}

export interface Toast {
  id: number;
  text: string;
  tone?: "info" | "error" | "success";
  action?: { label: string; run: () => void };
  ttl?: number;
}

interface AppState {
  auth: "unknown" | "signed_out" | "signed_in" | "expired";
  me: { id: string; name: string; image: string | null } | null;
  library: PlaylistSummary[];
  libraryState: "idle" | "loading" | "ready" | "error";
  libraryError: string | null;
  settings: Settings;
  profile: PreferenceProfile;
  listening: ListeningData | null;
  listeningState: "off" | "loading" | "ready" | "error";
  toasts: Toast[];
  rateLimitedUntil: number | null;

  boot(): Promise<void>;
  loadLibrary(force?: boolean): Promise<void>;
  upsertPlaylist(p: PlaylistSummary): void;
  setSettings(p: Partial<Settings>): void;
  setProfile(p: PreferenceProfile): void;
  enableListening(): Promise<void>;
  loadListening(): Promise<void>;
  toast(t: Omit<Toast, "id">): number;
  dismiss(id: number): void;
  logout(): void;
}

const SETTINGS_KEY = "sift.settings.v1";
const defaultSettings: Settings = { theme: "dark", autoplayNext: true, startAt: 0.25, skipExisting: true, laterPlaylistId: null };
const loadSettings = (): Settings => {
  try {
    return { ...defaultSettings, ...JSON.parse(localStorage.getItem(SETTINGS_KEY) ?? "{}") };
  } catch {
    return defaultSettings;
  }
};

let toastId = 0;

export const useApp = create<AppState>((set, get) => ({
  auth: "unknown",
  me: null,
  library: [],
  libraryState: "idle",
  libraryError: null,
  settings: loadSettings(),
  profile: emptyProfile(),
  listening: null,
  listeningState: "off",
  toasts: [],
  rateLimitedUntil: null,

  async boot() {
    const s = services();
    s.auth.changes.on((st) => set({ auth: st.status }));
    s.rateListeners.add((ms) => set({ rateLimitedUntil: Date.now() + ms }));
    const profile = await s.kv.get<PreferenceProfile>("profile.v1");
    if (profile) set({ profile });
    const st = s.auth.state();
    if (st.status !== "signed_in") return set({ auth: st.status });
    try {
      const me = await s.api.me();
      setMeId(me.id);
      set({ auth: "signed_in", me: { id: me.id, name: me.display_name ?? me.id, image: me.images?.[0]?.url ?? null } });
      if (s.auth.hasScopes(HISTORY_SCOPES)) void get().loadListening();
    } catch (e) {
      set({ auth: s.auth.state().status === "signed_in" ? "signed_in" : "expired" });
      get().toast({ text: describeApiError(e, "loading your profile"), tone: "error" });
    }
  },

  async loadLibrary(force = false) {
    if (!force && get().libraryState === "ready") return;
    set({ libraryState: "loading", libraryError: null });
    try {
      if (!getMeId()) await get().boot();
      const library = await services().playlists.library();
      set({ library, libraryState: "ready" });
      const later = get().settings.laterPlaylistId;
      if (later && !library.some((p) => p.id === later)) get().setSettings({ laterPlaylistId: null });
    } catch (e) {
      set({ libraryState: "error", libraryError: describeApiError(e, "loading your playlists") });
    }
  },

  upsertPlaylist(p) {
    const lib = get().library;
    const i = lib.findIndex((x) => x.id === p.id);
    set({ library: i >= 0 ? lib.map((x) => (x.id === p.id ? { ...x, ...p } : x)) : [p, ...lib] });
  },

  setSettings(p) {
    const settings = { ...get().settings, ...p };
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    set({ settings });
  },

  setProfile(profile) {
    set({ profile });
    void services().kv.set("profile.v1", profile);
  },

  async enableListening() {
    await services().auth.login(HISTORY_SCOPES, location.pathname);
  },

  async loadListening() {
    const { api } = services();
    set({ listeningState: "loading" });
    try {
      const ranges = ["short_term", "medium_term", "long_term"] as const;
      const [recent, ...tops] = await Promise.all([
        api.recentlyPlayed(),
        ...ranges.map((r) => api.topTracks(r)),
        ...ranges.map((r) => api.topArtists(r)),
      ]);
      const r = recent as Awaited<ReturnType<typeof api.recentlyPlayed>>;
      const tt = tops.slice(0, 3) as Awaited<ReturnType<typeof api.topTracks>>[];
      const ta = tops.slice(3) as Awaited<ReturnType<typeof api.topArtists>>[];
      set({
        listening: {
          recentUris: new Set(r.items.map((i) => i.track.uri)),
          topTrackUris: new Set(tt.flatMap((p) => p.items.map((t) => t.uri))),
          topArtistIds: new Set(ta.flatMap((p) => p.items.map((a) => a.id!).filter(Boolean))),
        },
        listeningState: "ready",
      });
    } catch (e) {
      set({ listeningState: "error" });
      get().toast({ text: describeApiError(e, "reading listening history"), tone: "error" });
    }
  },

  toast(t) {
    const id = ++toastId;
    set({ toasts: [...get().toasts.slice(-1), { ...t, id }] });
    setTimeout(() => get().dismiss(id), t.ttl ?? (t.action ? 5000 : 3500));
    return id;
  },
  dismiss(id) {
    set({ toasts: get().toasts.filter((t) => t.id !== id) });
  },

  logout() {
    const s = services();
    s.playback.dispose();
    s.auth.logout();
    set({ me: null, library: [], libraryState: "idle", auth: "signed_out", listening: null, listeningState: "off" });
  },
}));
