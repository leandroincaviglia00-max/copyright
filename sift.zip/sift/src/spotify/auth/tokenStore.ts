export interface TokenSet {
  accessToken: string;
  refreshToken: string | null;
  /** epoch ms */
  expiresAt: number;
  scopes: string[];
}

export interface StorageLike {
  getItem(k: string): string | null;
  setItem(k: string, v: string): void;
  removeItem(k: string): void;
}

export class MemoryStorage implements StorageLike {
  private m = new Map<string, string>();
  getItem(k: string) {
    return this.m.has(k) ? (this.m.get(k) as string) : null;
  }
  setItem(k: string, v: string) {
    this.m.set(k, v);
  }
  removeItem(k: string) {
    this.m.delete(k);
  }
}

const KEY = "sift.auth.tokens.v1";

export class TokenStore {
  constructor(private storage: StorageLike) {}
  load(): TokenSet | null {
    try {
      const raw = this.storage.getItem(KEY);
      if (!raw) return null;
      const t = JSON.parse(raw) as TokenSet;
      if (!t.accessToken || typeof t.expiresAt !== "number") return null;
      return t;
    } catch {
      return null;
    }
  }
  save(t: TokenSet) {
    this.storage.setItem(KEY, JSON.stringify(t));
  }
  clear() {
    this.storage.removeItem(KEY);
  }
}
