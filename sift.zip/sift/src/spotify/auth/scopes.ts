/**
 * Every scope Sift requests, and why. Keep this list minimal.
 * https://developer.spotify.com/documentation/web-api/concepts/scopes
 */
export const CORE_SCOPES = [
  "playlist-read-private", // list + read your private playlists
  "playlist-read-collaborative", // read collaborative playlists you're part of
  "playlist-modify-private", // remove/add/create on private playlists
  "playlist-modify-public", // remove/add on public playlists
  "user-read-playback-state", // show the active device, read progress
  "user-modify-playback-state", // start/pause/seek/transfer playback
  "streaming", // Web Playback SDK (in-browser Premium playback)
  "user-read-email", // required by the Web Playback SDK
  "user-read-private", // required by the Web Playback SDK
] as const;

/**
 * Opt-in only. Requested when the user enables "Listening insights" (smart
 * cleanup lenses + discovery seeds that use real listening data).
 */
export const HISTORY_SCOPES = ["user-read-recently-played", "user-top-read"] as const;

export type Scope = (typeof CORE_SCOPES)[number] | (typeof HISTORY_SCOPES)[number];
