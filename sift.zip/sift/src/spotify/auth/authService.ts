import { Emitter } from "../../lib/emitter";
import { challengeFromVerifier, randomString } from "./pkce";
import { CORE_SCOPES } from "./scopes";
import { TokenStore, type StorageLike, type TokenSet } from "./tokenStore";

export const AUTHORIZE_URL = "https://accounts.spotify.com/authorize";
export const TOKEN_URL = "https://accounts.spotify.com/api/token";
const PENDING_KEY = "sift.auth.pending.v1";
/** Refresh this long before the token actually expires. */
const SKEW_MS = 60_000;

export type AuthErrorKind = "denied" | "state_mismatch" | "exchange_failed" | "expired" | "not_signed_in" | "network";

export class AuthError extends Error {
  constructor(public kind: AuthErrorKind, message: string) {
    super(message);
    this.name = "AuthError";
  }
}

interface Pending {
  verifier: string;
  state: string;
  scopes: string[];
  returnTo: string;
}

export interface AuthDeps {
  clientId: string;
  redirectUri: string;
  /** persistent storage for tokens (localStorage in the browser) */
  storage: StorageLike;
  /** per-tab storage for the in-flight PKCE verifier (sessionStorage) */
  pendingStorage: StorageLike;
  fetch?: typeof fetch;
  now?: () => number;
  navigate?: (url: string) => void;
}

export type AuthState = { status: "signed_out" } | { status: "signed_in"; scopes: string[] } | { status: "expired" };

export class AuthService {
  readonly changes = new Emitter<AuthState>();
  private tokens: TokenStore;
  private refreshing: Promise<TokenSet> | null = null;
  private f: typeof fetch;
  private now: () => number;

  constructor(private deps: AuthDeps) {
    this.tokens = new TokenStore(deps.storage);
    this.f = deps.fetch ?? ((...a) => fetch(...a));
    this.now = deps.now ?? Date.now;
  }

  state(): AuthState {
    const t = this.tokens.load();
    if (!t) return { status: "signed_out" };
    if (!t.refreshToken && t.expiresAt <= this.now()) return { status: "expired" };
    return { status: "signed_in", scopes: t.scopes };
  }

  hasScopes(scopes: readonly string[]) {
    const t = this.tokens.load();
    return !!t && scopes.every((s) => t.scopes.includes(s));
  }

  /** Build the authorize URL (and persist the verifier). Exposed for tests. */
  async buildAuthorizeUrl(extraScopes: readonly string[] = [], returnTo = "/library"): Promise<string> {
    const verifier = randomString(64);
    const state = randomString(43);
    const already = this.tokens.load()?.scopes ?? [];
    const scopes = Array.from(new Set([...CORE_SCOPES, ...already.filter((s) => s !== ""), ...extraScopes]));
    const pending: Pending = { verifier, state, scopes, returnTo };
    this.deps.pendingStorage.setItem(PENDING_KEY, JSON.stringify(pending));
    const params = new URLSearchParams({
      client_id: this.deps.clientId,
      response_type: "code",
      redirect_uri: this.deps.redirectUri,
      code_challenge_method: "S256",
      code_challenge: await challengeFromVerifier(verifier),
      state,
      scope: scopes.join(" "),
    });
    return `${AUTHORIZE_URL}?${params.toString()}`;
  }

  async login(extraScopes: readonly string[] = [], returnTo?: string) {
    const url = await this.buildAuthorizeUrl(extraScopes, returnTo);
    (this.deps.navigate ?? ((u) => window.location.assign(u)))(url);
  }

  /** Handle the redirect back from Spotify. Returns where to go next. */
  async handleCallback(search: string): Promise<string> {
    const q = new URLSearchParams(search);
    const rawPending = this.deps.pendingStorage.getItem(PENDING_KEY);
    this.deps.pendingStorage.removeItem(PENDING_KEY);
    const err = q.get("error");
    if (err) {
      throw new AuthError(
        "denied",
        err === "access_denied" ? "You declined access on Spotify. Sift needs it to read and edit your playlists." : `Spotify returned “${err}”.`,
      );
    }
    const pending = rawPending ? (JSON.parse(rawPending) as Pending) : null;
    const code = q.get("code");
    if (!pending || !code || q.get("state") !== pending.state) {
      throw new AuthError("state_mismatch", "This sign-in link is stale or was opened in another tab. Please sign in again.");
    }
    const body = new URLSearchParams({
      grant_type: "authorization_code",
      code,
      redirect_uri: this.deps.redirectUri,
      client_id: this.deps.clientId,
      code_verifier: pending.verifier,
    });
    const t = await this.tokenRequest(body, null, pending.scopes);
    this.tokens.save(t);
    this.changes.emit(this.state());
    return pending.returnTo || "/library";
  }

  /** Returns a valid access token, refreshing if needed. */
  async getAccessToken(): Promise<string> {
    const t = this.tokens.load();
    if (!t) throw new AuthError("not_signed_in", "Not signed in to Spotify.");
    if (t.expiresAt - SKEW_MS > this.now()) return t.accessToken;
    return (await this.refresh()).accessToken;
  }

  /** Single-flight refresh. Called proactively and on 401. */
  refresh(): Promise<TokenSet> {
    if (this.refreshing) return this.refreshing;
    const current = this.tokens.load();
    if (!current?.refreshToken) {
      this.markExpired();
      return Promise.reject(new AuthError("expired", "Your Spotify session expired. Sign in again; your review progress is saved."));
    }
    const body = new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: current.refreshToken,
      client_id: this.deps.clientId,
    });
    this.refreshing = this.tokenRequest(body, current.refreshToken, current.scopes)
      .then((t) => {
        this.tokens.save(t);
        return t;
      })
      .catch((e) => {
        if (e instanceof AuthError && e.kind !== "network") this.markExpired();
        throw e;
      })
      .finally(() => {
        this.refreshing = null;
      });
    return this.refreshing;
  }

  logout() {
    this.tokens.clear();
    this.changes.emit({ status: "signed_out" });
  }

  private markExpired() {
    this.tokens.clear();
    this.changes.emit({ status: "expired" });
  }

  private async tokenRequest(body: URLSearchParams, prevRefresh: string | null, requestedScopes: string[]): Promise<TokenSet> {
    let res: Response;
    try {
      res = await this.f(TOKEN_URL, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: body.toString(),
      });
    } catch {
      throw new AuthError("network", "Couldn't reach Spotify to sign you in. Check your connection.");
    }
    const json = (await res.json().catch(() => ({}))) as Record<string, unknown>;
    if (!res.ok) {
      const code = String(json.error ?? res.status);
      const kind: AuthErrorKind = body.get("grant_type") === "refresh_token" ? "expired" : "exchange_failed";
      const msg =
        code === "invalid_grant"
          ? kind === "expired"
            ? "Your Spotify session expired or was revoked. Sign in again; your review progress is saved."
            : "That sign-in code was already used or expired. Please sign in again."
          : code === "invalid_client"
            ? "Spotify doesn't recognise this Client ID. Check VITE_SPOTIFY_CLIENT_ID."
            : `Spotify sign-in failed (${code}).`;
      throw new AuthError(kind, msg);
    }
    const scopes = typeof json.scope === "string" && json.scope ? json.scope.split(" ") : requestedScopes;
    return {
      accessToken: String(json.access_token),
      // Spotify may rotate refresh tokens; keep the old one if a new one isn't issued.
      refreshToken: typeof json.refresh_token === "string" ? json.refresh_token : prevRefresh,
      expiresAt: this.now() + Number(json.expires_in ?? 3600) * 1000,
      scopes,
    };
  }
}
