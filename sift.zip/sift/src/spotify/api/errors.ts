export type ApiErrorKind =
  | "unauthorized" // 401 after a refresh attempt
  | "forbidden" // 403: missing scope, not owner, Premium required, dev-mode user not allow-listed
  | "not_found" // 404: playlist deleted / device gone
  | "conflict" // 409 / snapshot mismatch
  | "rate_limited" // 429 that we gave up waiting on
  | "quota" // 429 with reason QUOTA_EXCEEDED (July 2026 change)
  | "bad_request"
  | "server"
  | "network"
  | "aborted";

export class SpotifyApiError extends Error {
  constructor(
    public kind: ApiErrorKind,
    message: string,
    public status: number | null = null,
    public reason: string | null = null,
    public retryAfterMs: number | null = null,
  ) {
    super(message);
    this.name = "SpotifyApiError";
  }
}

/** Human, actionable copy for each failure mode. */
export function describeApiError(e: unknown, context?: string): string {
  const where = context ? ` while ${context}` : "";
  if (!(e instanceof SpotifyApiError)) return e instanceof Error ? e.message : `Something went wrong${where}.`;
  switch (e.kind) {
    case "unauthorized":
      return "Spotify signed you out. Sign in again; nothing you've decided is lost.";
    case "forbidden":
      if (/premium/i.test(e.message)) return "Full-track playback needs Spotify Premium. Previews and “Open in Spotify” still work.";
      if (/owner|collaborat/i.test(e.message) || context?.includes("playlist"))
        return "Spotify only lets owners and collaborators read or change this playlist.";
      return `Spotify refused the request${where}. If this app is in Development Mode, make sure your account is added under “User Management” in the Spotify dashboard.`;
    case "not_found":
      return `Spotify couldn't find that${where}. It may have been deleted or the device went offline.`;
    case "conflict":
      return "The playlist changed on Spotify since you loaded it.";
    case "rate_limited":
      return "Spotify is rate-limiting us. Give it a moment and try again.";
    case "quota":
      return "This app hit its Spotify API quota. Wait a while, then retry. Your decisions are safe locally.";
    case "network":
      return `Network problem${where}. Your decisions are saved locally; retry when you're back online.`;
    case "server":
      return `Spotify had a hiccup${where}. Retry in a moment.`;
    case "aborted":
      return "Cancelled.";
    default:
      return e.message || `Spotify rejected the request${where}.`;
  }
}
