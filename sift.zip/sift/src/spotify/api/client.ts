import { backoffDelay, isAbort, sleep } from "../../lib/async";
import { SpotifyApiError, type ApiErrorKind } from "./errors";

export const API_BASE = "https://api.spotify.com/v1";

export interface TokenProvider {
  getAccessToken(): Promise<string>;
  refresh(): Promise<unknown>;
}

export interface ClientDeps {
  auth: TokenProvider;
  fetch?: typeof fetch;
  sleep?: (ms: number, signal?: AbortSignal) => Promise<void>;
  random?: () => number;
  /** How many times to retry 429 / 5xx / network failures. */
  maxRetries?: number;
  /** Longest Retry-After we are willing to wait inline. */
  maxRetryAfterMs?: number;
  onRateLimit?: (waitMs: number) => void;
}

export type Query = Record<string, string | number | boolean | undefined | null>;

export interface RequestOpts {
  query?: Query;
  body?: unknown;
  signal?: AbortSignal;
  /** Allow retrying on network/5xx even for non-idempotent methods. Default: only GET/PUT/DELETE. */
  retryUnsafe?: boolean;
}

export type HttpMethod = "GET" | "POST" | "PUT" | "DELETE";

export class SpotifyClient {
  private f: typeof fetch;
  private wait: (ms: number, signal?: AbortSignal) => Promise<void>;
  private maxRetries: number;
  private maxRetryAfterMs: number;
  constructor(private deps: ClientDeps) {
    this.f = deps.fetch ?? ((...a) => fetch(...a));
    this.wait = deps.sleep ?? sleep;
    this.maxRetries = deps.maxRetries ?? 4;
    this.maxRetryAfterMs = deps.maxRetryAfterMs ?? 30_000;
  }

  get<T>(path: string, opts: Omit<RequestOpts, "body"> = {}) {
    return this.request<T>("GET", path, opts);
  }
  post<T>(path: string, opts: RequestOpts = {}) {
    return this.request<T>("POST", path, opts);
  }
  put<T>(path: string, opts: RequestOpts = {}) {
    return this.request<T>("PUT", path, opts);
  }
  delete<T>(path: string, opts: RequestOpts = {}) {
    return this.request<T>("DELETE", path, opts);
  }

  static buildUrl(path: string, query?: Query) {
    const url = new URL(path.startsWith("http") ? path : API_BASE + path);
    if (query)
      for (const [k, v] of Object.entries(query)) {
        if (v !== undefined && v !== null && v !== "") url.searchParams.set(k, String(v));
      }
    return url.toString();
  }

  async request<T>(method: HttpMethod, path: string, opts: RequestOpts = {}): Promise<T> {
    const url = SpotifyClient.buildUrl(path, opts.query);
    const safe = method !== "POST" || !!opts.retryUnsafe;
    let refreshed = false;
    for (let attempt = 0; ; attempt++) {
      if (opts.signal?.aborted) throw new SpotifyApiError("aborted", "Request cancelled");
      let token: string;
      try {
        token = await this.deps.auth.getAccessToken();
      } catch (e) {
        throw new SpotifyApiError("unauthorized", e instanceof Error ? e.message : "Not signed in", 401);
      }
      let res: Response;
      try {
        res = await this.f(url, {
          method,
          signal: opts.signal,
          headers: {
            Authorization: `Bearer ${token}`,
            ...(opts.body !== undefined ? { "Content-Type": "application/json" } : {}),
          },
          body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
        });
      } catch (e) {
        if (isAbort(e) || opts.signal?.aborted) throw new SpotifyApiError("aborted", "Request cancelled");
        if (safe && attempt < this.maxRetries) {
          await this.wait(backoffDelay(attempt, 500, 15_000, this.deps.random), opts.signal);
          continue;
        }
        throw new SpotifyApiError("network", "Network request failed", null);
      }

      if (res.ok) {
        if (res.status === 204) return undefined as T;
        const text = await res.text();
        if (!text) return undefined as T;
        try {
          return JSON.parse(text) as T;
        } catch {
          return text as unknown as T;
        }
      }

      const payload = await readError(res);

      if (res.status === 401 && !refreshed) {
        refreshed = true;
        try {
          await this.deps.auth.refresh();
        } catch (e) {
          throw new SpotifyApiError("unauthorized", e instanceof Error ? e.message : "Session expired", 401);
        }
        attempt--; // a refresh is not a retry
        continue;
      }

      if (res.status === 429) {
        const retryAfterMs = parseRetryAfter(res.headers.get("Retry-After"));
        if (payload.reason === "QUOTA_EXCEEDED") {
          throw new SpotifyApiError("quota", payload.message, 429, payload.reason, retryAfterMs);
        }
        const waitMs = retryAfterMs ?? backoffDelay(attempt, 1000, 30_000, this.deps.random);
        if (attempt < this.maxRetries && waitMs <= this.maxRetryAfterMs) {
          this.deps.onRateLimit?.(waitMs);
          await this.wait(waitMs, opts.signal);
          continue;
        }
        throw new SpotifyApiError("rate_limited", payload.message, 429, payload.reason, waitMs);
      }

      if (res.status >= 500 && safe && attempt < this.maxRetries) {
        await this.wait(backoffDelay(attempt, 500, 15_000, this.deps.random), opts.signal);
        continue;
      }

      throw new SpotifyApiError(kindFor(res.status), payload.message, res.status, payload.reason);
    }
  }
}

function kindFor(status: number): ApiErrorKind {
  if (status === 401) return "unauthorized";
  if (status === 403) return "forbidden";
  if (status === 404) return "not_found";
  if (status === 409 || status === 412) return "conflict";
  if (status >= 500) return "server";
  return "bad_request";
}

export function parseRetryAfter(h: string | null): number | null {
  if (!h) return null;
  const secs = Number(h);
  if (Number.isFinite(secs)) return Math.max(0, secs * 1000);
  const date = Date.parse(h);
  return Number.isFinite(date) ? Math.max(0, date - Date.now()) : null;
}

async function readError(res: Response): Promise<{ message: string; reason: string | null }> {
  try {
    const j = (await res.json()) as { error?: { message?: string; reason?: string } | string; error_description?: string };
    if (typeof j.error === "object" && j.error) return { message: j.error.message ?? `HTTP ${res.status}`, reason: j.error.reason ?? null };
    return { message: j.error_description ?? String(j.error ?? `HTTP ${res.status}`), reason: null };
  } catch {
    return { message: `HTTP ${res.status}`, reason: null };
  }
}
