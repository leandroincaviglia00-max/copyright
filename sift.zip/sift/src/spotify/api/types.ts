/**
 * Response shapes for the Spotify Web API as of the February/March 2026
 * changes. Fields Spotify removed in Development Mode (popularity,
 * available_markets, linked_from, label, user.product/email/country…) are
 * intentionally absent. Deprecated-but-present fields are optional.
 */
export interface SpImage {
  url: string;
  width: number | null;
  height: number | null;
}
export interface ExternalUrls {
  spotify?: string;
}
export interface SpUser {
  id: string;
  display_name: string | null;
  images?: SpImage[];
  external_urls?: ExternalUrls;
  uri?: string;
}
export interface Paging<T> {
  href: string;
  items: T[];
  limit: number;
  next: string | null;
  offset: number;
  previous: string | null;
  total: number;
}
export interface SpArtistRef {
  id: string | null;
  name: string;
  uri: string;
  external_urls?: ExternalUrls;
}
export interface SpArtist extends SpArtistRef {
  /** Deprecated by Spotify; may be empty. Treat as optional enrichment. */
  genres?: string[];
  images?: SpImage[];
}
export interface SpAlbumRef {
  id: string | null;
  name: string;
  uri?: string;
  images: SpImage[];
  release_date?: string;
  release_date_precision?: "year" | "month" | "day";
  album_type?: string;
  total_tracks?: number;
  external_urls?: ExternalUrls;
  artists?: SpArtistRef[];
}
export interface SpTrack {
  type: "track";
  id: string | null;
  uri: string;
  name: string;
  duration_ms: number;
  explicit?: boolean;
  is_local?: boolean;
  is_playable?: boolean;
  preview_url?: string | null;
  external_urls?: ExternalUrls;
  external_ids?: { isrc?: string };
  album: SpAlbumRef;
  artists: SpArtistRef[];
  track_number?: number;
  disc_number?: number;
}
export interface SpEpisode {
  type: "episode";
  id: string;
  uri: string;
  name: string;
  duration_ms: number;
  explicit?: boolean;
  images?: SpImage[];
  release_date?: string;
  external_urls?: ExternalUrls;
  show?: { name: string; images?: SpImage[] };
}
/** Unknown future item types are preserved but never acted on. */
export interface SpUnknownItem {
  type: string;
  uri?: string;
  name?: string;
}
export type SpPlaylistEntity = SpTrack | SpEpisode | SpUnknownItem;

export interface SpPlaylistItem {
  added_at: string | null;
  added_by?: { id: string } | null;
  is_local: boolean;
  /** Renamed from `track` in Feb 2026. `track` is read only as a fallback. */
  item?: SpPlaylistEntity | null;
  track?: SpPlaylistEntity | null;
}

export interface SpPlaylist {
  id: string;
  name: string;
  description?: string | null;
  collaborative: boolean;
  public: boolean | null;
  snapshot_id: string;
  images: SpImage[] | null;
  owner: SpUser;
  external_urls?: ExternalUrls;
  uri: string;
  /** Renamed from `tracks` in Feb 2026. */
  items?: { href?: string; total: number } | null;
  tracks?: { href?: string; total: number } | null;
}

export interface SpSnapshot {
  snapshot_id: string;
}

export interface SpDevice {
  id: string | null;
  is_active: boolean;
  is_restricted: boolean;
  name: string;
  type: string;
  volume_percent: number | null;
}

export interface SpPlaybackState {
  device: SpDevice;
  is_playing: boolean;
  progress_ms: number | null;
  item: SpTrack | SpEpisode | null;
}

export interface SpPlayHistory {
  played_at: string;
  track: SpTrack;
}
export interface SpCursorPaging<T> {
  items: T[];
  next: string | null;
  cursors?: { after?: string; before?: string } | null;
  limit: number;
}
