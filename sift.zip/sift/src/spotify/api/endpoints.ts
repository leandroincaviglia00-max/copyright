/**
 * Thin, typed wrappers over the CURRENT Spotify Web API (verified against the
 * Feb 2026 changelog + migration guide, Mar 2026 reverts, Jul 2026 quota
 * update). Notably:
 *  - playlist contents use /playlists/{id}/items (never /tracks)
 *  - DELETE body is { items: [{ uri }] } (renamed from `tracks`)
 *  - playlist creation is POST /me/playlists (not /users/{id}/playlists)
 *  - search `limit` max is 10
 *  - no batch GET /tracks|/artists|/albums; single-entity fetches only
 */
import { chunk } from "../../lib/async";
import type { SpotifyClient } from "./client";
import type {
  Paging,
  SpArtist,
  SpAlbumRef,
  SpCursorPaging,
  SpDevice,
  SpPlayHistory,
  SpPlaybackState,
  SpPlaylist,
  SpPlaylistItem,
  SpSnapshot,
  SpTrack,
  SpUser,
} from "./types";

export const LIMITS = {
  playlistItemsPage: 50,
  playlistsPage: 50,
  mutateBatch: 100,
  searchPage: 10,
  artistAlbumsPage: 10,
  albumTracksPage: 50,
} as const;

export const ITEM_FIELDS =
  "total,limit,offset,next,items(added_at,added_by(id),is_local," +
  "item(type,id,uri,name,duration_ms,explicit,is_local,is_playable,preview_url,external_urls,external_ids," +
  "album(id,name,uri,images,release_date,release_date_precision,external_urls),artists(id,name,uri,external_urls)," +
  "images,release_date,show(name,images)))";

export class SpotifyApi {
  constructor(readonly c: SpotifyClient) {}

  me(signal?: AbortSignal) {
    return this.c.get<SpUser>("/me", { signal });
  }

  // ── Playlists ────────────────────────────────────────────────
  myPlaylistsPage(offset = 0, signal?: AbortSignal) {
    return this.c.get<Paging<SpPlaylist>>("/me/playlists", { query: { limit: LIMITS.playlistsPage, offset }, signal });
  }

  async allMyPlaylists(signal?: AbortSignal): Promise<SpPlaylist[]> {
    const first = await this.myPlaylistsPage(0, signal);
    const out = [...first.items];
    for (let off = first.items.length; off < first.total; off += LIMITS.playlistsPage) {
      const p = await this.myPlaylistsPage(off, signal);
      out.push(...p.items);
      if (!p.items.length) break;
    }
    return out.filter(Boolean);
  }

  /** Cheap metadata fetch; used for snapshot / external-change checks. */
  playlistMeta(id: string, signal?: AbortSignal) {
    return this.c.get<Pick<SpPlaylist, "id" | "name" | "snapshot_id" | "owner" | "collaborative" | "public" | "images" | "items" | "external_urls" | "uri" | "description">>(
      `/playlists/${encodeURIComponent(id)}`,
      { query: { fields: "id,name,description,snapshot_id,owner(id,display_name),collaborative,public,images,external_urls,uri,items(total)" }, signal },
    );
  }

  playlistItemsPage(id: string, offset: number, signal?: AbortSignal, fields = ITEM_FIELDS) {
    return this.c.get<Paging<SpPlaylistItem>>(`/playlists/${encodeURIComponent(id)}/items`, {
      query: { limit: LIMITS.playlistItemsPage, offset, additional_types: "track,episode", fields },
      signal,
    });
  }

  addItems(id: string, uris: string[], position?: number) {
    if (uris.length > LIMITS.mutateBatch) throw new RangeError("max 100 uris per request");
    return this.c.post<SpSnapshot>(`/playlists/${encodeURIComponent(id)}/items`, {
      body: position === undefined ? { uris } : { uris, position },
    });
  }

  removeItems(id: string, uris: string[], snapshotId?: string) {
    if (uris.length > LIMITS.mutateBatch) throw new RangeError("max 100 uris per request");
    return this.c.delete<SpSnapshot>(`/playlists/${encodeURIComponent(id)}/items`, {
      body: { items: uris.map((uri) => ({ uri })), ...(snapshotId ? { snapshot_id: snapshotId } : {}) },
    });
  }

  createPlaylist(input: { name: string; description?: string; public: boolean }) {
    return this.c.post<SpPlaylist>("/me/playlists", {
      body: { name: input.name, description: input.description ?? "", public: input.public, collaborative: false },
    });
  }

  // ── Catalog ─────────────────────────────────────────────────
  searchTracks(q: string, offset = 0, signal?: AbortSignal) {
    return this.c.get<{ tracks: Paging<SpTrack> }>("/search", {
      query: { q, type: "track", limit: LIMITS.searchPage, offset },
      signal,
    });
  }
  artist(id: string, signal?: AbortSignal) {
    return this.c.get<SpArtist>(`/artists/${encodeURIComponent(id)}`, { signal });
  }
  artistAlbums(id: string, offset = 0, signal?: AbortSignal) {
    return this.c.get<Paging<SpAlbumRef>>(`/artists/${encodeURIComponent(id)}/albums`, {
      query: { include_groups: "album,single", limit: LIMITS.artistAlbumsPage, offset },
      signal,
    });
  }
  albumTracks(id: string, signal?: AbortSignal) {
    return this.c.get<Paging<Omit<SpTrack, "album">>>(`/albums/${encodeURIComponent(id)}/tracks`, {
      query: { limit: LIMITS.albumTracksPage },
      signal,
    });
  }

  // ── Listening history (opt-in scopes) ────────────────────────
  recentlyPlayed(signal?: AbortSignal) {
    return this.c.get<SpCursorPaging<SpPlayHistory>>("/me/player/recently-played", { query: { limit: 50 }, signal });
  }
  topArtists(range: "short_term" | "medium_term" | "long_term", signal?: AbortSignal) {
    return this.c.get<Paging<SpArtist>>("/me/top/artists", { query: { time_range: range, limit: 50 }, signal });
  }
  topTracks(range: "short_term" | "medium_term" | "long_term", signal?: AbortSignal) {
    return this.c.get<Paging<SpTrack>>("/me/top/tracks", { query: { time_range: range, limit: 50 }, signal });
  }

  // ── Player ──────────────────────────────────────────────────
  playbackState() {
    return this.c.get<SpPlaybackState | undefined>("/me/player");
  }
  devices() {
    return this.c.get<{ devices: SpDevice[] }>("/me/player/devices");
  }
  transfer(deviceId: string, play = false) {
    return this.c.put<void>("/me/player", { body: { device_ids: [deviceId], play } });
  }
  play(deviceId: string | null, uri: string, positionMs = 0) {
    return this.c.put<void>("/me/player/play", {
      query: deviceId ? { device_id: deviceId } : undefined,
      body: { uris: [uri], position_ms: Math.max(0, Math.round(positionMs)) },
    });
  }
  pause(deviceId?: string | null) {
    return this.c.put<void>("/me/player/pause", { query: deviceId ? { device_id: deviceId } : undefined });
  }
  resume(deviceId?: string | null) {
    return this.c.put<void>("/me/player/play", { query: deviceId ? { device_id: deviceId } : undefined });
  }
  seek(positionMs: number, deviceId?: string | null) {
    return this.c.put<void>("/me/player/seek", { query: { position_ms: Math.round(positionMs), device_id: deviceId ?? undefined } });
  }
}

export { chunk };
