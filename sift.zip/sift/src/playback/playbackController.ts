/**
 * One place that decides HOW a song is heard:
 *   1. "full"    – Spotify Web Playback SDK in this tab (Premium)
 *   2. "remote"  – another Spotify Connect device the user picked
 *   3. "preview" – Spotify-hosted 30 s preview_url, streamed (never stored)
 *   4. "none"    – nothing playable here → Open in Spotify
 * Audio is only ever streamed by Spotify's own player or the browser's
 * <audio> element pointing at Spotify's URL. Nothing is downloaded or cached.
 */
import { Emitter } from "../lib/emitter";
import type { SpotifyApi } from "../spotify/api/endpoints";
import { SpotifyApiError } from "../spotify/api/errors";
import { loadSdk } from "./sdkLoader";

export type PlayMode = "full" | "remote" | "preview" | "none";
export type SdkStatus = "off" | "loading" | "ready" | "not_premium" | "auth_error" | "unsupported" | "error";

export interface PlayableTrack {
  uri: string | null;
  previewUrl: string | null;
  durationMs: number;
  name: string;
}

export interface PlaybackSnapshot {
  mode: PlayMode;
  playing: boolean;
  loading: boolean;
  uri: string | null;
  positionMs: number;
  durationMs: number;
  sdk: SdkStatus;
  sdkDeviceId: string | null;
  device: { id: string; name: string; type: string } | null;
  message: string | null;
  /** browsers need one real user gesture before audio can start */
  unlocked: boolean;
}

const initial: PlaybackSnapshot = {
  mode: "none",
  playing: false,
  loading: false,
  uri: null,
  positionMs: 0,
  durationMs: 0,
  sdk: "off",
  sdkDeviceId: null,
  device: null,
  message: null,
  unlocked: false,
};

export class PlaybackController {
  readonly changes = new Emitter<PlaybackSnapshot>();
  private s: PlaybackSnapshot = initial;
  private player: Spotify.Player | null = null;
  private audio: HTMLAudioElement | null = null;
  private poll: ReturnType<typeof setInterval> | null = null;
  private remoteDevice: { id: string; name: string; type: string } | null = null;
  private reqId = 0;

  constructor(private api: SpotifyApi, private getToken: () => Promise<string>, private playerName: string) {}

  get snapshot() {
    return this.s;
  }
  private set(p: Partial<PlaybackSnapshot>) {
    this.s = { ...this.s, ...p };
    this.changes.emit(this.s);
  }

  /** Must be called from a user gesture (tap/click/keypress). */
  async unlock() {
    if (this.s.unlocked) return;
    this.set({ unlocked: true });
    try {
      await this.player?.activateElement();
    } catch {
      /* not all browsers need it */
    }
  }

  async connectSdk(): Promise<void> {
    if (this.player || this.s.sdk === "loading") return;
    if (typeof window === "undefined" || !("MediaSource" in window) || !navigator.requestMediaKeySystemAccess) {
      this.set({ sdk: "unsupported", message: "This browser can't run the Spotify player (needs EME/DRM support). Previews still work." });
      return;
    }
    this.set({ sdk: "loading" });
    try {
      await loadSdk();
    } catch (e) {
      this.set({ sdk: "error", message: (e as Error).message });
      return;
    }
    const player = new window.Spotify!.Player({
      name: this.playerName,
      getOAuthToken: (cb) => void this.getToken().then(cb, () => this.set({ sdk: "auth_error" })),
      volume: 0.8,
    });
    player.addListener("ready", ({ device_id }) => this.set({ sdk: "ready", sdkDeviceId: device_id, message: null }));
    player.addListener("not_ready", () => this.set({ sdk: "error", sdkDeviceId: null, message: "The in-browser player went offline. Reconnecting…" }));
    player.addListener("initialization_error", (e) => this.set({ sdk: "unsupported", message: `Spotify player unavailable: ${e.message}` }));
    player.addListener("authentication_error", () => this.set({ sdk: "auth_error", message: "The Spotify player couldn't authenticate. Sign out and back in." }));
    player.addListener("account_error", () =>
      this.set({ sdk: "not_premium", message: "Full-track playback needs Spotify Premium on this account. Using previews instead." }),
    );
    player.addListener("playback_error", (e) => this.set({ loading: false, message: `Playback error: ${e.message}` }));
    player.addListener("autoplay_failed", () => this.set({ playing: false, loading: false, message: "Your browser blocked autoplay. Tap play." }));
    player.addListener("player_state_changed", (st) => {
      if (this.s.mode !== "full") return;
      if (!st) return this.set({ playing: false });
      this.set({
        playing: !st.paused,
        loading: false,
        positionMs: st.position,
        durationMs: st.duration || this.s.durationMs,
        uri: st.track_window.current_track?.uri ?? this.s.uri,
      });
    });
    this.player = player;
    const ok = await player.connect();
    if (!ok) this.set({ sdk: "error", message: "Couldn't start the Spotify player." });
  }

  useRemoteDevice(d: { id: string; name: string; type: string } | null) {
    this.remoteDevice = d;
    this.set({ device: d });
  }

  async listDevices() {
    const r = await this.api.devices();
    return r.devices.filter((d) => d.id && !d.is_restricted);
  }

  /** Decide the best available mode for a track. */
  modeFor(t: PlayableTrack): PlayMode {
    if (t.uri && !t.uri.startsWith("spotify:local:")) {
      if (this.remoteDevice) return "remote";
      if (this.s.sdk === "ready" && this.s.sdkDeviceId) return "full";
    }
    return t.previewUrl ? "preview" : "none";
  }

  async play(t: PlayableTrack, startFraction = 0) {
    const id = ++this.reqId;
    await this.stopPreview();
    const mode = this.modeFor(t);
    const startAt = Math.floor(t.durationMs * startFraction);
    this.set({ mode, uri: t.uri, loading: mode !== "none", playing: false, positionMs: startAt, durationMs: mode === "preview" ? 30_000 : t.durationMs, message: null });
    if (mode === "none") {
      this.set({ message: t.uri?.startsWith("spotify:local:") ? "Local files only play inside the Spotify app." : "No preview for this song. Connect Premium playback or open it in Spotify." });
      return;
    }
    if (mode === "preview") return this.playPreview(t.previewUrl!, id);
    const deviceId = mode === "full" ? this.s.sdkDeviceId : this.remoteDevice!.id;
    try {
      await this.api.play(deviceId, t.uri!, startAt);
      if (id !== this.reqId) return;
      if (mode === "full") this.set({ device: { id: deviceId!, name: this.playerName, type: "Browser" } });
      else this.set({ playing: true, loading: false });
      this.startPolling();
    } catch (e) {
      if (id !== this.reqId) return;
      if (e instanceof SpotifyApiError && e.kind === "not_found" && mode === "full") {
        // SDK device vanished (tab slept, network blip): reconnect once.
        this.player?.disconnect();
        this.player = null;
        this.set({ sdk: "off", sdkDeviceId: null });
        await this.connectSdk();
        return;
      }
      if (e instanceof SpotifyApiError && e.kind === "forbidden") {
        this.set({ sdk: mode === "full" ? "not_premium" : this.s.sdk, message: "Spotify refused playback (Premium required or device restricted)." });
      } else if (e instanceof SpotifyApiError && e.kind === "not_found") {
        this.remoteDevice = null;
        this.set({ device: null, message: "That Spotify device is no longer available." });
      } else {
        this.set({ message: "Couldn't start playback on Spotify." });
      }
      if (t.previewUrl) return this.playPreview(t.previewUrl, id);
      this.set({ mode: "none", loading: false, playing: false });
    }
  }

  private async playPreview(url: string, id: number) {
    if (!this.audio) {
      this.audio = new Audio();
      this.audio.preload = "none";
      this.audio.addEventListener("timeupdate", () => this.s.mode === "preview" && this.set({ positionMs: (this.audio!.currentTime || 0) * 1000 }));
      this.audio.addEventListener("ended", () => this.set({ playing: false }));
      this.audio.addEventListener("pause", () => this.s.mode === "preview" && this.set({ playing: false }));
      this.audio.addEventListener("playing", () => this.s.mode === "preview" && this.set({ playing: true, loading: false }));
    }
    this.audio.src = url;
    this.set({ mode: "preview", durationMs: 30_000 });
    try {
      await this.audio.play();
    } catch {
      if (id === this.reqId) this.set({ playing: false, loading: false, message: "Tap play to start the preview (browser autoplay rules)." });
    }
  }

  private async stopPreview() {
    if (this.audio && !this.audio.paused) this.audio.pause();
  }

  async toggle() {
    const m = this.s.mode;
    if (m === "preview" && this.audio) {
      if (this.audio.paused) await this.audio.play().catch(() => undefined);
      else this.audio.pause();
    } else if (m === "full" && this.player) {
      await this.player.togglePlay();
    } else if (m === "remote" && this.remoteDevice) {
      if (this.s.playing) await this.api.pause(this.remoteDevice.id).catch(() => undefined);
      else await this.api.resume(this.remoteDevice.id).catch(() => undefined);
      this.set({ playing: !this.s.playing });
    }
  }

  async pause() {
    if (this.s.mode === "preview") this.audio?.pause();
    else if (this.s.mode === "full") await this.player?.pause().catch(() => undefined);
    else if (this.s.mode === "remote" && this.remoteDevice && this.s.playing) await this.api.pause(this.remoteDevice.id).catch(() => undefined);
    this.set({ playing: false });
  }

  async seek(ms: number) {
    if (this.s.mode === "preview" && this.audio) this.audio.currentTime = ms / 1000;
    else if (this.s.mode === "full") await this.player?.seek(ms);
    else if (this.s.mode === "remote" && this.remoteDevice) await this.api.seek(ms, this.remoteDevice.id).catch(() => undefined);
    this.set({ positionMs: ms });
  }

  private startPolling() {
    if (this.poll) return;
    this.poll = setInterval(async () => {
      if (!this.s.playing) return;
      if (this.s.mode === "full") {
        const st = await this.player?.getCurrentState();
        if (st) this.set({ positionMs: st.position, playing: !st.paused });
      } else if (this.s.mode === "remote") {
        this.set({ positionMs: Math.min(this.s.durationMs, this.s.positionMs + 1000) });
      }
    }, 1000);
  }

  dispose() {
    if (this.poll) clearInterval(this.poll);
    this.poll = null;
    this.audio?.pause();
    this.audio = null;
    this.player?.disconnect();
    this.player = null;
  }
}
