const SDK_URL = "https://sdk.scdn.co/spotify-player.js";
let loading: Promise<void> | null = null;

/** Injects the official Web Playback SDK once. */
export function loadSdk(timeoutMs = 15_000): Promise<void> {
  if (typeof window === "undefined") return Promise.reject(new Error("No window"));
  if (window.Spotify?.Player) return Promise.resolve();
  if (loading) return loading;
  loading = new Promise<void>((resolve, reject) => {
    const t = setTimeout(() => reject(new Error("The Spotify player took too long to load.")), timeoutMs);
    window.onSpotifyWebPlaybackSDKReady = () => {
      clearTimeout(t);
      resolve();
    };
    const s = document.createElement("script");
    s.src = SDK_URL;
    s.async = true;
    s.onerror = () => {
      clearTimeout(t);
      loading = null;
      reject(new Error("Couldn't load the Spotify player (blocked by an extension or network?)."));
    };
    document.head.appendChild(s);
  });
  return loading;
}
