/** Minimal typings for the Spotify Web Playback SDK (https://sdk.scdn.co/spotify-player.js). */
declare namespace Spotify {
  interface PlayerInit {
    name: string;
    getOAuthToken: (cb: (token: string) => void) => void;
    volume?: number;
    enableMediaSession?: boolean;
  }
  interface Error {
    message: string;
  }
  interface WebPlaybackTrack {
    uri: string;
    id: string | null;
    name: string;
    duration_ms: number;
  }
  interface PlaybackState {
    paused: boolean;
    position: number;
    duration: number;
    track_window: { current_track: WebPlaybackTrack | null };
  }
  interface ReadyEvent {
    device_id: string;
  }
  class Player {
    constructor(init: PlayerInit);
    connect(): Promise<boolean>;
    disconnect(): void;
    addListener(e: "ready" | "not_ready", cb: (d: ReadyEvent) => void): boolean;
    addListener(e: "player_state_changed", cb: (s: PlaybackState | null) => void): boolean;
    addListener(
      e: "initialization_error" | "authentication_error" | "account_error" | "playback_error" | "autoplay_failed",
      cb: (err: Error) => void,
    ): boolean;
    getCurrentState(): Promise<PlaybackState | null>;
    pause(): Promise<void>;
    resume(): Promise<void>;
    togglePlay(): Promise<void>;
    seek(ms: number): Promise<void>;
    setVolume(v: number): Promise<void>;
    activateElement(): Promise<void>;
  }
}
interface Window {
  onSpotifyWebPlaybackSDKReady?: () => void;
  Spotify?: typeof Spotify;
}
