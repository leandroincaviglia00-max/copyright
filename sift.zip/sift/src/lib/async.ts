export const sleep = (ms: number, signal?: AbortSignal) =>
  new Promise<void>((resolve, reject) => {
    if (signal?.aborted) return reject(abortError());
    const t = setTimeout(() => {
      signal?.removeEventListener("abort", onAbort);
      resolve();
    }, ms);
    const onAbort = () => {
      clearTimeout(t);
      reject(abortError());
    };
    signal?.addEventListener("abort", onAbort, { once: true });
  });

export function abortError() {
  try {
    return new DOMException("Aborted", "AbortError");
  } catch {
    const e = new Error("Aborted");
    e.name = "AbortError";
    return e;
  }
}

export const isAbort = (e: unknown) => e instanceof Error && e.name === "AbortError";

/** Exponential backoff with full jitter. attempt starts at 0. */
export function backoffDelay(attempt: number, baseMs = 500, capMs = 15_000, rand = Math.random) {
  const exp = Math.min(capMs, baseMs * 2 ** attempt);
  return Math.round(exp / 2 + rand() * (exp / 2));
}

/** Run async jobs with bounded concurrency, preserving result order. */
export async function mapLimit<T, R>(items: T[], limit: number, fn: (item: T, i: number) => Promise<R>): Promise<R[]> {
  const out = new Array<R>(items.length);
  let next = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (next < items.length) {
      const i = next++;
      out[i] = await fn(items[i], i);
    }
  });
  await Promise.all(workers);
  return out;
}

export function chunk<T>(arr: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

export function debounce<A extends unknown[]>(fn: (...a: A) => void, ms: number) {
  let t: ReturnType<typeof setTimeout> | null = null;
  let lastArgs: A | null = null;
  const d = (...a: A) => {
    lastArgs = a;
    if (t) clearTimeout(t);
    t = setTimeout(() => {
      t = null;
      fn(...(lastArgs as A));
    }, ms);
  };
  d.flush = () => {
    if (t) {
      clearTimeout(t);
      t = null;
      fn(...(lastArgs as A));
    }
  };
  return d;
}

export const uid = () =>
  typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : Math.random().toString(36).slice(2) + Date.now().toString(36);
