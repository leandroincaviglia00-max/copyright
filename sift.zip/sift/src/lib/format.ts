export const fmtNum = (n: number) => n.toLocaleString("en-US");

export function fmtDuration(ms: number) {
  if (!Number.isFinite(ms) || ms <= 0) return "–:––";
  const s = Math.round(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = String(s % 60).padStart(2, "0");
  return h ? `${h}:${String(m).padStart(2, "0")}:${sec}` : `${m}:${sec}`;
}

export function fmtTime(ts: number) {
  return new Date(ts).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
}

export function fmtRelative(ts: number, now = Date.now()) {
  const d = Math.round((now - ts) / 1000);
  if (d < 45) return "just now";
  if (d < 3600) return `${Math.round(d / 60)} min ago`;
  if (d < 86400) return `${Math.round(d / 3600)} h ago`;
  const days = Math.round(d / 86400);
  if (days < 45) return `${days} d ago`;
  return new Date(ts).toLocaleDateString(undefined, { month: "short", year: "numeric" });
}

export const plural = (n: number, one: string, many = one + "s") => `${fmtNum(n)} ${n === 1 ? one : many}`;

export function decadeOf(year: number | null) {
  return year ? `${Math.floor(year / 10) * 10}s` : null;
}

export function normalizeTitle(s: string) {
  return s
    .toLowerCase()
    .replace(/\s*[-–(\[].*?(remaster|version|mix|edit|live|mono|stereo).*?([)\]]|$)/g, "")
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();
}
