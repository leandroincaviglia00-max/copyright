/** Typed, validated access to build-time configuration. No secrets live here. */
export interface AppConfig {
  clientId: string;
  redirectUri: string;
  playerName: string;
}

export class ConfigError extends Error {}

type EnvLike = Record<string, string | undefined>;

export function readConfig(env: EnvLike): AppConfig {
  const clientId = (env.VITE_SPOTIFY_CLIENT_ID ?? "").trim();
  const redirectUri = (env.VITE_SPOTIFY_REDIRECT_URI ?? "").trim();
  const missing: string[] = [];
  if (!clientId) missing.push("VITE_SPOTIFY_CLIENT_ID");
  if (!redirectUri) missing.push("VITE_SPOTIFY_REDIRECT_URI");
  if (missing.length) {
    throw new ConfigError(`Missing ${missing.join(" and ")}. Copy .env.example to .env.local and fill it in.`);
  }
  if (/\/\/localhost[:/]/.test(redirectUri)) {
    throw new ConfigError("Spotify no longer accepts 'localhost' redirect URIs. Use http://127.0.0.1:5173/callback instead.");
  }
  return { clientId, redirectUri, playerName: (env.VITE_PLAYER_NAME ?? "Sift Web Player").trim() };
}

let cached: AppConfig | null = null;
export function config(): AppConfig {
  if (!cached) cached = readConfig(import.meta.env as unknown as EnvLike);
  return cached;
}
