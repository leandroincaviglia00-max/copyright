/** Minimal async key-value store. IndexedDB in the browser, memory in tests. */
export interface KV {
  get<T>(key: string): Promise<T | undefined>;
  set<T>(key: string, value: T): Promise<void>;
  del(key: string): Promise<void>;
  keys(prefix?: string): Promise<string[]>;
}

export class MemoryKV implements KV {
  private m = new Map<string, string>();
  async get<T>(key: string) {
    const v = this.m.get(key);
    return v === undefined ? undefined : (JSON.parse(v) as T);
  }
  async set<T>(key: string, value: T) {
    this.m.set(key, JSON.stringify(value));
  }
  async del(key: string) {
    this.m.delete(key);
  }
  async keys(prefix = "") {
    return [...this.m.keys()].filter((k) => k.startsWith(prefix));
  }
}

export class IndexedDbKV implements KV {
  private dbp: Promise<IDBDatabase>;
  constructor(name = "sift", private store = "kv") {
    this.dbp = new Promise((resolve, reject) => {
      const req = indexedDB.open(name, 1);
      req.onupgradeneeded = () => req.result.createObjectStore(store);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  private async tx<R>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<R>): Promise<R> {
    const db = await this.dbp;
    return new Promise<R>((resolve, reject) => {
      const t = db.transaction(this.store, mode);
      const r = fn(t.objectStore(this.store));
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  }
  get<T>(key: string) {
    return this.tx<T | undefined>("readonly", (s) => s.get(key) as IDBRequest<T | undefined>);
  }
  async set<T>(key: string, value: T) {
    await this.tx("readwrite", (s) => s.put(value, key));
  }
  async del(key: string) {
    await this.tx("readwrite", (s) => s.delete(key));
  }
  async keys(prefix = "") {
    const all = (await this.tx("readonly", (s) => s.getAllKeys())) as IDBValidKey[];
    return all.map(String).filter((k) => k.startsWith(prefix));
  }
}

export function createKV(): KV {
  try {
    if (typeof indexedDB !== "undefined") return new IndexedDbKV();
  } catch {
    /* private mode etc. */
  }
  return new MemoryKV();
}
