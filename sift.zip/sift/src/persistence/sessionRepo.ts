import { debounce } from "../lib/async";
import type { ApplyJournal } from "../review/applyPlanner";
import type { ReviewSession } from "../review/types";
import type { KV } from "./kv";

const S = (id: string) => `session.${id}`;
const J = (playlistId: string) => `journal.${playlistId}`;
const LAST_APPLIED = (playlistId: string) => `applied.${playlistId}`;

export interface SessionIndexEntry {
  id: string;
  playlistId: string;
  playlistName: string;
  playlistImage: string | null;
  updatedAt: number;
  total: number;
  decided: number;
  status: ReviewSession["status"];
}

export class SessionRepo {
  constructor(private kv: KV) {}

  async save(s: ReviewSession) {
    await this.kv.set(S(s.id), s);
  }
  load(id: string) {
    return this.kv.get<ReviewSession>(S(id));
  }
  async remove(id: string) {
    await this.kv.del(S(id));
  }
  async list(): Promise<SessionIndexEntry[]> {
    const keys = await this.kv.keys("session.");
    const all = (await Promise.all(keys.map((k) => this.kv.get<ReviewSession>(k)))).filter(Boolean) as ReviewSession[];
    return all
      .map((s) => ({
        id: s.id,
        playlistId: s.playlistId,
        playlistName: s.playlistName,
        playlistImage: s.playlistImage,
        updatedAt: s.updatedAt,
        total: s.order.length,
        decided: Object.keys(s.decisions).length,
        status: s.status,
      }))
      .sort((a, b) => b.updatedAt - a.updatedAt);
  }
  async latestFor(playlistId: string): Promise<ReviewSession | undefined> {
    const idx = (await this.list()).find((e) => e.playlistId === playlistId && e.status !== "applied");
    return idx ? this.load(idx.id) : undefined;
  }

  saveJournal(j: ApplyJournal) {
    return this.kv.set(J(j.playlistId), j);
  }
  loadJournal(playlistId: string) {
    return this.kv.get<ApplyJournal>(J(playlistId));
  }
  clearJournal(playlistId: string) {
    return this.kv.del(J(playlistId));
  }
  saveLastApplied(j: ApplyJournal) {
    return this.kv.set(LAST_APPLIED(j.playlistId), j);
  }
  loadLastApplied(playlistId: string) {
    return this.kv.get<ApplyJournal>(LAST_APPLIED(playlistId));
  }

  /** Coalesces rapid swipes into one write; flush on pagehide. */
  writer(ms = 300) {
    return debounce((s: ReviewSession) => void this.save(s), ms);
  }
}

// ── Export / import ─────────────────────────────────────────────
export interface SessionExport {
  app: "sift";
  kind: "review-session";
  version: 1;
  exportedAt: string;
  session: ReviewSession;
}

export function exportSession(s: ReviewSession, now = new Date()): SessionExport {
  return { app: "sift", kind: "review-session", version: 1, exportedAt: now.toISOString(), session: s };
}

export class ImportError extends Error {}

export function parseImport(text: string): ReviewSession {
  let j: unknown;
  try {
    j = JSON.parse(text);
  } catch {
    throw new ImportError("That file isn't valid JSON.");
  }
  const x = j as Partial<SessionExport>;
  if (x?.app !== "sift" || x.kind !== "review-session" || x.version !== 1 || !x.session) {
    throw new ImportError("That file isn't a Sift session export.");
  }
  const s = x.session;
  if (!s.playlistId || !Array.isArray(s.order) || typeof s.decisions !== "object" || typeof s.entries !== "object") {
    throw new ImportError("The session in that file is incomplete.");
  }
  for (const [k, d] of Object.entries(s.decisions)) {
    if (!(k in s.entries)) throw new ImportError("The session references songs it doesn't contain.");
    if (!["keep", "remove", "move"].includes((d as { kind: string }).kind)) throw new ImportError("Unknown decision type in file.");
  }
  return { ...s, history: s.history ?? [], future: s.future ?? [], skips: s.skips ?? {}, pendingPlaylists: s.pendingPlaylists ?? [] };
}

export function downloadJson(filename: string, data: unknown) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
