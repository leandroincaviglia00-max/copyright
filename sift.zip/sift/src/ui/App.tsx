import { useEffect, type ReactElement } from "react";
import { useApp } from "../state/appStore";
import { navigate, useRoute } from "../state/router";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { Toasts } from "./components/Toasts";
import { Callback } from "./screens/Callback";
import { Discover } from "./screens/Discover";
import { Home } from "./screens/Home";
import { Library } from "./screens/Library";
import { Review } from "./screens/Review";
import { Sessions } from "./screens/Sessions";
import { Stats } from "./screens/Stats";
import { Summary } from "./screens/Summary";

export function App() {
  const route = useRoute();
  const auth = useApp((s) => s.auth);
  const theme = useApp((s) => s.settings.theme);
  const rl = useApp((s) => s.rateLimitedUntil);

  useEffect(() => {
    if (route.name !== "callback") void useApp.getState().boot();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);
  useEffect(() => {
    if (auth === "signed_in" && route.name === "home") navigate("/library", true);
  }, [auth, route.name]);

  let body: ReactElement;
  if (route.name === "callback") body = <Callback />;
  else if (auth === "unknown") body = <div className="loading-screen"><div className="spinner" style={{ margin: "0 auto" }} /></div>;
  else if (auth !== "signed_in") body = <Home expired={auth === "expired"} />;
  else
    switch (route.name) {
      case "review": body = <div className="page"><Review id={route.id} /></div>; break;
      case "summary": body = <div className="page"><Summary id={route.id} /></div>; break;
      case "discover": body = route.id ? <div className="page"><Discover id={route.id} /></div> : <Discover />; break;
      case "stats": body = <Stats />; break;
      case "sessions": body = <Sessions />; break;
      default: body = <Library />;
    }

  return (
    <ErrorBoundary>
      <div className="app">
        <div className="ambient" aria-hidden="true" />
        {rl && rl > Date.now() && <div className="banner" style={{ position: "fixed", top: 10, left: "50%", translate: "-50% 0", zIndex: 50 }}>Spotify asked us to slow down. Retrying automatically…</div>}
        {body}
        <Toasts />
      </div>
    </ErrorBoundary>
  );
}
