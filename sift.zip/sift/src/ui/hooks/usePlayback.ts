import { useSyncExternalStore } from "react";
import { services } from "../../state/services";

export function usePlayback() {
  const pc = services().playback;
  return useSyncExternalStore(
    (l) => pc.changes.on(l) as unknown as () => void,
    () => pc.snapshot,
  );
}
