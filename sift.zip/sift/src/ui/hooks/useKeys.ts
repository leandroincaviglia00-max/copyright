import { useEffect, useRef } from "react";

/** Global shortcuts, ignored while typing or when a dialog is open. */
export function useKeys(map: Record<string, (e: KeyboardEvent) => void>, enabled = true) {
  const ref = useRef(map);
  ref.current = map;
  useEffect(() => {
    if (!enabled) return;
    const h = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (t.closest("input,textarea,select,[role=dialog]") || e.metaKey || e.ctrlKey || e.altKey) return;
      const k = (e.shiftKey && e.key.length === 1 ? "Shift+" : "") + (e.key.length === 1 ? e.key.toLowerCase() : e.key);
      const fn = ref.current[k];
      if (fn) {
        e.preventDefault();
        fn(e);
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [enabled]);
}
