/**
 * Pointer-driven card physics. Writes transforms + CSS vars directly to the
 * element (no React re-render per frame), flings with the release velocity,
 * springs back when the gesture doesn't commit.
 */
import { useCallback, useEffect, useRef } from "react";

export type SwipeDir = "left" | "right" | "up";

interface Opts {
  onCommit: (dir: SwipeDir) => void;
  onDragStart?: () => void;
  enabled?: boolean;
  allowUp?: boolean;
  allowLeft?: boolean;
}

export function useSwipe<T extends HTMLElement>({ onCommit, onDragStart, enabled = true, allowUp = true, allowLeft = true }: Opts) {
  const ref = useRef<T>(null);
  const st = useRef({ active: false, id: -1, x0: 0, y0: 0, dx: 0, dy: 0, vx: 0, vy: 0, t: 0, lx: 0, ly: 0, flinging: false });
  const commitRef = useRef(onCommit);
  commitRef.current = onCommit;

  const paint = useCallback((dx: number, dy: number, lifted: boolean) => {
    const el = ref.current;
    if (!el) return;
    const w = el.offsetWidth || 360;
    const rot = Math.max(-18, Math.min(18, (dx / w) * 22));
    el.style.transform = `translate3d(${dx}px, ${dy}px, 0) rotate(${rot}deg) scale(${lifted ? 1.02 : 1})`;
    const th = w * 0.32;
    const horiz = Math.abs(dx) >= Math.abs(dy) * 0.8;
    const s = (v: number) => Math.max(0, Math.min(1, v)).toFixed(3);
    el.style.setProperty("--keep-s", s(horiz && dx > 0 ? dx / th : 0));
    el.style.setProperty("--cut-s", s(horiz && dx < 0 && allowLeft ? -dx / th : 0));
    el.style.setProperty("--file-s", s(!horiz && dy < 0 && allowUp ? -dy / th : 0));
  }, [allowLeft, allowUp]);

  const reset = useCallback(() => {
    const el = ref.current;
    if (!el) return;
    el.style.transform = "";
    ["--keep-s", "--cut-s", "--file-s"].forEach((p) => el.style.removeProperty(p));
  }, []);

  const springBack = useCallback(() => {
    const el = ref.current;
    if (!el) return;
    const from = el.style.transform || "none";
    reset();
    el.animate([{ transform: from }, { transform: "none" }], { duration: 420, easing: "cubic-bezier(0.34, 1.56, 0.64, 1)" });
  }, [reset]);

  const fling = useCallback(
    (dir: SwipeDir, velocity = 0) => {
      const el = ref.current;
      if (!el || st.current.flinging) return;
      st.current.flinging = true;
      const w = window.innerWidth;
      const h = window.innerHeight;
      const { dx, dy } = st.current;
      const from = el.style.transform || "none";
      const to =
        dir === "up"
          ? `translate3d(${dx * 0.5}px, ${-h}px, 0) rotate(0deg)`
          : `translate3d(${(dir === "right" ? 1 : -1) * w * 1.1}px, ${dy + 60}px, 0) rotate(${dir === "right" ? 24 : -24}deg)`;
      const duration = Math.max(180, 320 - Math.min(140, Math.abs(velocity) * 120));
      paint(dir === "up" ? 0 : dir === "right" ? 999 : -999, dir === "up" ? -999 : 0, false);
      el.style.transform = from;
      const anim = el.animate([{ transform: from }, { transform: to }], { duration, easing: "cubic-bezier(0.4, 0, 0.8, 0.6)", fill: "forwards" });
      anim.onfinish = () => {
        st.current.flinging = false;
        st.current.dx = st.current.dy = 0;
        commitRef.current(dir);
      };
    },
    [paint],
  );

  useEffect(() => {
    const el = ref.current;
    if (!el || !enabled) return;
    const down = (e: PointerEvent) => {
      if (e.button !== 0 || st.current.flinging) return;
      if ((e.target as HTMLElement).closest("a,button,input")) return;
      el.setPointerCapture(e.pointerId);
      Object.assign(st.current, { active: true, id: e.pointerId, x0: e.clientX, y0: e.clientY, dx: 0, dy: 0, vx: 0, vy: 0, t: performance.now(), lx: e.clientX, ly: e.clientY });
      el.getAnimations().forEach((a) => a.cancel());
      onDragStart?.();
    };
    const move = (e: PointerEvent) => {
      const s = st.current;
      if (!s.active || e.pointerId !== s.id) return;
      const now = performance.now();
      const dt = Math.max(1, now - s.t);
      s.vx = 0.8 * ((e.clientX - s.lx) / dt) + 0.2 * s.vx;
      s.vy = 0.8 * ((e.clientY - s.ly) / dt) + 0.2 * s.vy;
      s.lx = e.clientX;
      s.ly = e.clientY;
      s.t = now;
      s.dx = e.clientX - s.x0;
      s.dy = Math.min(e.clientY - s.y0, 80); // resist downward drags
      paint(s.dx, s.dy, true);
    };
    const up = (e: PointerEvent) => {
      const s = st.current;
      if (!s.active || e.pointerId !== s.id) return;
      s.active = false;
      const w = el.offsetWidth || 360;
      const th = w * 0.32;
      const horiz = Math.abs(s.dx) >= Math.abs(s.dy) * 0.8;
      if (horiz && (s.dx > th || (s.vx > 0.55 && s.dx > 30))) return fling("right", s.vx);
      if (horiz && allowLeft && (s.dx < -th || (s.vx < -0.55 && s.dx < -30))) return fling("left", s.vx);
      if (!horiz && allowUp && (s.dy < -th || (s.vy < -0.55 && s.dy < -30))) return fling("up", s.vy);
      springBack();
    };
    el.addEventListener("pointerdown", down);
    el.addEventListener("pointermove", move);
    el.addEventListener("pointerup", up);
    el.addEventListener("pointercancel", up);
    return () => {
      el.removeEventListener("pointerdown", down);
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerup", up);
      el.removeEventListener("pointercancel", up);
    };
  }, [enabled, fling, paint, springBack, allowUp, allowLeft, onDragStart]);

  return { ref, fling, reset };
}
