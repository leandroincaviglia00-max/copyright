/**
 * Reads the artwork's average colour for the ambient background glow. The
 * artwork itself is never altered, cropped or overlaid.
 */
import { useEffect } from "react";

const cache = new Map<string, string>();

export function useArtworkTone(url: string | null | undefined) {
  useEffect(() => {
    const root = document.documentElement;
    if (!url) return;
    const hit = cache.get(url);
    if (hit) {
      root.style.setProperty("--tone", hit);
      return;
    }
    let dead = false;
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.decoding = "async";
    img.onload = () => {
      if (dead) return;
      try {
        const c = document.createElement("canvas");
        c.width = c.height = 16;
        const ctx = c.getContext("2d", { willReadFrequently: true })!;
        ctx.drawImage(img, 0, 0, 16, 16);
        const d = ctx.getImageData(0, 0, 16, 16).data;
        let r = 0, g = 0, b = 0, wsum = 0;
        for (let i = 0; i < d.length; i += 4) {
          const max = Math.max(d[i], d[i + 1], d[i + 2]);
          const min = Math.min(d[i], d[i + 1], d[i + 2]);
          const w = 0.2 + (max - min) / 255; // favour saturated pixels
          r += d[i] * w; g += d[i + 1] * w; b += d[i + 2] * w; wsum += w;
        }
        const v = `${Math.round(r / wsum)} ${Math.round(g / wsum)} ${Math.round(b / wsum)}`;
        cache.set(url, v);
        root.style.setProperty("--tone", v);
      } catch {
        /* tainted canvas: keep previous tone */
      }
    };
    img.src = url;
    return () => {
      dead = true;
    };
  }, [url]);
}
