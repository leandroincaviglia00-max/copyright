import { useEffect, useRef, useState } from "react";
import type { Ranked } from "../../discovery/types";
import { fmtDuration, fmtNum } from "../../lib/format";
import { useApp } from "../../state/appStore";
import { useDiscovery } from "../../state/discoveryStore";
import { navigate } from "../../state/router";
import { services } from "../../state/services";
import { Deck, type DeckHandle, type SleeveData } from "../components/Deck";
import { DevicesSheet } from "../components/DevicesSheet";
import { Icon } from "../components/Icon";
import { PlayerStrip } from "../components/PlayerStrip";
import { useArtworkTone } from "../hooks/useArtworkTone";
import { useKeys } from "../hooks/useKeys";
import { usePlayback } from "../hooks/usePlayback";

const TIER_COLOR = { "Close to home": "var(--keep)", "Next door": "var(--file)", Wildcard: "var(--sticker)" } as const;

function toSleeve(r: Ranked): SleeveData {
  const c = r.candidate;
  return {
    key: c.uri,
    image: c.album.image,
    title: c.name,
    artist: c.artists.map((a) => a.name).join(", "),
    meta: [c.album.name, c.album.releaseDate ? c.album.releaseDate.slice(0, 4) : "", fmtDuration(c.durationMs)].filter(Boolean),
    url: c.url,
    extra: (
      <div style={{ marginTop: 8 }}>
        <span className="tier" style={{ color: "var(--sleeve-ink)" }}>
          <i className="dot" style={{ background: TIER_COLOR[r.tier], marginRight: 6 }} />
          {r.tier}
        </span>
        <ul className="why" style={{ margin: "6px 0 0", padding: 0 }}>
          {r.reasons.slice(0, 2).map((x) => (
            <li key={x.code + x.text}>{x.text}</li>
          ))}
        </ul>
      </div>
    ),
  };
}

export function Discover({ id }: { id?: string }) {
  const app = useApp();
  const d = useDiscovery();
  const pb = usePlayback();
  const deck = useRef<DeckHandle>(null);
  const [devices, setDevices] = useState(false);
  const [showDna, setShowDna] = useState(false);
  const top = d.stack[0];
  useArtworkTone(top?.candidate.album.image);

  useEffect(() => {
    void app.loadLibrary();
    if (id) void d.start(id);
    void services().playback.connectSdk();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const last = useRef<string | null>(null);
  useEffect(() => {
    if (!top || !pb.unlocked || !app.settings.autoplayNext || last.current === top.candidate.uri) return;
    last.current = top.candidate.uri;
    void services().playback.play(top.candidate, app.settings.startAt);
  }, [top, pb.unlocked, app.settings.autoplayNext, app.settings.startAt]);

  const play = async () => {
    if (!top) return;
    const pc = services().playback;
    await pc.unlock();
    if (pb.uri === top.candidate.uri && (pb.playing || pb.positionMs > 0)) await pc.toggle();
    else {
      last.current = top.candidate.uri;
      await pc.play(top.candidate, app.settings.startAt);
    }
  };

  useKeys({
    ArrowRight: () => deck.current?.fling("right"),
    ArrowLeft: () => deck.current?.fling("left"),
    ArrowUp: () => deck.current?.fling("up"),
    " ": () => void play(),
    z: () => d.undo(),
    s: () => d.decide("skip"),
  }, !devices);

  if (!id) {
    const readable = app.library.filter((p) => p.readable && p.total > 0);
    return (
      <div className="page">
        <div className="topbar">
          <button className="icon-btn" onClick={() => navigate("/library")} aria-label="Back"><Icon name="back" /></button>
          <span className="grow eyebrow">Discover</span>
        </div>
        <h1 className="display" style={{ fontSize: "clamp(44px, 9vw, 84px)", margin: "24px 0 6px" }}>Dig from a crate.</h1>
        <p className="muted" style={{ marginTop: 0 }}>Pick a playlist. Sift reads its artists, eras and tags, then deals you songs that aren't in it yet.</p>
        <div className="grid" style={{ marginTop: 24 }}>
          {readable.map((p) => (
            <button key={p.id} className="pl" onClick={() => navigate(`/discover/${encodeURIComponent(p.id)}`)}>
              <span className="cover">{p.image ? <img src={p.image} alt="" loading="lazy" /> : <span className="placeholder">{p.name[0]}</span>}</span>
              <span className="name">{p.name}</span>
              <span className="meta">{fmtNum(p.total)} songs</span>
            </button>
          ))}
        </div>
      </div>
    );
  }

  const dna = d.dna;
  const editable = app.library.filter((p) => p.editable);
  const maxDec = Math.max(1, ...(dna?.decades.map((x) => x.count) ?? [1]));

  return (
    <div className="review">
      <div className="stage">
        <div className="stage-head">
          <div className="topbar">
            <button className="icon-btn" onClick={() => navigate("/discover")} aria-label="Back"><Icon name="back" /></button>
            <div className="grow stage-title">
              <span className="eyebrow">Discover from</span>
              <h1>{d.refName || "…"}</h1>
            </div>
            <button className="btn small" onClick={() => setShowDna((x) => !x)}>Music DNA</button>
          </div>
          <div className="catno">
            <span>
              <b>{fmtNum(d.history.filter((h) => h.verdict === "like").length)}</b> yes · {fmtNum(d.history.filter((h) => h.verdict === "reject").length)} no · {fmtNum(d.history.filter((h) => h.verdict === "later").length)} later
            </span>
            <span>Learns from every swipe</span>
          </div>
        </div>

        {d.phase === "analyzing" && (
          <div className="loading-screen">
            <div className="spinner" style={{ margin: "0 auto" }} />
            <div className="mono muted">Reading the grooves…</div>
          </div>
        )}
        {d.phase === "error" && (
          <div className="empty"><h2>Couldn't dig.</h2><p>{d.error}</p><button className="btn primary" onClick={() => void d.start(id)}>Retry</button></div>
        )}
        {d.phase === "ready" && top && (
          <>
            <Deck ref={deck} cards={d.stack.map(toSleeve)} onCommit={(dir) => d.decide(dir === "right" ? "like" : dir === "left" ? "reject" : "later")} playing={pb.playing && pb.uri === top.candidate.uri} enter="rise" labels={{ keep: "Yes", cut: "Nope", file: "Later" }} />
            <PlayerStrip pb={pb.uri === top.candidate.uri ? pb : { ...pb, mode: services().playback.modeFor(top.candidate), positionMs: 0, playing: false, message: null }} onDevices={() => setDevices(true)} />
            <div className="actions">
              <button className="act sm" onClick={() => d.undo()} disabled={!d.history.length} aria-label="Undo"><Icon name="undo" /><span className="lbl">Undo</span></button>
              <button className="act lg cut" onClick={() => deck.current?.fling("left")} aria-label="Not for me"><Icon name="x" size={30} /><span className="lbl">Nope</span></button>
              <button className="act md play" onClick={() => void play()} aria-label="Play or pause"><Icon name={pb.playing && pb.uri === top.candidate.uri ? "pause" : "play"} size={26} /></button>
              <button className="act lg keep" onClick={() => deck.current?.fling("right")} aria-label="I like this"><Icon name="heart" size={30} /><span className="lbl">Yes</span></button>
              <button className="act sm file" onClick={() => deck.current?.fling("up")} aria-label="Save for later"><Icon name="bookmark" /><span className="lbl">Later</span></button>
            </div>
          </>
        )}
        {d.phase === "ready" && !top && (
          <div className="empty">
            <h2>{d.exhausted ? "Crate's bare." : "Digging…"}</h2>
            <p>{d.exhausted ? "Spotify's catalog search ran dry for this playlist's seeds. Try another playlist, or save what you've found." : "Fetching more candidates."}</p>
          </div>
        )}

        {(d.liked.length > 0 || d.later.length > 0) && (
          <div className="tray">
            <span className="grow">{fmtNum(d.liked.length)} liked{d.later.length ? ` · ${fmtNum(d.later.length)} later` : ""}</span>
            <select value={d.destinationId ?? ""} onChange={(e) => d.setDestination(e.target.value || null)} aria-label="Add liked songs to">
              <option value="">New “Sift · Discoveries”</option>
              {editable.map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
            <button className="btn small primary" onClick={() => void d.saveLiked()} disabled={d.saving}>{d.saving ? "Adding…" : "Add"}</button>
          </div>
        )}
      </div>

      <aside className={`side ${showDna ? "open" : ""}`}>
        {dna && (
          <>
            <div className="panel">
              <div className="eyebrow" style={{ marginBottom: 12 }}>Music DNA · {fmtNum(dna.size)} songs</div>
              <div style={{ fontWeight: 600, marginBottom: 6 }}>Heavy rotation</div>
              {dna.artists.slice(0, 6).map((a) => (
                <div key={a.id} className="hbar">
                  <span className="nm">{a.name}</span>
                  <span className="track"><i style={{ width: `${(a.count / dna.artists[0].count) * 100}%` }} /></span>
                  <span className="v">{a.count}</span>
                </div>
              ))}
            </div>
            {dna.decades.length > 0 && (
              <div className="panel">
                <div style={{ fontWeight: 600, marginBottom: 10 }}>Release eras</div>
                <div className="dna-bars">
                  {dna.decades.map((x) => (
                    <div key={x.decade}><span style={{ height: `${(x.count / maxDec) * 100}%` }} /><small>{x.decade.slice(2)}</small></div>
                  ))}
                </div>
              </div>
            )}
            <div className="panel">
              <div style={{ fontWeight: 600, marginBottom: 10 }}>Genre threads</div>
              {dna.genres.length ? (
                <div className="tags">{dna.genres.slice(0, 12).map((g) => <span key={g.name} className="tag">{g.name}</span>)}</div>
              ) : (
                <p className="muted" style={{ margin: 0, fontSize: 14 }}>Spotify didn't share genre tags for these artists (the field is deprecated). Discovery leans on artists and eras instead.</p>
              )}
              {dna.clusters.length > 0 && (
                <div style={{ marginTop: 14, display: "flex", flexDirection: "column", gap: 8 }}>
                  {dna.clusters.slice(0, 4).map((c) => (
                    <div key={c.label} style={{ fontSize: 14 }}><strong>{c.label}</strong> <span className="muted">· {c.artists.join(", ")}</span></div>
                  ))}
                </div>
              )}
            </div>
            <div className="panel" style={{ fontSize: 14 }}>
              <span className="muted">
                Rankings use only this playlist's metadata and your own yes/no swipes. No audio analysis, no AI model, and no match percentages we can't explain.
              </span>
            </div>
          </>
        )}
      </aside>
      <DevicesSheet open={devices} onClose={() => setDevices(false)} />
    </div>
  );
}
