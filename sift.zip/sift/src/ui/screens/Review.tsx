import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { computeLenses } from "../../cleanup/smartFilters";
import { fmtDuration, fmtNum, fmtTime } from "../../lib/format";
import type { PlaylistEntry } from "../../playlists/model";
import * as E from "../../review/reviewEngine";
import type { Decision, DecisionRecord, QueueFilter } from "../../review/types";
import { useApp } from "../../state/appStore";
import { useReview } from "../../state/reviewStore";
import { navigate } from "../../state/router";
import { services } from "../../state/services";
import { Deck, type DeckHandle, type SleeveData } from "../components/Deck";
import { DevicesSheet } from "../components/DevicesSheet";
import { Icon } from "../components/Icon";
import { MoveSheet } from "../components/MoveSheet";
import { PlayerStrip } from "../components/PlayerStrip";
import { Confirm } from "../components/Sheet";
import { useArtworkTone } from "../hooks/useArtworkTone";
import { useKeys } from "../hooks/useKeys";
import { usePlayback } from "../hooks/usePlayback";
import type { SwipeDir } from "../hooks/useSwipe";

const DECIDED: Record<string, { label: string; color: string }> = {
  keep: { label: "Kept", color: "var(--keep)" },
  remove: { label: "Cut", color: "var(--cut)" },
  move: { label: "Filed", color: "var(--file)" },
};

const KIND_LABEL: Partial<Record<PlaylistEntry["kind"], string>> = { episode: "EPISODE", local: "LOCAL FILE", unavailable: "UNAVAILABLE", unknown: "UNSUPPORTED" };

export function toSleeve(e: PlaylistEntry, d?: DecisionRecord): SleeveData {
  return {
    key: e.key,
    image: e.image,
    title: e.name,
    artist: e.artists.map((a) => a.name).join(", ") || "Unknown artist",
    meta: [e.albumName, e.releaseYear ? String(e.releaseYear) : "", fmtDuration(e.durationMs), e.explicit ? "E" : ""].filter(Boolean),
    url: e.url,
    kindLabel: KIND_LABEL[e.kind],
    decided: d ? DECIDED[d.kind] : null,
  };
}

export function Review({ id }: { id: string }) {
  const r = useReview();
  const app = useApp();
  const pb = usePlayback();
  const deck = useRef<DeckHandle>(null);
  const [moveOpen, setMoveOpen] = useState(false);
  const [devicesOpen, setDevicesOpen] = useState(false);
  const [sideOpen, setSideOpen] = useState(false);
  const [confirmRestart, setConfirmRestart] = useState(false);
  const [enter, setEnter] = useState<"left" | "right" | "up" | "rise" | null>(null);
  const [nonce, setNonce] = useState(0);
  const fileInput = useRef<HTMLInputElement>(null);
  const flungUp = useRef(false);

  useEffect(() => {
    void r.open(id);
    void useApp.getState().loadLibrary();
    void services().playback.connectSdk();
    return () => r.close();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  // external-change detection: poll the snapshot while reviewing
  useEffect(() => {
    const t = setInterval(() => void useReview.getState().checkRemote(), 60_000);
    const onFocus = () => void useReview.getState().checkRemote();
    window.addEventListener("focus", onFocus);
    return () => (clearInterval(t), window.removeEventListener("focus", onFocus));
  }, []);

  const s = r.session;
  const key = s ? E.current(s) : null;
  const entry = key ? r.entries.get(key) ?? null : null;
  const q = useMemo(() => (s ? E.queue(s) : []), [s]);
  const idx = key ? q.indexOf(key) : -1;
  const c = useMemo(() => (s ? E.counts(s) : null), [s]);
  const editable = r.playlist?.editable !== false;
  useArtworkTone(entry?.imageSmall ?? entry?.image);

  const cards = useMemo(() => {
    if (!s || idx < 0) return [];
    return q
      .slice(idx, idx + 3)
      .map((k) => r.entries.get(k))
      .filter(Boolean)
      .map((e) => toSleeve(e!, s.decisions[e!.key]));
  }, [q, idx, r.entries, s]);

  // autoplay the next card once the user has pressed play at least once
  const lastPlayed = useRef<string | null>(null);
  useEffect(() => {
    if (!entry || !pb.unlocked || !app.settings.autoplayNext) return;
    if (lastPlayed.current === entry.key) return;
    lastPlayed.current = entry.key;
    void services().playback.play(entry, app.settings.startAt);
  }, [entry, pb.unlocked, app.settings.autoplayNext, app.settings.startAt]);

  const lenses = useMemo(
    () => (s ? computeLenses({ entries: r.list, session: s, profile: app.profile, listening: app.listening, genresByArtist: {} }) : []),
    // lenses don't need to recompute on every swipe
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [r.list, s?.skips, app.listening, s?.id],
  );

  const decide = useCallback(
    (d: Decision) => {
      const st = useReview.getState();
      const k = st.session && E.current(st.session);
      if (!k) return;
      if (d.kind === "remove" && !editable) return;
      st.decide(d, k);
      setEnter("rise");
      const e = st.entries.get(k);
      const label = d.kind === "keep" ? "Kept" : d.kind === "remove" ? "Cut" : d.targets.length > 1 ? `Filed to ${d.targets.length} playlists` : "Filed";
      app.toast({ text: `${label} · ${e?.name ?? ""}`, action: { label: "Undo", run: () => undo() }, ttl: 2600 });
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [editable],
  );

  const undo = () => {
    const st = useReview.getState();
    const last = st.session?.history[st.session.history.length - 1];
    if (!last) return;
    st.undo();
    const k = last.next?.kind;
    setEnter(k === "keep" ? "right" : k === "remove" ? "left" : "up");
  };

  const onCommit = (dir: SwipeDir) => {
    if (dir === "right") decide({ kind: "keep" });
    else if (dir === "left") decide({ kind: "remove" });
    else {
      flungUp.current = true;
      setMoveOpen(true);
    }
  };

  const closeMove = () => {
    setMoveOpen(false);
    // the card flew up but the sheet was dismissed: bring the sleeve back
    if (flungUp.current) {
      flungUp.current = false;
      setNonce((n) => n + 1);
      setEnter("up");
    }
  };

  const togglePlay = async () => {
    if (!entry) return;
    const pc = services().playback;
    await pc.unlock();
    if (pb.uri === entry.uri && pb.mode !== "none" && (pb.playing || pb.positionMs > 0)) await pc.toggle();
    else {
      lastPlayed.current = entry.key;
      await pc.play(entry, app.settings.startAt);
    }
  };

  const setFilter = (f: QueueFilter) => r.setFilter(s?.filter === f ? "all" : f);

  useKeys(
    {
      ArrowRight: () => deck.current?.fling("right"),
      ArrowLeft: () => editable && deck.current?.fling("left"),
      ArrowUp: () => setMoveOpen(true),
      " ": () => void togglePlay(),
      z: undo,
      Backspace: undo,
      "Shift+z": () => r.redo(),
      s: () => r.skip(),
      u: () => r.jumpToUndecided(),
      o: () => entry?.url && window.open(entry.url, "_blank", "noopener"),
      Enter: () => navigate(`/review/${encodeURIComponent(id)}/summary`),
    },
    !moveOpen && !devicesOpen,
  );

  if (r.load.state === "loading" || r.load.state === "idle")
    return (
      <div className="loading-screen">
        <div className="spinner" style={{ margin: "0 auto" }} />
        <div className="mono muted">
          {r.load.total ? `Pulling ${fmtNum(r.load.loaded)} / ${fmtNum(r.load.total)} songs` : "Opening the crate…"}
        </div>
      </div>
    );
  if (r.load.state === "error" || !s || !c || !r.playlist)
    return (
      <div className="empty">
        <h2>Can't open this one.</h2>
        <p>{r.load.error}</p>
        <div style={{ display: "flex", gap: 10 }}>
          <button className="btn" onClick={() => navigate("/library")}>Back to library</button>
          <button className="btn primary" onClick={() => void r.open(id)}>Retry</button>
        </div>
      </div>
    );

  const pending = c.remove + c.move;
  const recent = [...s.history].reverse().flatMap((h) => (h.next?.kind === "move" ? h.next.targets : []));
  const pos = s.filter === "all" ? s.order.indexOf(key ?? "") : idx;

  return (
    <div className="review">
      <div className="stage">
        <div className="stage-head">
          <div className="topbar">
            <button className="icon-btn" onClick={() => navigate("/library")} aria-label="Back to library"><Icon name="back" /></button>
            <div className="grow stage-title">
              <h1>{r.playlist.name}</h1>
              {!editable && <span className="badge lock"><Icon name="lock" size={14} /> Read-only</span>}
            </div>
            <button className="icon-btn" onClick={() => setSideOpen((o) => !o)} aria-label="Filters and tools" aria-expanded={sideOpen}><Icon name="sliders" /></button>
            <button className="btn small primary" onClick={() => navigate(`/review/${encodeURIComponent(id)}/summary`)}>
              Review{pending ? ` · ${fmtNum(pending)}` : ""}
            </button>
          </div>
          <div className="rail" aria-label={`${c.keep} kept, ${c.remove} cut, ${c.move} filed of ${c.total}`}>
            <span className="k" style={{ width: `${(c.keep / Math.max(1, c.total)) * 100}%` }} />
            <span className="c" style={{ width: `${(c.remove / Math.max(1, c.total)) * 100}%` }} />
            <span className="f" style={{ width: `${(c.move / Math.max(1, c.total)) * 100}%` }} />
          </div>
          <div className="catno">
            <span>
              No. <b>{String(Math.max(0, pos) + 1).padStart(4, "0")}</b> / {fmtNum(s.filter === "all" ? c.total : q.length)}
              {s.filter !== "all" && <> · {s.filter === "lens" ? s.lens?.label : s.filter}</>}
            </span>
            {r.remoteChanged ? (
              <button className="badge warn" onClick={() => void r.resync()}>Changed on Spotify · Re-sync</button>
            ) : (
              <span className="badge live" title="Last synchronised with Spotify">Synced {fmtTime(s.lastSyncedAt)}</span>
            )}
          </div>
          {r.pendingJournal && (
            <div className="banner">
              <span className="grow">An earlier apply didn't finish. Nothing was lost.</span>
              <button className="btn small primary" onClick={() => navigate(`/review/${encodeURIComponent(id)}/summary`)}>Resume</button>
            </div>
          )}
          {r.reconcileReport && (
            <div className="banner">
              <span className="grow">
                This playlist changed on Spotify: {r.reconcileReport.addedExternally.length} new, {r.reconcileReport.removedExternally.length} gone
                {r.reconcileReport.droppedDecisions.length ? ` (${r.reconcileReport.droppedDecisions.length} of your decisions no longer apply)` : ""}. Your other decisions are intact.
              </span>
              <button className="btn small" onClick={r.dismissReport}>Got it</button>
            </div>
          )}
        </div>

        {entry ? (
          <>
            <Deck
              key={nonce}
              ref={deck}
              cards={cards}
              onCommit={onCommit}
              playing={pb.playing && pb.uri === entry.uri}
              enter={enter}
              allowLeft={editable}
              labels={{ keep: "Keep", cut: "Cut", file: "File" }}
            />
            <PlayerStrip pb={pb.uri === entry.uri ? pb : { ...pb, mode: services().playback.modeFor(entry), positionMs: 0, playing: false, message: null }} onDevices={() => setDevicesOpen(true)} />
            <div className="actions">
              <button className="act sm" onClick={undo} disabled={!E.canUndo(s)} aria-label="Undo (Z)"><Icon name="undo" /><span className="lbl">Undo</span></button>
              <button className="act lg cut" onClick={() => deck.current?.fling("left")} disabled={!editable} aria-label="Cut from playlist (←)"><Icon name="x" size={30} /><span className="lbl">Cut</span></button>
              <button className="act md play" onClick={() => void togglePlay()} aria-label="Play or pause (Space)">
                <Icon name={pb.playing && pb.uri === entry.uri ? "pause" : "play"} size={26} />
              </button>
              <button className="act lg keep" onClick={() => deck.current?.fling("right")} aria-label="Keep (→)"><Icon name="heart" size={30} /><span className="lbl">Keep</span></button>
              <button className="act sm file" onClick={() => setMoveOpen(true)} aria-label="File / move (↑)"><Icon name="up" /><span className="lbl">File</span></button>
            </div>
          </>
        ) : (
          <div className="empty">
            <h2>{s.filter === "all" ? "Crate's done." : "Nothing here."}</h2>
            <p>
              {s.filter === "all"
                ? `You've been through all ${fmtNum(c.total)} songs. Check the summary, then send it to Spotify.`
                : "No songs match this filter."}
            </p>
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap", justifyContent: "center" }}>
              {s.filter !== "all" && <button className="btn" onClick={() => r.setFilter("all")}>Show everything</button>}
              {c.undecided > 0 && <button className="btn" onClick={() => r.jumpToUndecided()}>Jump to undecided</button>}
              <button className="btn primary" onClick={() => navigate(`/review/${encodeURIComponent(id)}/summary`)}>Open summary</button>
            </div>
          </div>
        )}
      </div>

      <aside className={`side ${sideOpen ? "open" : ""}`}>
        <div className="panel">
          <div className="eyebrow" style={{ marginBottom: 12 }}>This session</div>
          <div className="tally">
            {([
              ["undecided", "Undecided", c.undecided, "var(--muted)"],
              ["keep", "Kept", c.keep, "var(--keep)"],
              ["remove", "Cut", c.remove, "var(--cut)"],
              ["move", "Filed", c.move, "var(--file)"],
            ] as const).map(([f, l, n, col]) => (
              <button key={f} aria-pressed={s.filter === f} onClick={() => setFilter(f)}>
                <span className="n">{fmtNum(n)}</span>
                <span className="l"><i className="dot" style={{ background: col }} />{l}</span>
              </button>
            ))}
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 12, flexWrap: "wrap" }}>
            <button className="btn small" onClick={() => r.jumpToUndecided()} disabled={!c.undecided}>Jump to undecided</button>
            <button className="btn small ghost" onClick={() => r.redo()} disabled={!E.canRedo(s)}><Icon name="redo" size={18} /> Redo</button>
          </div>
        </div>

        <div className="panel">
          <div className="eyebrow" style={{ marginBottom: 8 }}>Smart lenses</div>
          {lenses.map((l) =>
            l.available ? (
              <button
                key={l.id}
                className="lens"
                title={l.blurb}
                aria-pressed={s.filter === "lens" && s.lens?.id === l.id}
                disabled={!l.keys.length}
                onClick={() => (s.filter === "lens" && s.lens?.id === l.id ? r.setFilter("all") : r.setFilter("lens", { id: l.id, label: l.label, keys: l.keys }))}
              >
                <span>{l.label}</span>
                <small>{fmtNum(l.keys.length)}</small>
              </button>
            ) : (
              <button key={l.id} className="lens" title={l.blurb} onClick={() => void app.enableListening()}>
                <span>{l.label}</span>
                <small>Enable</small>
              </button>
            ),
          )}
          {app.listeningState === "off" && (
            <p className="muted" style={{ fontSize: 14, margin: "8px 12px 0" }}>
              “Enable” asks Spotify for read-only listening history (recently played, top items). Used only for these lenses and discovery seeds.
            </p>
          )}
        </div>

        <div className="panel">
          <div className="eyebrow" style={{ marginBottom: 10 }}>Session</div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <button className="btn small" onClick={r.exportJson}><Icon name="download" size={18} /> Export</button>
            <button className="btn small" onClick={() => fileInput.current?.click()}><Icon name="upload" size={18} /> Import</button>
            <button className="btn small" onClick={() => void r.resync()}><Icon name="refresh" size={18} /> Refresh</button>
            <button className="btn small ghost" onClick={() => setConfirmRestart(true)}>Restart review</button>
          </div>
          <input
            ref={fileInput}
            type="file"
            accept="application/json"
            hidden
            onChange={async (e) => {
              const f = e.target.files?.[0];
              e.target.value = "";
              if (!f) return;
              try {
                await r.importJson(await f.text());
                app.toast({ text: "Session restored from file", tone: "success" });
              } catch (err) {
                app.toast({ text: (err as Error).message, tone: "error" });
              }
            }}
          />
        </div>

        <div className="panel kbd">
          <kbd>→</kbd><span>Keep</span>
          <kbd>←</kbd><span>Cut</span>
          <kbd>↑</kbd><span>File / move</span>
          <kbd>Space</kbd><span>Play / pause</span>
          <kbd>Z</kbd><span>Undo (Shift+Z redo)</span>
          <kbd>S</kbd><span>Skip for now</span>
          <kbd>U</kbd><span>Next undecided</span>
          <kbd>O</kbd><span>Open in Spotify</span>
        </div>
      </aside>

      {entry && (
        <MoveSheet
          open={moveOpen}
          onClose={closeMove}
          source={r.playlist}
          library={app.library}
          pending={s.pendingPlaylists}
          recent={Array.from(new Set(recent))}
          songName={entry.name}
          onDecide={(d) => {
            if (flungUp.current) {
              flungUp.current = false;
              setNonce((n) => n + 1);
            }
            setMoveOpen(false);
            decide(d);
          }}
          onCreatePending={r.addPendingPlaylist}
        />
      )}
      <DevicesSheet open={devicesOpen} onClose={() => setDevicesOpen(false)} />
      <Confirm
        open={confirmRestart}
        onClose={() => setConfirmRestart(false)}
        title="Start over?"
        body={`This clears all ${fmtNum(Object.keys(s.decisions).length)} local decisions for “${s.playlistName}”. Nothing on Spotify changes. Export first if you might want them back.`}
        confirmLabel="Clear decisions"
        danger
        onConfirm={() => r.restart()}
      />
    </div>
  );
}
