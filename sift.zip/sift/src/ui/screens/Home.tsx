import { useState } from "react";
import { ConfigError, config } from "../../config/env";
import { services } from "../../state/services";
import { Icon } from "../components/Icon";

export function Home({ expired }: { expired?: boolean }) {
  const [err, setErr] = useState<string | null>(() => {
    try {
      config();
      return null;
    } catch (e) {
      return e instanceof ConfigError ? e.message : String(e);
    }
  });
  const [busy, setBusy] = useState(false);
  const go = async () => {
    setBusy(true);
    try {
      await services().auth.login([], "/library");
    } catch (e) {
      setErr((e as Error).message);
      setBusy(false);
    }
  };
  return (
    <main className="home">
      <div>
        <div className="crate-demo" aria-hidden="true">
          <span /><span /><span /><span />
        </div>
        <h1 className="display">SIFT</h1>
        <p className="tag">Your Spotify playlists, one sleeve at a time.</p>
        {expired && <div className="banner" style={{ maxWidth: 440, margin: "0 auto 18px" }}>Your Spotify session ended. Sign back in: every decision you made is still here.</div>}
        {err && <div className="banner error" style={{ maxWidth: 440, margin: "0 auto 18px", textAlign: "left" }}>{err}</div>}
        <button className="btn primary" style={{ height: 56, padding: "0 30px", fontSize: 18 }} onClick={go} disabled={!!err || busy}>
          {busy ? "Opening Spotify…" : "Connect Spotify"} <Icon name="ext" size={18} />
        </button>
        <p className="fineprint">
          Swipe right to keep, left to cut, up to file. Nothing changes on Spotify until you review and apply. Sift never stores audio, and your tokens never leave this browser.
        </p>
      </div>
    </main>
  );
}
