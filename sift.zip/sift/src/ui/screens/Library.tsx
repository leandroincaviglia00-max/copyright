import { useEffect, useMemo, useState } from "react";
import { fmtNum, fmtRelative } from "../../lib/format";
import type { SessionIndexEntry } from "../../persistence/sessionRepo";
import { useApp } from "../../state/appStore";
import { navigate } from "../../state/router";
import { services } from "../../state/services";
import { Icon } from "../components/Icon";
import { SpotifyLink } from "../components/SpotifyLink";

type Filter = "all" | "editable" | "locked" | "progress";

export function Library() {
  const app = useApp();
  const [q, setQ] = useState("");
  const [f, setF] = useState<Filter>("all");
  const [sessions, setSessions] = useState<SessionIndexEntry[]>([]);

  useEffect(() => {
    void app.loadLibrary();
    void services().repo.list().then(setSessions);
    document.documentElement.style.setProperty("--tone", "90 90 100");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const byPl = useMemo(() => new Map(sessions.filter((s) => s.status !== "applied").map((s) => [s.playlistId, s])), [sessions]);
  const list = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return app.library.filter((p) => {
      if (needle && !`${p.name} ${p.ownerName}`.toLowerCase().includes(needle)) return false;
      if (f === "editable") return p.editable;
      if (f === "locked") return !p.readable;
      if (f === "progress") return byPl.has(p.id);
      return true;
    });
  }, [app.library, q, f, byPl]);
  const counts = {
    all: app.library.length,
    editable: app.library.filter((p) => p.editable).length,
    locked: app.library.filter((p) => !p.readable).length,
    progress: app.library.filter((p) => byPl.has(p.id)).length,
  };

  return (
    <div className="page">
      <header className="topbar">
        <a className="logo" href="/library" onClick={(e) => (e.preventDefault(), navigate("/library"))}><i />SIFT</a>
        <span className="grow" />
        <button className="icon-btn" onClick={() => navigate("/discover")} aria-label="Discover"><Icon name="compass" /></button>
        <button className="icon-btn" onClick={() => navigate("/stats")} aria-label="Statistics"><Icon name="chart" /></button>
        <button className="icon-btn" onClick={() => navigate("/sessions")} aria-label="Sessions"><Icon name="list" /></button>
        <button className="icon-btn" onClick={() => app.setSettings({ theme: app.settings.theme === "dark" ? "light" : "dark" })} aria-label="Toggle theme">
          <Icon name={app.settings.theme === "dark" ? "sun" : "moon"} />
        </button>
        <button className="icon-btn" onClick={app.logout} aria-label="Disconnect Spotify" title="Disconnect Spotify"><Icon name="out" /></button>
      </header>

      <div className="lib-head">
        <h1 className="display">Your crates</h1>
        <span className="muted">{app.me ? `${app.me.name} · ` : ""}{fmtNum(app.library.length)} playlists</span>
      </div>

      <div className="lib-tools">
        <input className="input" placeholder="Find a playlist" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search playlists" />
        <div className="chips" role="toolbar" aria-label="Filter playlists">
          {([
            ["all", "All"],
            ["editable", "Yours to sort"],
            ["progress", "In progress"],
            ["locked", "Locked"],
          ] as const).map(([k, l]) => (
            <button key={k} className="chip" aria-pressed={f === k} onClick={() => setF(k)}>
              {l} <span className="n">{counts[k]}</span>
            </button>
          ))}
        </div>
      </div>

      {app.libraryState === "loading" && !app.library.length && (
        <div className="loading-screen"><div className="spinner" style={{ margin: "0 auto" }} /></div>
      )}
      {app.libraryState === "error" && (
        <div className="banner error"><span className="grow">{app.libraryError}</span><button className="btn small" onClick={() => void app.loadLibrary(true)}>Retry</button></div>
      )}
      {app.libraryState === "ready" && !list.length && (
        <div className="empty"><h2>No sleeves here.</h2><p>{q ? "Nothing matches that search." : "No playlists in this filter."}</p></div>
      )}
      {f === "locked" && counts.locked > 0 && (
        <p className="muted" style={{ marginTop: 0 }}>Since February 2026, Spotify only shares the songs of playlists you own or collaborate on. These can't be opened by any third-party app.</p>
      )}

      <div className="grid">
        {list.map((p) => {
          const sess = byPl.get(p.id);
          return (
            <div key={p.id} className={`pl ${p.readable ? "" : "locked"}`}>
              <button className="cover" onClick={() => p.readable && navigate(`/review/${encodeURIComponent(p.id)}`)} disabled={!p.readable} aria-label={`Review ${p.name}`}>
                {p.image ? <img src={p.image} alt="" loading="lazy" /> : <span className="placeholder">{p.name.slice(0, 1)}</span>}
                {sess && <span className="progress-tab">{fmtNum(sess.decided)}/{fmtNum(sess.total)}</span>}
              </button>
              <div className="name">{p.name}</div>
              <div className="meta">
                <span>{fmtNum(p.total)} songs</span>
                {p.ownerId !== app.me?.id && <span>· {p.ownerName}</span>}
                {p.collaborative ? <span className="badge">Collab</span> : p.isPublic === false ? <span className="badge">Private</span> : null}
                {!p.readable && <span className="badge lock"><Icon name="lock" size={12} /> Locked</span>}
              </div>
              <div className="acts">
                {p.readable ? (
                  <>
                    <button className="btn small primary" onClick={() => navigate(`/review/${encodeURIComponent(p.id)}`)}>{sess ? "Resume" : "Sort"}</button>
                    <button className="btn small" onClick={() => navigate(`/discover/${encodeURIComponent(p.id)}`)} aria-label={`Discover from ${p.name}`}><Icon name="compass" size={18} /></button>
                  </>
                ) : (
                  <SpotifyLink href={p.url} className="btn small" label="Open in Spotify" />
                )}
              </div>
              {sess && <small className="muted">Last sorted {fmtRelative(sess.updatedAt)}</small>}
            </div>
          );
        })}
      </div>
    </div>
  );
}
