import { useEffect, useMemo, useState } from "react";
import { fmtNum } from "../../lib/format";
import * as E from "../../review/reviewEngine";
import type { ReviewSession } from "../../review/types";
import { useApp } from "../../state/appStore";
import { navigate } from "../../state/router";
import { services } from "../../state/services";
import { Icon } from "../components/Icon";

export function Stats() {
  const app = useApp();
  const [sessions, setSessions] = useState<ReviewSession[]>([]);
  useEffect(() => {
    const { repo } = services();
    void repo.list().then(async (idx) => setSessions((await Promise.all(idx.map((i) => repo.load(i.id)))).filter(Boolean) as ReviewSession[]));
  }, []);

  const agg = useMemo(() => {
    let keep = 0, remove = 0, move = 0, total = 0, decisions = 0;
    const artists = new Map<string, number>();
    const paces: number[] = [];
    for (const s of sessions) {
      const c = E.counts(s);
      keep += c.keep; remove += c.remove; move += c.move; total += c.total;
      decisions += s.history.length;
      const p = E.reviewPace(s);
      if (p) paces.push(p);
      for (const e of Object.values(s.entries)) {
        const a = e.artist.split(", ")[0];
        if (a) artists.set(a, (artists.get(a) ?? 0) + 1);
      }
    }
    const decided = keep + remove + move;
    return {
      keep, remove, move, total, decided, decisions,
      cleanup: decided ? remove / decided : 0,
      pace: paces.length ? paces.reduce((a, b) => a + b, 0) / paces.length : null,
      artists: [...artists].sort((a, b) => b[1] - a[1]).slice(0, 10),
    };
  }, [sessions]);

  const p = app.profile;
  const likeRate = p.totals.like + p.totals.reject ? p.totals.like / (p.totals.like + p.totals.reject) : null;
  const likedArtists = Object.values(p.artists).filter((a) => a.like > 0).sort((a, b) => b.like - a.like).slice(0, 6);
  const topGenres = Object.entries(p.genres).map(([g, t]) => ({ g, n: t.like + t.reject, like: t.like })).sort((a, b) => b.n - a.n).slice(0, 8);

  return (
    <div className="page">
      <div className="topbar">
        <button className="icon-btn" onClick={() => navigate("/library")} aria-label="Back"><Icon name="back" /></button>
        <span className="grow eyebrow">Statistics</span>
      </div>
      <h1 className="display" style={{ fontSize: "clamp(44px, 9vw, 84px)", margin: "24px 0 0" }}>
        {agg.decided ? <>{Math.round(agg.cleanup * 100)}% cut.</> : "No sorting yet."}
      </h1>
      <p className="muted" style={{ marginTop: 8 }}>{agg.decided ? `Across ${sessions.length} crate${sessions.length === 1 ? "" : "s"} and ${fmtNum(agg.total)} songs.` : "Sort a playlist and your numbers show up here."}</p>

      <div className="stat-hero">
        <div className="panel"><span className="n" style={{ color: "var(--keep)" }}>{fmtNum(agg.keep)}</span><span className="eyebrow">Kept</span></div>
        <div className="panel"><span className="n" style={{ color: "var(--cut)" }}>{fmtNum(agg.remove)}</span><span className="eyebrow">Cut</span></div>
        <div className="panel"><span className="n" style={{ color: "var(--file)" }}>{fmtNum(agg.move)}</span><span className="eyebrow">Filed</span></div>
        <div className="panel"><span className="n">{agg.pace ? agg.pace.toFixed(1) : "–"}</span><span className="eyebrow">Songs / minute</span></div>
      </div>

      <div className="two">
        <div className="panel">
          <div className="eyebrow" style={{ marginBottom: 12 }}>Most represented artists</div>
          {agg.artists.length ? agg.artists.map(([a, n]) => (
            <div key={a} className="hbar"><span className="nm">{a}</span><span className="track"><i style={{ width: `${(n / agg.artists[0][1]) * 100}%` }} /></span><span className="v">{n}</span></div>
          )) : <p className="muted">Nothing yet.</p>}
        </div>
        <div className="panel">
          <div className="eyebrow" style={{ marginBottom: 12 }}>Crates</div>
          {sessions.map((s) => {
            const c = E.counts(s);
            return (
              <button key={s.id} className="lens" onClick={() => navigate(`/review/${encodeURIComponent(s.playlistId)}`)}>
                <span>{s.playlistName}</span>
                <small>{fmtNum(c.total - c.undecided)}/{fmtNum(c.total)} · {s.history.length} moves</small>
              </button>
            );
          })}
          {!sessions.length && <p className="muted">No sessions yet.</p>}
        </div>
        <div className="panel">
          <div className="eyebrow" style={{ marginBottom: 12 }}>Discovery</div>
          <div style={{ display: "flex", gap: 24, flexWrap: "wrap", marginBottom: 14 }}>
            <div><span className="display" style={{ fontSize: 40 }}>{fmtNum(p.totals.shown)}</span><div className="muted">songs dealt</div></div>
            <div><span className="display" style={{ fontSize: 40 }}>{likeRate === null ? "–" : `${Math.round(likeRate * 100)}%`}</span><div className="muted">said yes</div></div>
            <div><span className="display" style={{ fontSize: 40 }}>{fmtNum(p.totals.later)}</span><div className="muted">saved for later</div></div>
          </div>
          {likedArtists.length > 0 && <div className="tags">{likedArtists.map((a) => <span key={a.name} className="tag">{a.name} · {a.like}</span>)}</div>}
        </div>
        <div className="panel">
          <div className="eyebrow" style={{ marginBottom: 12 }}>Genre feedback</div>
          {topGenres.length ? topGenres.map((g) => (
            <div key={g.g} className="hbar"><span className="nm">{g.g}</span><span className="track"><i style={{ width: `${(g.like / Math.max(1, g.n)) * 100}%`, background: "var(--keep)" }} /></span><span className="v">{g.like}/{g.n}</span></div>
          )) : <p className="muted" style={{ margin: 0 }}>Only appears when Spotify supplies genre tags for artists you swipe on.</p>}
        </div>
      </div>
    </div>
  );
}
