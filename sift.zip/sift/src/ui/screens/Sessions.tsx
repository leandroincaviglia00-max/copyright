import { useEffect, useState } from "react";
import { fmtNum, fmtRelative } from "../../lib/format";
import { downloadJson, exportSession, type SessionIndexEntry } from "../../persistence/sessionRepo";
import { navigate } from "../../state/router";
import { services } from "../../state/services";
import { Icon } from "../components/Icon";
import { Confirm } from "../components/Sheet";

export function Sessions() {
  const [list, setList] = useState<SessionIndexEntry[]>([]);
  const [del, setDel] = useState<SessionIndexEntry | null>(null);
  const reload = () => void services().repo.list().then(setList);
  useEffect(reload, []);
  return (
    <div className="page" style={{ maxWidth: 760 }}>
      <div className="topbar">
        <button className="icon-btn" onClick={() => navigate("/library")} aria-label="Back"><Icon name="back" /></button>
        <span className="grow eyebrow">Session history</span>
      </div>
      <h1 className="display" style={{ fontSize: "clamp(44px, 9vw, 76px)", margin: "24px 0 18px" }}>Sessions</h1>
      {!list.length && <p className="muted">Nothing yet. Sessions are saved on this device as you swipe.</p>}
      {list.map((s) => (
        <div key={s.id} className="dest" style={{ padding: "10px 8px" }}>
          {s.playlistImage ? <img src={s.playlistImage} alt="" /> : <span className="ph" />}
          <span className="nm">
            {s.playlistName}
            <br />
            <small className="muted">{fmtNum(s.decided)}/{fmtNum(s.total)} decided · {fmtRelative(s.updatedAt)}</small>
          </span>
          <button className="btn small" onClick={() => navigate(`/review/${encodeURIComponent(s.playlistId)}`)}>Open</button>
          <button className="icon-btn" aria-label="Export" onClick={async () => { const x = await services().repo.load(s.id); if (x) downloadJson(`sift-${s.playlistName}.json`, exportSession(x)); }}><Icon name="download" size={18} /></button>
          <button className="icon-btn" aria-label="Delete" onClick={() => setDel(s)}><Icon name="x" size={18} /></button>
        </div>
      ))}
      <Confirm
        open={!!del}
        onClose={() => setDel(null)}
        title="Delete this session?"
        body={`Removes the local decisions for “${del?.playlistName}”. Your Spotify playlist isn't touched.`}
        confirmLabel="Delete session"
        danger
        onConfirm={() => del && void services().repo.remove(del.id).then(reload)}
      />
    </div>
  );
}
