import { useEffect, useMemo, useState } from "react";
import { fmtNum, fmtRelative, fmtTime } from "../../lib/format";
import { LATER_REF } from "../../review/applyPlanner";
import * as E from "../../review/reviewEngine";
import { useApp } from "../../state/appStore";
import { useReview } from "../../state/reviewStore";
import { navigate } from "../../state/router";
import { Icon } from "../components/Icon";
import { Confirm } from "../components/Sheet";

export function Summary({ id }: { id: string }) {
  const r = useReview();
  const app = useApp();
  const [confirm, setConfirm] = useState(false);
  const [confirmRestore, setConfirmRestore] = useState(false);

  useEffect(() => {
    void r.open(id);
    void app.loadLibrary();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const s = r.session;
  const c = s ? E.counts(s) : null;
  const plan = useMemo(() => (s ? r.plan() : null), [s, r, app.library, app.settings.laterPlaylistId]);
  if (!s || !c || !r.playlist)
    return (
      <div className="loading-screen">
        <div className="spinner" style={{ margin: "0 auto" }} />
      </div>
    );

  const nameOf = (t: string) =>
    t === LATER_REF ? "Sift · Later" : t.startsWith("new:") ? (s.pendingPlaylists.find((p) => p.tempId === t)?.name ?? "New playlist") : (app.library.find((p) => p.id === t)?.name ?? "Playlist");
  const ap = r.apply;
  const running = ap.phase === "running";
  const hasChanges = !!plan && plan.journal.steps.length > 0;
  const editable = r.playlist.editable;

  return (
    <div style={{ maxWidth: 720, margin: "0 auto" }}>
      <div className="topbar">
        <button className="icon-btn" onClick={() => navigate(`/review/${encodeURIComponent(id)}`)} aria-label="Back to review"><Icon name="back" /></button>
        <div className="grow eyebrow">Review summary</div>
        <span className="badge live">Synced {fmtTime(s.lastSyncedAt)}</span>
      </div>
      <h1 className="display" style={{ fontSize: "clamp(40px, 9vw, 72px)", margin: "24px 0 4px" }}>{r.playlist.name}</h1>
      <div className="muted">{fmtNum(c.total)} songs · {fmtNum(c.total - c.undecided)} decided</div>

      <div className="ledger">
        <Row k="Keep" v={c.keep} color="var(--keep)" onClick={() => go("keep")} />
        <Row k="Remove" v={c.remove} color="var(--cut)" onClick={() => go("remove")} />
        {Object.entries(c.byTarget).map(([t, n]) => (
          <Row key={t} k="File to" name={nameOf(t)} v={n} color="var(--file)" onClick={() => go("move")} />
        ))}
        <Row k="Undecided" v={c.undecided} color="var(--muted)" onClick={() => go("undecided")} />
      </div>

      {plan?.summary.warnings.map((w) => (
        <div key={w} className="banner" style={{ marginBottom: 10 }}>{w}</div>
      ))}

      {ap.phase === "conflict" && (
        <div className="banner error" style={{ flexDirection: "column", alignItems: "stretch", marginBottom: 14 }}>
          <strong>Someone changed this playlist on Spotify while you were sorting.</strong>
          <span>
            Your destination copies are done; nothing has been removed yet. Re-sync to see what changed first (your decisions stay attached to each song), or continue against the new version.
          </span>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <button className="btn small primary" onClick={() => void r.discardPending().then(() => r.resync())}>Re-sync & re-check</button>
            <button className="btn small" onClick={() => void r.applyChanges({ acceptSnapshot: ap.remoteSnapshot, journal: ap.journal })}>Continue anyway</button>
          </div>
        </div>
      )}
      {ap.phase === "paused" && (
        <div className="banner error" style={{ flexDirection: "column", alignItems: "stretch", marginBottom: 14 }}>
          <strong>Apply paused</strong>
          <span>{ap.message}</span>
          <span className="muted" style={{ fontSize: 14 }}>
            {ap.journal.steps.filter((x) => x.status === "done").length} of {ap.journal.steps.length} steps finished. Progress is saved; resuming skips what's done.
          </span>
          <div style={{ display: "flex", gap: 8 }}>
            {app.auth !== "signed_in" ? (
              <button className="btn small primary" onClick={() => void import("../../state/services").then(({ services }) => services().auth.login([], location.pathname))}>Sign in & resume</button>
            ) : (
              <button className="btn small primary" onClick={() => void r.applyChanges({ journal: ap.journal })}>Resume</button>
            )}
            <button className="btn small ghost" onClick={() => void r.discardPending()}>Discard remaining</button>
          </div>
        </div>
      )}
      {r.pendingJournal && ap.phase === "idle" && (
        <div className="banner" style={{ marginBottom: 14 }}>
          <span className="grow">An earlier apply stopped partway ({r.pendingJournal.steps.filter((x) => x.status === "done").length}/{r.pendingJournal.steps.length} steps). Resume it before starting a new one.</span>
          <button className="btn small primary" onClick={() => void r.applyChanges({ journal: r.pendingJournal! })}>Resume</button>
          <button className="btn small ghost" onClick={() => void r.discardPending()}>Discard</button>
        </div>
      )}

      {running && (
        <div className="panel" style={{ marginBottom: 14 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
            <strong>{ap.label}</strong>
            <span className="mono muted">{ap.done}/{ap.total}</span>
          </div>
          <div className="progress"><i style={{ width: `${(ap.done / Math.max(1, ap.total)) * 100}%` }} /></div>
          <p className="muted" style={{ fontSize: 14, marginBottom: 0 }}>Copies go to destinations first; removals happen last. Safe to close: it resumes where it stopped.</p>
        </div>
      )}

      {ap.phase === "done" && (
        <div className="panel" style={{ marginBottom: 14 }}>
          <span className="badge live">Synced with Spotify · {fmtTime(ap.at)}</span>
          <p style={{ margin: "12px 0 0" }}>
            Done. Sift re-read the playlist from Spotify afterwards, so what you see is what Spotify has.
          </p>
        </div>
      )}

      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
        <button className="btn primary" style={{ height: 54, padding: "0 26px", fontSize: 17 }} disabled={!hasChanges || running || !editable || !!r.pendingJournal} onClick={() => setConfirm(true)}>
          Apply changes to Spotify
        </button>
        <button className="btn" onClick={() => void r.resync()} disabled={running}><Icon name="refresh" size={18} /> Refresh from Spotify</button>
        <button className="btn ghost" onClick={r.exportJson}><Icon name="download" size={18} /> Export decisions</button>
      </div>
      {!editable && <p className="muted">This playlist is read-only for you, so nothing can be removed. Filed songs can still be copied from a playlist you can edit.</p>}
      {!hasChanges && editable && <p className="muted">Nothing to apply yet. Cut or file some songs first.</p>}

      {r.lastApplied && r.lastApplied.removed.length > 0 && !running && (
        <div className="panel" style={{ marginTop: 24 }}>
          <div className="eyebrow">Last applied {fmtRelative(r.lastApplied.finishedAt ?? r.lastApplied.createdAt)}</div>
          <p style={{ margin: "10px 0 14px" }}>
            Removed {fmtNum(r.lastApplied.removed.length)} songs from this playlist. Changed your mind? Put them back (added to the end, in their original order).
          </p>
          <button className="btn" onClick={() => setConfirmRestore(true)}><Icon name="undo" size={18} /> Put {fmtNum(r.lastApplied.removed.length)} songs back</button>
        </div>
      )}

      <Confirm
        open={confirm}
        onClose={() => setConfirm(false)}
        title="Send this to Spotify?"
        danger={!!plan?.summary.removeSongs}
        confirmLabel={plan?.summary.removeSongs ? `Remove ${fmtNum(plan.summary.removeSongs)} & apply` : "Apply"}
        onConfirm={() => void r.applyChanges()}
        body={
          plan && (
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {plan.summary.creates.length > 0 && <span>Create {plan.summary.creates.map((n) => `“${n}”`).join(", ")} (private unless you chose public).</span>}
              {plan.summary.addsByTarget.map((a) => (
                <span key={a.target}>Copy {fmtNum(a.count)} songs to “{nameOf(a.target)}”{app.settings.skipExisting ? " (skipping ones already there)" : ""}.</span>
              ))}
              {plan.summary.removeSongs > 0 && (
                <span style={{ color: "var(--cut)" }}>
                  Remove {fmtNum(plan.summary.removeSongs)} songs from “{r.playlist.name}”.
                </span>
              )}
              <span style={{ fontSize: 14 }}>About {fmtNum(plan.summary.requests)} requests. Sift checks the playlist hasn't changed before removing anything, and you can put removed songs back afterwards.</span>
            </div>
          )
        }
      />
      <Confirm
        open={confirmRestore}
        onClose={() => setConfirmRestore(false)}
        title="Put songs back?"
        body={`Re-adds ${fmtNum(r.lastApplied?.removed.length ?? 0)} songs to the end of “${r.playlist.name}”. Songs already in the playlist are skipped.`}
        confirmLabel="Put them back"
        onConfirm={() => void r.restoreLast()}
      />
    </div>
  );

  function go(f: "keep" | "remove" | "move" | "undecided") {
    r.setFilter(f);
    navigate(`/review/${encodeURIComponent(id)}`);
  }
}

function Row({ k, v, color, name, onClick }: { k: string; v: number; color: string; name?: string; onClick: () => void }) {
  return (
    <button className="row" onClick={onClick} style={{ textAlign: "left" }} disabled={!v}>
      <span className="k">
        <i className="dot" style={{ background: color }} />
        {k} {name && <em>“{name}”</em>}
      </span>
      <span className="v" style={{ color: v ? "var(--text)" : "var(--muted)" }}>{fmtNum(v)}</span>
    </button>
  );
}
