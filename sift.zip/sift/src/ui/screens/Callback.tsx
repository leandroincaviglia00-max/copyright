import { useEffect, useRef, useState } from "react";
import { AuthError } from "../../spotify/auth/authService";
import { useApp } from "../../state/appStore";
import { navigate } from "../../state/router";
import { services } from "../../state/services";

export function Callback() {
  const [err, setErr] = useState<string | null>(null);
  const ran = useRef(false);
  useEffect(() => {
    if (ran.current) return; // StrictMode double-invoke: codes are single-use
    ran.current = true;
    services()
      .auth.handleCallback(location.search)
      .then(async (to) => {
        await useApp.getState().boot();
        navigate(to, true);
      })
      .catch((e) => setErr(e instanceof AuthError ? e.message : "Sign-in failed. Please try again."));
  }, []);
  return (
    <div className="loading-screen">
      {err ? (
        <div className="empty">
          <h2>Didn't connect.</h2>
          <p>{err}</p>
          <button className="btn primary" onClick={() => navigate("/", true)}>Try again</button>
        </div>
      ) : (
        <>
          <div className="spinner" style={{ margin: "0 auto" }} />
          <div className="mono muted">Connecting to Spotify…</div>
        </>
      )}
    </div>
  );
}
