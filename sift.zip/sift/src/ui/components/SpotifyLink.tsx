/**
 * Attribution + deep link back to Spotify, required wherever Spotify
 * metadata or artwork is shown. Drop Spotify's official logo files into
 * /public (see docs/SETUP.md → "Branding"); until then a text label is used.
 */
import { useState } from "react";

export function SpotifyLink({ href, label = "Open in Spotify", className = "sp" }: { href?: string; label?: string; className?: string }) {
  const [logoOk, setLogoOk] = useState(true);
  if (!href) return null;
  return (
    <a className={className} href={href} target="_blank" rel="noreferrer noopener" onPointerDown={(e) => e.stopPropagation()} aria-label={label}>
      {logoOk && <img src="/spotify-icon.svg" alt="" width={16} height={16} onError={() => setLogoOk(false)} />}
      <span>{label}</span>
    </a>
  );
}
