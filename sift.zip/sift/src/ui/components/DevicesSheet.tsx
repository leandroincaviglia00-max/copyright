import { useEffect, useState } from "react";
import type { SpDevice } from "../../spotify/api/types";
import { describeApiError } from "../../spotify/api/errors";
import { services } from "../../state/services";
import { usePlayback } from "../hooks/usePlayback";
import { Icon } from "./Icon";
import { Sheet } from "./Sheet";

const SDK_COPY: Record<string, string> = {
  off: "Not connected yet.",
  loading: "Connecting…",
  ready: "Ready: full tracks play right here.",
  not_premium: "Needs Spotify Premium. Using previews.",
  auth_error: "Couldn't authenticate. Sign out and in again.",
  unsupported: "This browser can't run Spotify's player.",
  error: "Player offline. Try reconnecting.",
};

export function DevicesSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const pb = usePlayback();
  const pc = services().playback;
  const [devices, setDevices] = useState<SpDevice[]>([]);
  const [err, setErr] = useState<string | null>(null);
  const refresh = () =>
    pc.listDevices().then(
      (d) => (setDevices(d), setErr(null)),
      (e) => setErr(describeApiError(e, "listing devices")),
    );
  useEffect(() => {
    if (open) void refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);
  const others = devices.filter((d) => d.id !== pb.sdkDeviceId);
  return (
    <Sheet open={open} onClose={onClose} label="Where to listen">
      <h2>Where to listen</h2>
      <div className="scroll">
        <button className="dest" aria-pressed={!pb.device || pb.device.id === pb.sdkDeviceId} onClick={() => (pc.useRemoteDevice(null), void pc.connectSdk(), void pc.unlock())}>
          <span className="ph" style={{ display: "grid", placeItems: "center" }}>
            <Icon name="play" />
          </span>
          <span className="nm">
            This browser (Spotify Web Playback)
            <br />
            <small className="muted">{SDK_COPY[pb.sdk]}</small>
          </span>
          <span className="ck">{(!pb.device || pb.device.id === pb.sdkDeviceId) && <Icon name="check" size={16} />}</span>
        </button>
        {others.map((d) => (
          <button key={d.id} className="dest" aria-pressed={pb.device?.id === d.id} onClick={() => pc.useRemoteDevice({ id: d.id!, name: d.name, type: d.type })}>
            <span className="ph" style={{ display: "grid", placeItems: "center" }}>
              <Icon name="device" />
            </span>
            <span className="nm">
              {d.name}
              <br />
              <small className="muted">{d.type}{d.is_active ? " · active" : ""}</small>
            </span>
            <span className="ck">{pb.device?.id === d.id && <Icon name="check" size={16} />}</span>
          </button>
        ))}
        {err && <p className="muted">{err}</p>}
        <p className="muted" style={{ fontSize: 14 }}>
          Full tracks need Spotify Premium. Without it, Sift uses Spotify's 30-second previews where Spotify provides one, otherwise “Open in Spotify”. Audio is always streamed by Spotify and never saved.
        </p>
      </div>
      <div className="sheet-foot">
        <button className="btn small" onClick={refresh}>
          <Icon name="refresh" size={18} /> Refresh devices
        </button>
        <span style={{ flex: 1 }} />
        <button className="btn small primary" onClick={onClose}>
          Done
        </button>
      </div>
    </Sheet>
  );
}
