import { useEffect, useMemo, useState } from "react";
import type { PlaylistSummary } from "../../playlists/model";
import { LATER_REF } from "../../review/applyPlanner";
import type { Decision, PendingPlaylist } from "../../review/types";
import { Icon } from "./Icon";
import { Sheet } from "./Sheet";

interface Props {
  open: boolean;
  onClose: () => void;
  source: PlaylistSummary;
  library: PlaylistSummary[];
  pending: PendingPlaylist[];
  recent: string[];
  songName: string;
  onDecide: (d: Decision) => void;
  onCreatePending: (p: { name: string; description: string; public: boolean }) => string;
}

export function MoveSheet({ open, onClose, source, library, pending, recent, songName, onDecide, onCreatePending }: Props) {
  const [q, setQ] = useState("");
  const [sel, setSel] = useState<string[]>([]);
  const [copy, setCopy] = useState(false);
  const [creating, setCreating] = useState(false);
  const [draft, setDraft] = useState({ name: "", description: "", public: false });

  useEffect(() => {
    if (open) {
      setQ("");
      setSel([]);
      setCreating(false);
      setDraft({ name: "", description: "", public: false });
    }
  }, [open]);

  const options = useMemo(() => {
    const drafts = pending.filter((p) => !p.createdId).map((p) => ({ id: p.tempId, name: p.name, image: null as string | null, sub: `New · ${p.public ? "public" : "private"}` }));
    const lib = library
      .filter((p) => p.editable && p.id !== source.id)
      .map((p) => ({ id: p.id, name: p.name, image: p.image, sub: `${p.total} songs${p.isPublic ? "" : " · private"}` }));
    const rank = (id: string) => (recent.includes(id) ? recent.indexOf(id) : 999);
    const all = [...drafts, ...lib].sort((a, b) => rank(a.id) - rank(b.id));
    const needle = q.trim().toLowerCase();
    return needle ? all.filter((o) => o.name.toLowerCase().includes(needle)) : all;
  }, [library, pending, q, recent, source.id]);

  const toggle = (id: string) => setSel((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));
  const commit = (targets: string[], keepInSource = copy) => {
    if (!targets.length) return;
    onDecide({ kind: "move", targets, keepInSource });
    onClose();
  };
  const create = () => {
    if (!draft.name.trim()) return;
    const id = onCreatePending({ ...draft, name: draft.name.trim() });
    setSel((s) => [...s, id]);
    setCreating(false);
    setDraft({ name: "", description: "", public: false });
  };

  return (
    <Sheet open={open} onClose={onClose} label="File this song">
      <h2>
        File <span style={{ color: "var(--file)" }}>“{songName}”</span>
      </h2>
      <div className="quick">
        <button onClick={() => commit([LATER_REF], true)}>
          <span><Icon name="bookmark" size={18} /> Save for later</span>
          <small>Copy to “Sift · Later”, keep here</small>
        </button>
        <button onClick={() => (onDecide({ kind: "keep" }), onClose())}>
          <span style={{ color: "var(--keep)" }}><Icon name="heart" size={18} /> Keep here</span>
          <small>No move, just keep</small>
        </button>
        {source.editable && (
          <button onClick={() => (onDecide({ kind: "remove" }), onClose())} style={{ gridColumn: "span 2" }}>
            <span style={{ color: "var(--cut)" }}><Icon name="x" size={18} /> Remove completely</span>
            <small>Cut from “{source.name}”, don't file anywhere</small>
          </button>
        )}
      </div>

      <input className="input" placeholder="Search your playlists" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search playlists" />
      <div className="scroll" style={{ marginTop: 8, maxHeight: "34dvh" }}>
        {creating ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 10, padding: "8px 0" }}>
            <input className="input" autoFocus placeholder="Playlist name" value={draft.name} maxLength={100} onChange={(e) => setDraft({ ...draft, name: e.target.value })} onKeyDown={(e) => e.key === "Enter" && create()} />
            <textarea className="input" rows={2} placeholder="Description (optional)" value={draft.description} maxLength={300} onChange={(e) => setDraft({ ...draft, description: e.target.value })} />
            <label className="toggle">
              <input type="checkbox" checked={draft.public} onChange={(e) => setDraft({ ...draft, public: e.target.checked })} />
              {draft.public ? "Public on your profile" : "Private (recommended for sorting)"}
            </label>
            <div style={{ display: "flex", gap: 8 }}>
              <button className="btn small" onClick={() => setCreating(false)}>Cancel</button>
              <button className="btn small primary" onClick={create} disabled={!draft.name.trim()}>Add as destination</button>
            </div>
            <small className="muted">It's created on Spotify only when you apply changes.</small>
          </div>
        ) : (
          <button className="dest" onClick={() => (setCreating(true), setDraft((d) => ({ ...d, name: q })))}>
            <span className="ph" style={{ display: "grid", placeItems: "center" }}><Icon name="plus" /></span>
            <span className="nm">New playlist{q ? ` “${q}”` : ""}</span>
          </button>
        )}
        {options.map((o) => (
          <button key={o.id} className="dest" aria-pressed={sel.includes(o.id)} onClick={() => toggle(o.id)} onDoubleClick={() => commit([o.id])}>
            {o.image ? <img src={o.image} alt="" /> : <span className="ph" />}
            <span className="nm">
              {o.name}
              <br />
              <small className="muted">{o.sub}</small>
            </span>
            <span className="ck">{sel.includes(o.id) && <Icon name="check" size={16} />}</span>
          </button>
        ))}
        {!options.length && <p className="muted">No editable playlists match.</p>}
      </div>
      <div className="sheet-foot">
        {source.editable ? (
          <label className="toggle">
            <input type="checkbox" checked={copy} onChange={(e) => setCopy(e.target.checked)} />
            Also keep in this playlist
          </label>
        ) : (
          <small className="muted">Read-only source: songs are copied.</small>
        )}
        <span style={{ flex: 1 }} />
        <button className="btn primary" disabled={!sel.length} onClick={() => commit(sel, source.editable ? copy : true)}>
          {copy || !source.editable ? "Copy" : "Move"} to {sel.length || ""} {sel.length === 1 ? "playlist" : "playlists"}
        </button>
      </div>
    </Sheet>
  );
}
