import { useRef } from "react";
import { fmtDuration } from "../../lib/format";
import type { PlaybackSnapshot } from "../../playback/playbackController";
import { services } from "../../state/services";

const MODE_LABEL: Record<PlaybackSnapshot["mode"], string> = {
  full: "FULL TRACK",
  remote: "ON DEVICE",
  preview: "30s PREVIEW",
  none: "NO AUDIO",
};

export function PlayerStrip({ pb, onDevices }: { pb: PlaybackSnapshot; onDevices: () => void }) {
  const bar = useRef<HTMLDivElement>(null);
  const pct = pb.durationMs ? Math.min(100, (pb.positionMs / pb.durationMs) * 100) : 0;
  const seek = (e: React.PointerEvent) => {
    const r = bar.current!.getBoundingClientRect();
    const f = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
    void services().playback.seek(f * pb.durationMs);
  };
  const where = pb.mode === "full" ? "this browser" : pb.mode === "remote" ? pb.device?.name : null;
  return (
    <>
      <div className="player">
        <button className={`mode ${pb.mode}`} onClick={onDevices} title="Choose where to listen">
          {MODE_LABEL[pb.mode]}
        </button>
        <div className="bar" ref={bar} onPointerDown={pb.mode !== "none" ? seek : undefined} role="slider" aria-label="Seek" aria-valuemin={0} aria-valuemax={pb.durationMs} aria-valuenow={pb.positionMs}>
          <i style={{ width: `${pct}%` }} />
        </div>
        <span className="t">{pb.mode === "none" ? "–:––" : fmtDuration(pb.positionMs)}</span>
      </div>
      <div className="player-note">{pb.message ?? (where ? `Playing on ${where}` : pb.loading ? "Cueing…" : "\u00a0")}</div>
    </>
  );
}
