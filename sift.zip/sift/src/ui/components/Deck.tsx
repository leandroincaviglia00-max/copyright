import { forwardRef, useImperativeHandle, type ReactNode } from "react";
import { useSwipe, type SwipeDir } from "../hooks/useSwipe";
import { SpotifyLink } from "./SpotifyLink";

export interface SleeveData {
  key: string;
  image: string | null;
  title: string;
  artist: string;
  meta: string[];
  url?: string;
  kindLabel?: string;
  decided?: { label: string; color: string } | null;
  extra?: ReactNode;
}

export interface DeckHandle {
  fling(dir: SwipeDir): void;
}

interface Props {
  cards: SleeveData[]; // [top, next, after]
  onCommit: (dir: SwipeDir) => void;
  onDragStart?: () => void;
  playing: boolean;
  enter?: "left" | "right" | "up" | "rise" | null;
  labels?: { keep: string; cut: string; file: string };
  allowLeft?: boolean;
  allowUp?: boolean;
}

export const Deck = forwardRef<DeckHandle, Props>(function Deck(
  { cards, onCommit, onDragStart, playing, enter, labels = { keep: "Keep", cut: "Cut", file: "File" }, allowLeft = true, allowUp = true },
  ref,
) {
  const top = cards[0];
  const { ref: el, fling } = useSwipe<HTMLDivElement>({ onCommit, onDragStart, enabled: !!top, allowLeft, allowUp });
  useImperativeHandle(ref, () => ({ fling: (d) => fling(d) }), [fling]);

  return (
    <div className="deck" aria-live="polite">
      {cards
        .slice(1, 3)
        .reverse()
        .map((c, i, arr) => (
          <Sleeve key={c.key} data={c} className={`behind behind-${arr.length - i}`} />
        ))}
      {top && (
        <Sleeve
          key={top.key}
          data={top}
          innerRef={el}
          className={`top ${enter ? `enter-${enter}` : ""}`}
          playing={playing}
          labels={labels}
        />
      )}
    </div>
  );
});

function Sleeve({
  data,
  className,
  innerRef,
  playing = false,
  labels,
}: {
  data: SleeveData;
  className: string;
  innerRef?: React.Ref<HTMLDivElement>;
  playing?: boolean;
  labels?: { keep: string; cut: string; file: string };
}) {
  return (
    <div ref={innerRef} className={`sleeve ${className}`} data-playing={playing} role="group" aria-label={`${data.title} by ${data.artist}`}>
      <div className="edge" />
      <div className="disc">
        <div className="disc-spin" />
      </div>
      <div className="art">
        {data.image ? <img src={data.image} alt={`Cover art: ${data.meta[0] ?? data.title}`} draggable={false} /> : <div className="noart">♪</div>}
      </div>
      <div className="label">
        {data.kindLabel && <span className="kind">{data.kindLabel}</span>}
        <SpotifyLink href={data.url} label="Spotify" />
        <div className="t" style={{ paddingRight: data.url ? 92 : 0 }}>
          {data.title}
        </div>
        <div className="a">{data.artist}</div>
        <div className="m">
          {data.meta.map((m, i) => (
            <span key={i}>{m}</span>
          ))}
        </div>
        {data.extra}
        {labels && (
          <>
            <span className="stamp keep">{labels.keep}</span>
            <span className="stamp cut">{labels.cut}</span>
            <span className="stamp file">{labels.file}</span>
          </>
        )}
      </div>
      {data.decided && (
        <span className="decided-tag" style={{ background: data.decided.color }}>
          {data.decided.label}
        </span>
      )}
    </div>
  );
}
