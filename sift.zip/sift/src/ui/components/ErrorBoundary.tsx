import { Component, type ReactNode } from "react";

export class ErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state = { error: null as Error | null };
  static getDerivedStateFromError(error: Error) {
    return { error };
  }
  componentDidCatch(error: Error) {
    console.error("[sift] UI crash", error);
  }
  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="empty" style={{ minHeight: "100dvh", justifyContent: "center" }}>
        <h2 className="display">Needle skipped.</h2>
        <p>Something broke in the interface. Your review decisions are saved on this device, so nothing is lost.</p>
        <p className="mono muted">{this.state.error.message}</p>
        <button className="btn primary" onClick={() => location.reload()}>
          Reload Sift
        </button>
      </div>
    );
  }
}
