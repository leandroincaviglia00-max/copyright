import { describe, expect, it } from "vitest";
import { AuthService, AUTHORIZE_URL } from "../src/spotify/auth/authService";
import { CORE_SCOPES, HISTORY_SCOPES } from "../src/spotify/auth/scopes";
import { MemoryStorage } from "../src/spotify/auth/tokenStore";
import { mockFetch } from "./helpers";

function setup(routes: Parameters<typeof mockFetch>[0] = {}, now = { t: 1_000_000 }) {
  const m = mockFetch(routes);
  const storage = new MemoryStorage();
  const pending = new MemoryStorage();
  let navigated = "";
  const auth = new AuthService({
    clientId: "cid",
    redirectUri: "http://127.0.0.1:5173/callback",
    storage,
    pendingStorage: pending,
    fetch: m.fetch,
    now: () => now.t,
    navigate: (u) => (navigated = u),
  });
  return { auth, m, storage, now, nav: () => navigated };
}

const tokenOk = (over: Record<string, unknown> = {}) => () => ({ json: { access_token: "A1", refresh_token: "R1", expires_in: 3600, scope: CORE_SCOPES.join(" "), token_type: "Bearer", ...over } });

describe("AuthService (Authorization Code + PKCE)", () => {
  it("builds an authorize URL with S256 challenge, state, and only core scopes", async () => {
    const { auth } = setup();
    const url = new URL(await auth.buildAuthorizeUrl());
    expect(url.origin + url.pathname).toBe(AUTHORIZE_URL);
    expect(url.searchParams.get("response_type")).toBe("code");
    expect(url.searchParams.get("code_challenge_method")).toBe("S256");
    expect(url.searchParams.get("client_id")).toBe("cid");
    expect((url.searchParams.get("state") ?? "").length).toBeGreaterThan(40);
    const scopes = url.searchParams.get("scope")!.split(" ");
    expect(scopes.sort()).toEqual([...CORE_SCOPES].sort());
    expect(scopes.includes("user-read-recently-played")).toBe(false);
    expect(url.searchParams.has("client_secret")).toBe(false);
  });

  it("adds history scopes only when explicitly requested", async () => {
    const { auth } = setup();
    const url = new URL(await auth.buildAuthorizeUrl(HISTORY_SCOPES));
    expect(url.searchParams.get("scope")!.includes("user-top-read")).toBe(true);
  });

  it("exchanges the code with the stored verifier and persists tokens", async () => {
    const { auth, m } = setup({ "POST /api/token": tokenOk() });
    const url = new URL(await auth.buildAuthorizeUrl([], "/review/abc"));
    const state = url.searchParams.get("state");
    const to = await auth.handleCallback(`?code=CODE&state=${state}`);
    expect(to).toBe("/review/abc");
    const body = new URLSearchParams(m.calls[0].body as string);
    expect(body.get("grant_type")).toBe("authorization_code");
    expect(body.get("code")).toBe("CODE");
    expect(body.get("client_id")).toBe("cid");
    expect((body.get("code_verifier") ?? "").length).toBe(64);
    expect(body.has("client_secret")).toBe(false);
    expect(await auth.getAccessToken()).toBe("A1");
    expect(auth.state().status).toBe("signed_in");
  });

  it("rejects a callback whose state doesn't match (CSRF)", async () => {
    const { auth } = setup({ "POST /api/token": tokenOk() });
    await auth.buildAuthorizeUrl();
    await expect(auth.handleCallback("?code=X&state=evil")).rejects.toMatchObject({ kind: "state_mismatch" });
  });

  it("surfaces access_denied clearly", async () => {
    const { auth } = setup();
    await auth.buildAuthorizeUrl();
    await expect(auth.handleCallback("?error=access_denied")).rejects.toMatchObject({ kind: "denied" });
  });

  it("refreshes before expiry, keeps the old refresh token if none is rotated", async () => {
    const now = { t: 1_000_000 };
    const { auth, m } = setup({ "POST /api/token": [tokenOk(), tokenOk({ access_token: "A2", refresh_token: undefined })] }, now);
    const st = new URL(await auth.buildAuthorizeUrl()).searchParams.get("state");
    await auth.handleCallback(`?code=C&state=${st}`);
    now.t += 3600_000 - 30_000; // inside the 60s skew window
    expect(await auth.getAccessToken()).toBe("A2");
    const body = new URLSearchParams(m.calls[1].body as string);
    expect(body.get("grant_type")).toBe("refresh_token");
    expect(body.get("refresh_token")).toBe("R1");
    // still has R1 for the next refresh
    now.t += 3600_000;
    m.calls.length = 0;
    await auth.getAccessToken().catch(() => undefined);
    expect(new URLSearchParams(m.calls[0].body as string).get("refresh_token")).toBe("R1");
  });

  it("de-duplicates concurrent refreshes (single flight)", async () => {
    const now = { t: 0 };
    const { auth, m } = setup({ "POST /api/token": [tokenOk({ expires_in: 1 }), tokenOk({ access_token: "A2" })] }, now);
    const st = new URL(await auth.buildAuthorizeUrl()).searchParams.get("state");
    await auth.handleCallback(`?code=C&state=${st}`);
    now.t = 10_000;
    const [a, b, c] = await Promise.all([auth.getAccessToken(), auth.getAccessToken(), auth.getAccessToken()]);
    expect([a, b, c]).toEqual(["A2", "A2", "A2"]);
    expect(m.calls.length).toBe(2);
  });

  it("marks the session expired when the refresh token is revoked", async () => {
    const now = { t: 0 };
    const { auth } = setup({ "POST /api/token": [tokenOk({ expires_in: 1 }), () => ({ status: 400, json: { error: "invalid_grant" } })] }, now);
    const st = new URL(await auth.buildAuthorizeUrl()).searchParams.get("state");
    await auth.handleCallback(`?code=C&state=${st}`);
    const events: string[] = [];
    auth.changes.on((s) => events.push(s.status));
    now.t = 10_000;
    await expect(auth.getAccessToken()).rejects.toMatchObject({ kind: "expired" });
    expect(events).toContain("expired");
    expect(auth.state().status).toBe("signed_out");
  });

  it("logout clears tokens", async () => {
    const { auth } = setup({ "POST /api/token": tokenOk() });
    const st = new URL(await auth.buildAuthorizeUrl()).searchParams.get("state");
    await auth.handleCallback(`?code=C&state=${st}`);
    auth.logout();
    expect(auth.state().status).toBe("signed_out");
    await expect(auth.getAccessToken()).rejects.toMatchObject({ kind: "not_signed_in" });
  });
});
