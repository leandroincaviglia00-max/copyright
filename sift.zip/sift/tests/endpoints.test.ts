import { describe, expect, it } from "vitest";
import { SpotifyClient } from "../src/spotify/api/client";
import { SpotifyApi } from "../src/spotify/api/endpoints";
import { PlaylistService } from "../src/playlists/playlistService";
import { MemoryKV } from "../src/persistence/kv";
import { toEntries, toSummary } from "../src/playlists/model";
import { mockFetch, noSleep, rawItems, staticAuth } from "./helpers";

const mk = (routes: Parameters<typeof mockFetch>[0]) => {
  const m = mockFetch(routes);
  const api = new SpotifyApi(new SpotifyClient({ auth: staticAuth, fetch: m.fetch, sleep: noSleep }));
  return { m, api };
};

describe("current (2026) Spotify endpoints", () => {
  it("reads playlist contents from /items, never /tracks", async () => {
    const { m, api } = mk({ "GET /v1/playlists/p1/items": () => ({ json: { items: [], total: 0, limit: 50, offset: 0, next: null } }) });
    await api.playlistItemsPage("p1", 0);
    expect(m.calls[0].url.pathname).toBe("/v1/playlists/p1/items");
    expect(m.calls[0].url.searchParams.get("limit")).toBe("50");
    expect(m.calls[0].url.searchParams.get("additional_types")).toBe("track,episode");
    expect(m.calls.some((c) => c.url.pathname.endsWith("/tracks"))).toBe(false);
  });

  it("removes with DELETE /items and the renamed `items` body + snapshot", async () => {
    const { m, api } = mk({ "DELETE /v1/playlists/p1/items": () => ({ json: { snapshot_id: "s2" } }) });
    const r = await api.removeItems("p1", ["spotify:track:a", "spotify:track:b"], "s1");
    expect(r.snapshot_id).toBe("s2");
    expect(m.calls[0].body).toEqual({ items: [{ uri: "spotify:track:a" }, { uri: "spotify:track:b" }], snapshot_id: "s1" });
  });

  it("adds with POST /items and supports position", async () => {
    const { m, api } = mk({ "POST /v1/playlists/p1/items": () => ({ status: 201, json: { snapshot_id: "s3" } }) });
    await api.addItems("p1", ["spotify:track:a"], 4);
    expect(m.calls[0].body).toEqual({ uris: ["spotify:track:a"], position: 4 });
  });

  it("refuses batches over 100", async () => {
    const { api } = mk({});
    expect(() => api.removeItems("p", Array.from({ length: 101 }, (_, i) => `spotify:track:${i}`))).toThrow();
  });

  it("creates playlists with POST /me/playlists (not /users/{id}/playlists)", async () => {
    const { m, api } = mk({ "POST /v1/me/playlists": () => ({ status: 201, json: { id: "new1" } }) });
    await api.createPlaylist({ name: "Late night", description: "d", public: false });
    expect(m.calls[0].url.pathname).toBe("/v1/me/playlists");
    expect(m.calls[0].body).toEqual({ name: "Late night", description: "d", public: false, collaborative: false });
  });

  it("caps search at the new max limit of 10", async () => {
    const { m, api } = mk({ "GET /v1/search": () => ({ json: { tracks: { items: [], total: 0 } } }) });
    await api.searchTracks('artist:"X"');
    expect(m.calls[0].url.searchParams.get("limit")).toBe("10");
  });
});

describe("PlaylistService", () => {
  const ids = Array.from({ length: 123 }, (_, i) => `t${i}`);
  const all = rawItems(ids);
  const page = (off: number) => ({ items: all.slice(off, off + 50), total: all.length, limit: 50, offset: off, next: null });
  const meta = (snap: string) => () => ({ json: { id: "p1", name: "P", snapshot_id: snap, owner: { id: "me", display_name: "Me" }, collaborative: false, public: false, images: [], uri: "spotify:playlist:p1", items: { total: all.length } } });

  it("paginates every page and caches by snapshot", async () => {
    const { m, api } = mk({
      "GET /v1/playlists/p1": meta("s1"),
      "GET /v1/playlists/p1/items": (c) => ({ json: page(Number(c.url.searchParams.get("offset"))) }),
    });
    const svc = new PlaylistService(api, new MemoryKV(), () => "me");
    const a = await svc.load("p1");
    expect(a.entries).toHaveLength(123);
    expect(a.entries[122].name).toBe("Song t122");
    expect(a.fromCache).toBe(false);
    const itemCalls = m.calls.filter((c) => c.url.pathname.endsWith("/items")).length;
    expect(itemCalls).toBe(3);
    const b = await svc.load("p1");
    expect(b.fromCache).toBe(true);
    expect(m.calls.filter((c) => c.url.pathname.endsWith("/items")).length).toBe(3); // no re-download
  });

  it("refuses playlists the user neither owns nor collaborates on", async () => {
    const { api } = mk({ "GET /v1/playlists/p1": () => ({ json: { id: "p1", name: "Theirs", snapshot_id: "s", owner: { id: "someone" }, collaborative: false, public: true, images: [], uri: "u" } }) });
    const svc = new PlaylistService(api, new MemoryKV(), () => "me");
    await expect(svc.load("p1")).rejects.toMatchObject({ kind: "forbidden" });
  });
});

describe("model mapping", () => {
  it("reads the renamed `item` field and falls back to `track`", () => {
    const [a, b] = toEntries([
      { added_at: null, is_local: false, item: { type: "track", id: "x", uri: "spotify:track:x", name: "X", duration_ms: 1, album: { id: null, name: "A", images: [] }, artists: [] } as never },
      { added_at: null, is_local: false, track: { type: "track", id: "y", uri: "spotify:track:y", name: "Y", duration_ms: 1, album: { id: null, name: "B", images: [] }, artists: [] } as never },
    ]);
    expect(a.name).toBe("X");
    expect(b.name).toBe("Y");
  });

  it("keys duplicates by occurrence and flags episodes / local / unknown", () => {
    const es = toEntries([
      ...rawItems(["a", "a"]),
      { added_at: null, is_local: false, item: { type: "episode", id: "e", uri: "spotify:episode:e", name: "Ep", duration_ms: 1 } as never },
      { added_at: null, is_local: true, item: { type: "track", id: null, uri: "spotify:local:x", name: "L", duration_ms: 1, album: { id: null, name: "", images: [] }, artists: [] } as never },
      { added_at: null, is_local: false, item: { type: "audiobook_chapter", uri: "spotify:x:y", name: "?" } as never },
    ]);
    expect(es.map((e) => e.key).slice(0, 2)).toEqual(["spotify:track:a::0", "spotify:track:a::1"]);
    expect(es.map((e) => e.kind)).toEqual(["track", "track", "episode", "local", "unknown"]);
  });

  it("reads the playlist item total from the renamed `items` field", () => {
    const s = toSummary({ id: "p", name: "P", collaborative: true, public: null, snapshot_id: "s", images: null, owner: { id: "x", display_name: "X" }, uri: "u", items: { total: 7 } }, "me");
    expect(s.total).toBe(7);
    expect(s.editable).toBe(true);
  });
});
