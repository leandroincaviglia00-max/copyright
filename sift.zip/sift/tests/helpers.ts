import { toEntries, type PlaylistEntry } from "../src/playlists/model";
import type { SpPlaylistItem } from "../src/spotify/api/types";

export interface Call {
  url: URL;
  method: string;
  body: unknown;
  headers: Record<string, string>;
}

type Handler = (c: Call) => Response | Promise<Response> | { status?: number; json?: unknown; headers?: Record<string, string> };

/** Route table keyed by "METHOD /path" (query ignored). Handlers can be queues. */
export function mockFetch(routes: Record<string, Handler | Handler[]>) {
  const calls: Call[] = [];
  const queues = new Map<string, Handler[]>();
  for (const [k, v] of Object.entries(routes)) queues.set(k, Array.isArray(v) ? [...v] : [v]);
  const f = (async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = new URL(String(input));
    const method = (init?.method ?? "GET").toUpperCase();
    let body: unknown = init?.body;
    if (typeof body === "string") {
      try {
        body = JSON.parse(body);
      } catch {
        /* form body */
      }
    }
    const call: Call = { url, method, body, headers: (init?.headers ?? {}) as Record<string, string> };
    calls.push(call);
    const key = `${method} ${url.pathname}`;
    const q = queues.get(key) ?? [...queues.entries()].find(([k]) => new RegExp("^" + k.replace(/\*/g, "[^/]+") + "$").test(key))?.[1];
    if (!q || !q.length) return new Response(JSON.stringify({ error: { status: 404, message: `no route ${key}` } }), { status: 404 });
    const h = q.length > 1 ? q.shift()! : q[0];
    const r = await h(call);
    if (r instanceof Response) return r;
    const status = r.status ?? 200;
    return new Response(r.json === undefined ? null : JSON.stringify(r.json), { status, headers: { "Content-Type": "application/json", ...(r.headers ?? {}) } });
  }) as typeof fetch;
  return { fetch: f, calls };
}

export const netError: Handler = () => {
  throw new TypeError("Failed to fetch");
};

export const staticAuth = { getAccessToken: async () => "tok", refresh: async () => undefined };
export const noSleep = async () => undefined;

export function track(id: string, over: Partial<Record<string, unknown>> = {}) {
  return {
    type: "track",
    id,
    uri: `spotify:track:${id}`,
    name: `Song ${id}`,
    duration_ms: 200_000,
    explicit: false,
    preview_url: null,
    external_urls: { spotify: `https://open.spotify.com/track/${id}` },
    album: { id: `al${id}`, name: `Album ${id}`, images: [{ url: `https://i.scdn.co/image/${id}`, width: 640, height: 640 }], release_date: "1998-05-01" },
    artists: [{ id: `ar${id}`, name: `Artist ${id}`, uri: `spotify:artist:ar${id}` }],
    ...over,
  };
}

export function rawItems(ids: string[]): SpPlaylistItem[] {
  return ids.map((id) => ({ added_at: "2020-01-01T00:00:00Z", added_by: { id: "me" }, is_local: false, item: track(id) as never }));
}

export function entries(ids: string[]): PlaylistEntry[] {
  return toEntries(rawItems(ids));
}
