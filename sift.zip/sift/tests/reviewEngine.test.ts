import { describe, expect, it } from "vitest";
import * as E from "../src/review/reviewEngine";
import { entries } from "./helpers";

const P = { id: "p1", name: "Mix", image: null, snapshotId: "s1" };
const fresh = () => E.createSession(P, entries(["a", "b", "c", "d"]), 0);
const k = (id: string) => `spotify:track:${id}::0`;

describe("review engine", () => {
  it("starts at the first card and advances on decisions", () => {
    let s = fresh();
    expect(E.current(s)).toBe(k("a"));
    s = E.decide(s, k("a"), { kind: "keep" }, 1);
    expect(E.current(s)).toBe(k("b"));
    s = E.decide(s, k("b"), { kind: "remove" }, 2);
    s = E.decide(s, k("c"), { kind: "move", targets: ["x"], keepInSource: false }, 3);
    expect(E.counts(s)).toMatchObject({ total: 4, keep: 1, remove: 1, move: 1, undecided: 1, byTarget: { x: 1 } });
  });

  it("undo restores the previous decision and shows that card; redo re-applies", () => {
    let s = fresh();
    s = E.decide(s, k("a"), { kind: "remove" });
    s = E.decide(s, k("b"), { kind: "keep" });
    s = E.undo(s);
    expect(s.decisions[k("b")]).toBe(undefined);
    expect(E.current(s)).toBe(k("b"));
    s = E.undo(s);
    expect(E.counts(s).undecided).toBe(4);
    expect(E.canRedo(s)).toBe(true);
    s = E.redo(s);
    expect(s.decisions[k("a")].kind).toBe("remove");
    expect(E.current(s)).toBe(k("b"));
  });

  it("a new decision clears the redo stack", () => {
    let s = E.undo(E.decide(fresh(), k("a"), { kind: "keep" }));
    s = E.decide(s, k("a"), { kind: "remove" });
    expect(E.canRedo(s)).toBe(false);
  });

  it("changing a decision is itself undoable", () => {
    let s = E.decide(fresh(), k("a"), { kind: "keep" });
    s = E.goTo(s, k("a"));
    s = E.decide(s, k("a"), { kind: "remove" });
    s = E.undo(s);
    expect(s.decisions[k("a")].kind).toBe("keep");
  });

  it("filters: undecided / removed / moved queues", () => {
    let s = fresh();
    s = E.decide(s, k("a"), { kind: "remove" });
    s = E.decide(s, k("b"), { kind: "move", targets: ["x"], keepInSource: true });
    expect(E.queue(E.setFilter(s, "undecided"))).toEqual([k("c"), k("d")]);
    expect(E.queue(E.setFilter(s, "remove"))).toEqual([k("a")]);
    expect(E.queue(E.setFilter(s, "move"))).toEqual([k("b")]);
  });

  it("in 'undecided' mode a decided card leaves the queue and the next one shows", () => {
    let s = E.setFilter(fresh(), "undecided");
    s = E.decide(s, k("a"), { kind: "keep" });
    expect(E.current(s)).toBe(k("b"));
  });

  it("jump to undecided wraps around", () => {
    let s = fresh();
    s = E.decide(s, k("b"), { kind: "keep" });
    s = E.goTo(s, k("d"));
    s = E.decide(s, k("d"), { kind: "keep" });
    s = E.jumpToUndecided(s);
    expect(E.current(s)).toBe(k("a"));
  });

  it("lens mode reviews an ordered subset", () => {
    const s = E.setFilter(fresh(), "lens", { id: "x", label: "X", keys: [k("d"), k("b")] });
    expect(E.queue(s)).toEqual([k("d"), k("b")]);
    expect(E.current(s)).toBe(k("d"));
  });

  it("skip counts and moves on without deciding", () => {
    let s = E.skip(fresh(), k("a"));
    expect(s.skips[k("a")]).toBe(1);
    expect(E.current(s)).toBe(k("b"));
    expect(E.counts(s).undecided).toBe(4);
  });

  it("restart clears decisions but keeps the playlist", () => {
    const s = E.restart(E.decide(fresh(), k("a"), { kind: "keep" }));
    expect(E.counts(s).undecided).toBe(4);
    expect(s.history).toHaveLength(0);
  });

  it("ignores decisions for keys that don't exist", () => {
    const s = fresh();
    expect(E.decide(s, "nope", { kind: "keep" })).toBe(s);
  });

  it("measures pace excluding long breaks", () => {
    let s = fresh();
    const ts = [0, 2000, 4000, 6000, 8000, 10_000_000];
    const ids = ["a", "b", "c", "d"];
    ts.forEach((t, i) => (s = E.decide(s, k(ids[i % 4]), { kind: "keep" }, t)));
    const pace = E.reviewPace(s)!;
    expect(pace).toBeGreaterThan(10); // not dragged down by the huge gap
  });
});
