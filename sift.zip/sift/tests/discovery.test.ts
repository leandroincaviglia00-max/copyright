import { describe, expect, it } from "vitest";
import { buildDna } from "../src/discovery/dna";
import { emptyProfile, recordDiscovery, recordReview } from "../src/discovery/preferenceProfile";
import { rank, rankAll } from "../src/discovery/ranker";
import type { Candidate } from "../src/discovery/types";
import { computeLenses } from "../src/cleanup/smartFilters";
import * as E from "../src/review/reviewEngine";
import { toEntries } from "../src/playlists/model";
import { rawItems, track } from "./helpers";

const items = toEntries([
  ...rawItems(["1", "2", "3"]).map((r, i) => ({ ...r, item: { ...(r.item as object), artists: [{ id: "A", name: "Alpha", uri: "x" }], album: { id: `al${i}`, name: "LP", images: [], release_date: "1996" } } as never })),
  ...rawItems(["4"]).map((r) => ({ ...r, item: { ...(r.item as object), artists: [{ id: "B", name: "Beta", uri: "x" }] } as never })),
]);

const cand = (id: string, artistId: string, name: string, year = 1995, over: Partial<Candidate> = {}): Candidate => ({
  uri: `spotify:track:${id}`,
  id,
  name: id,
  artists: [{ id: artistId, name }],
  album: { name: "x", image: null, releaseDate: String(year), year },
  durationMs: 1,
  previewUrl: null,
  source: "genre",
  seed: {},
  ...over,
});

describe("Music DNA", () => {
  it("weights artists, eras and genres from legit metadata only", () => {
    const dna = buildDna({ id: "p", name: "P" }, items, { A: ["trip hop"], B: [] });
    expect(dna.artists[0]).toMatchObject({ id: "A", count: 3 });
    expect(dna.decades.find((d) => d.decade === "1990s")?.count).toBe(4);
    expect(dna.genres[0]).toEqual({ name: "trip hop", weight: 3 });
    expect(dna.genreCoverage).toBe(0.5);
  });
});

describe("ranker", () => {
  const dna = buildDna({ id: "p", name: "P" }, items, { A: ["trip hop"] });

  it("explains every point of score and never invents a percentage-of-similarity", () => {
    const r = rank(cand("x", "A", "Alpha", 1997, { genres: ["trip hop"] }), dna, emptyProfile());
    expect(r.reasons.map((x) => x.code)).toContain("artist_in_playlist");
    expect(r.reasons.map((x) => x.code)).toContain("genre_overlap");
    expect(r.tier).toBe("Close to home");
    expect(r.reasons.every((x) => !/% (match|similar)/i.test(x.text))).toBe(true);
  });

  it("adapts to explicit feedback: rejected artists sink, liked artists rise", () => {
    let p = emptyProfile();
    const z = cand("z1", "Z", "Zed");
    const y = cand("y1", "Y", "Why");
    const base = rankAll([z, y], dna, p, new Set()).map((r) => r.candidate.id);
    p = recordDiscovery(p, cand("z0", "Z", "Zed"), "reject");
    p = recordDiscovery(p, cand("z9", "Z", "Zed"), "reject");
    p = recordDiscovery(p, cand("y0", "Y", "Why"), "like");
    const after = rankAll([z, y], dna, p, new Set()).map((r) => r.candidate.id);
    expect(after[0]).toBe("y1");
    expect(base.length).toBe(2);
  });

  it("excludes songs already in the playlist or already judged", () => {
    let p = emptyProfile();
    p = recordDiscovery(p, cand("seen", "Q", "Q"), "like");
    const out = rankAll([cand("seen", "Q", "Q"), cand("inpl", "Q", "Q"), cand("new", "Q", "Q")], dna, p, new Set(["spotify:track:inpl"]));
    expect(out.map((r) => r.candidate.id)).toEqual(["new"]);
  });

  it("review removals teach the profile too", () => {
    const p = recordReview(emptyProfile(), [{ id: "A", name: "Alpha" }], "remove");
    expect(p.artists.A.removed).toBe(1);
  });
});

describe("smart cleanup lenses", () => {
  it("finds duplicates by ISRC and one-song artists; history lenses stay honest when unavailable", () => {
    const es = toEntries([
      { added_at: "2015-01-01T00:00:00Z", is_local: false, item: track("1", { external_ids: { isrc: "US1" } }) as never },
      { added_at: "2025-06-01T00:00:00Z", is_local: false, item: track("2", { external_ids: { isrc: "US1" } }) as never },
      { added_at: "2025-06-01T00:00:00Z", is_local: false, item: track("3") as never },
    ]);
    const session = E.createSession({ id: "p", name: "P", image: null, snapshotId: "s" }, es, 0);
    const lenses = computeLenses({ entries: es, session, profile: emptyProfile(), listening: null, genresByArtist: {}, now: Date.parse("2026-09-30") });
    const by = Object.fromEntries(lenses.map((l) => [l.id, l]));
    expect(by.duplicates.keys).toHaveLength(2);
    expect(by.old_adds.keys).toEqual([es[0].key]);
    expect(by.not_recent.available).toBe(false);
    expect(by.not_recent.keys).toEqual([]);
  });
});
