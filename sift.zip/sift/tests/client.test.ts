import { describe, expect, it } from "vitest";
import { SpotifyClient, parseRetryAfter } from "../src/spotify/api/client";
import { describeApiError } from "../src/spotify/api/errors";
import { mockFetch, netError, noSleep, staticAuth } from "./helpers";

describe("SpotifyClient", () => {
  it("sends bearer auth and parses JSON", async () => {
    const m = mockFetch({ "GET /v1/me": () => ({ json: { id: "u1" } }) });
    const c = new SpotifyClient({ auth: staticAuth, fetch: m.fetch, sleep: noSleep });
    expect(await c.get<{ id: string }>("/me")).toEqual({ id: "u1" });
    expect(m.calls[0].headers.Authorization).toBe("Bearer tok");
  });

  it("waits Retry-After on 429 then retries", async () => {
    const waits: number[] = [];
    const m = mockFetch({ "GET /v1/me": [() => ({ status: 429, headers: { "Retry-After": "2" }, json: { error: { status: 429, message: "slow" } } }), () => ({ json: { id: "ok" } })] });
    const c = new SpotifyClient({ auth: staticAuth, fetch: m.fetch, sleep: async (ms) => void waits.push(ms) });
    expect(await c.get("/me")).toEqual({ id: "ok" });
    expect(waits).toEqual([2000]);
  });

  it("does not retry QUOTA_EXCEEDED 429s", async () => {
    const m = mockFetch({ "GET /v1/me": () => ({ status: 429, json: { error: { status: 429, message: "Too many requests", reason: "QUOTA_EXCEEDED" } } }) });
    const c = new SpotifyClient({ auth: staticAuth, fetch: m.fetch, sleep: noSleep });
    await expect(c.get("/me")).rejects.toMatchObject({ kind: "quota", status: 429 });
    expect(m.calls.length).toBe(1);
  });

  it("gives up on a Retry-After longer than the cap", async () => {
    const m = mockFetch({ "GET /v1/me": () => ({ status: 429, headers: { "Retry-After": "600" }, json: {} }) });
    const c = new SpotifyClient({ auth: staticAuth, fetch: m.fetch, sleep: noSleep });
    await expect(c.get("/me")).rejects.toMatchObject({ kind: "rate_limited" });
  });

  it("refreshes once on 401 and replays the request", async () => {
    let refreshed = 0;
    const tokens = ["old", "new"];
    const auth = { getAccessToken: async () => tokens[refreshed], refresh: async () => void refreshed++ };
    const m = mockFetch({ "GET /v1/me": [() => ({ status: 401, json: { error: { status: 401, message: "expired" } } }), () => ({ json: { id: "u" } })] });
    const c = new SpotifyClient({ auth, fetch: m.fetch, sleep: noSleep });
    expect(await c.get("/me")).toEqual({ id: "u" });
    expect(refreshed).toBe(1);
    expect(m.calls[1].headers.Authorization).toBe("Bearer new");
  });

  it("does not loop on repeated 401s", async () => {
    const m = mockFetch({ "GET /v1/me": () => ({ status: 401, json: {} }) });
    const c = new SpotifyClient({ auth: staticAuth, fetch: m.fetch, sleep: noSleep });
    await expect(c.get("/me")).rejects.toMatchObject({ kind: "unauthorized" });
    expect(m.calls.length).toBe(2);
  });

  it("retries 5xx with backoff for GET", async () => {
    const waits: number[] = [];
    const m = mockFetch({ "GET /v1/me": [() => ({ status: 502, json: {} }), () => ({ status: 503, json: {} }), () => ({ json: { id: 1 } })] });
    const c = new SpotifyClient({ auth: staticAuth, fetch: m.fetch, sleep: async (ms) => void waits.push(ms), random: () => 1 });
    expect(await c.get("/me")).toEqual({ id: 1 });
    expect(waits).toEqual([500, 1000]);
  });

  it("never blindly retries a POST after a network error (not idempotent)", async () => {
    const m = mockFetch({ "POST /v1/playlists/p/items": netError });
    const c = new SpotifyClient({ auth: staticAuth, fetch: m.fetch, sleep: noSleep });
    await expect(c.post("/playlists/p/items", { body: { uris: [] } })).rejects.toMatchObject({ kind: "network" });
    expect(m.calls.length).toBe(1);
  });

  it("maps 403 / 404 to typed kinds with helpful copy", async () => {
    const m = mockFetch({ "GET /v1/playlists/x/items": () => ({ status: 403, json: { error: { status: 403, message: "Forbidden" } } }), "GET /v1/playlists/y": () => ({ status: 404, json: {} }) });
    const c = new SpotifyClient({ auth: staticAuth, fetch: m.fetch, sleep: noSleep });
    const e403 = (await c.get("/playlists/x/items").catch((e: unknown) => e)) as { kind: string };
    expect(e403.kind).toBe("forbidden");
    expect(describeApiError(e403 as never, "opening this playlist")).toMatch(/owners and collaborators/);
    await expect(c.get("/playlists/y")).rejects.toMatchObject({ kind: "not_found" });
  });

  it("honours AbortSignal", async () => {
    const m = mockFetch({ "GET /v1/me": () => ({ json: {} }) });
    const c = new SpotifyClient({ auth: staticAuth, fetch: m.fetch, sleep: noSleep });
    const ac = new AbortController();
    ac.abort();
    await expect(c.get("/me", { signal: ac.signal })).rejects.toMatchObject({ kind: "aborted" });
  });

  it("parses Retry-After seconds", () => {
    expect(parseRetryAfter("3")).toBe(3000);
    expect(parseRetryAfter(null)).toBe(null);
  });
});
