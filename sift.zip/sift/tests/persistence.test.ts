import { describe, expect, it } from "vitest";
import { MemoryKV } from "../src/persistence/kv";
import { exportSession, parseImport, SessionRepo } from "../src/persistence/sessionRepo";
import * as E from "../src/review/reviewEngine";
import { entries } from "./helpers";

const mk = () => E.createSession({ id: "p1", name: "Mix", image: null, snapshotId: "s1" }, entries(["a", "b", "c"]), 0);

describe("session persistence", () => {
  it("round-trips a session and finds the latest open one per playlist", async () => {
    const repo = new SessionRepo(new MemoryKV());
    let s = mk();
    s = E.decide(s, "spotify:track:a::0", { kind: "remove" }, 5);
    await repo.save(s);
    const back = await repo.latestFor("p1");
    expect(back?.decisions["spotify:track:a::0"].kind).toBe("remove");
    expect(back?.history).toHaveLength(1);
    const list = await repo.list();
    expect(list[0]).toMatchObject({ playlistId: "p1", decided: 1, total: 3 });
  });

  it("does not resume sessions that were fully applied", async () => {
    const repo = new SessionRepo(new MemoryKV());
    await repo.save({ ...mk(), status: "applied" });
    expect(await repo.latestFor("p1")).toBe(undefined);
  });

  it("debounced writer coalesces rapid saves and flushes on demand", async () => {
    const kv = new MemoryKV();
    const repo = new SessionRepo(kv);
    const w = repo.writer(10_000);
    let s = mk();
    for (const id of ["a", "b", "c"]) {
      s = E.decide(s, `spotify:track:${id}::0`, { kind: "keep" });
      w(s);
    }
    expect(await repo.load(s.id)).toBe(undefined);
    w.flush();
    await new Promise((r) => setTimeout(r, 0));
    expect(Object.keys((await repo.load(s.id))!.decisions)).toHaveLength(3);
  });

  it("persists and clears apply journals", async () => {
    const repo = new SessionRepo(new MemoryKV());
    await repo.saveJournal({ playlistId: "p1", steps: [] } as never);
    expect(await repo.loadJournal("p1")).toBeTruthy();
    await repo.clearJournal("p1");
    expect(await repo.loadJournal("p1")).toBe(undefined);
  });

  it("exports and re-imports a session file", () => {
    const s = E.decide(mk(), "spotify:track:b::0", { kind: "keep" });
    const text = JSON.stringify(exportSession(s));
    const back = parseImport(text);
    expect(back.decisions["spotify:track:b::0"].kind).toBe("keep");
  });

  it("rejects foreign or corrupt import files", () => {
    expect(() => parseImport("{not json")).toThrow();
    expect(() => parseImport(JSON.stringify({ app: "other" }))).toThrow();
    const s = mk();
    const bad = exportSession({ ...s, decisions: { ghost: { kind: "keep", at: 0 } } });
    expect(() => parseImport(JSON.stringify(bad))).toThrow();
  });
});
