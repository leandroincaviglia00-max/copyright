import { describe, expect, it } from "vitest";
import { base64url, challengeFromVerifier, randomString } from "../src/spotify/auth/pkce";

describe("PKCE", () => {
  it("matches the RFC 7636 appendix B test vector", async () => {
    expect(await challengeFromVerifier("dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk")).toBe("E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM");
  });
  it("generates verifiers from the unreserved charset and valid length", () => {
    const v = randomString(64);
    expect(v).toHaveLength(64);
    expect(/^[A-Za-z0-9\-._~]+$/.test(v)).toBe(true);
    expect(() => randomString(10)).toThrow();
  });
  it("base64url has no padding or unsafe chars", () => {
    expect(base64url(new Uint8Array([251, 255, 254]))).toBe("-__-");
  });
});
