import { describe, expect, it } from "vitest";
import { readConfig } from "../src/config/env";

describe("config", () => {
  it("requires client id + redirect uri and rejects localhost", () => {
    expect(() => readConfig({})).toThrow(/VITE_SPOTIFY_CLIENT_ID/);
    expect(() => readConfig({ VITE_SPOTIFY_CLIENT_ID: "x", VITE_SPOTIFY_REDIRECT_URI: "http://localhost:5173/callback" })).toThrow(/127\.0\.0\.1/);
    expect(readConfig({ VITE_SPOTIFY_CLIENT_ID: "x", VITE_SPOTIFY_REDIRECT_URI: "http://127.0.0.1:5173/callback" }).clientId).toBe("x");
  });
});
