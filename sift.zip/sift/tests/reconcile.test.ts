import { describe, expect, it } from "vitest";
import { reconcile } from "../src/review/reconcile";
import * as E from "../src/review/reviewEngine";
import { entries } from "./helpers";

describe("reconcile with external changes", () => {
  it("keeps decisions for surviving songs, drops the rest, and reports what changed", () => {
    let s = E.createSession({ id: "p", name: "P", image: null, snapshotId: "s1" }, entries(["a", "b", "c"]), 0);
    s = E.decide(s, "spotify:track:a::0", { kind: "keep" });
    s = E.decide(s, "spotify:track:b::0", { kind: "remove" });
    // externally: b deleted, d added, order shuffled
    const { session, report } = reconcile(s, entries(["c", "d", "a"]), "s2");
    expect(session.snapshotId).toBe("s2");
    expect(session.order).toEqual(["spotify:track:c::0", "spotify:track:d::0", "spotify:track:a::0"]);
    expect(session.decisions["spotify:track:a::0"].kind).toBe("keep");
    expect(session.decisions["spotify:track:b::0"]).toBe(undefined);
    expect(report.addedExternally.map((e) => e.name)).toEqual(["Song d"]);
    expect(report.removedExternally.map((e) => e.name)).toEqual(["Song b"]);
    expect(report.droppedDecisions).toHaveLength(1);
    expect(session.history.every((h) => h.key !== "spotify:track:b::0")).toBe(true);
  });

  it("reports no change for an identical copy", () => {
    const s = E.createSession({ id: "p", name: "P", image: null, snapshotId: "s1" }, entries(["a"]), 0);
    expect(reconcile(s, entries(["a"]), "s1").report.changed).toBe(false);
  });
});
