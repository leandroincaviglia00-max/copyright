import { describe, expect, it } from "vitest";
import { planApply, planRestore, LATER_REF, type ApplyJournal } from "../src/review/applyPlanner";
import { runJournal } from "../src/review/applyExecutor";
import * as E from "../src/review/reviewEngine";
import { SpotifyClient } from "../src/spotify/api/client";
import { SpotifyApi } from "../src/spotify/api/endpoints";
import { entries, mockFetch, netError, noSleep, staticAuth } from "./helpers";

const P = { id: "src", name: "Src", image: null, snapshotId: "s0" };
const k = (id: string, n = 0) => `spotify:track:${id}::${n}`;
const ctx = { playlistNames: { dest: "Dest" } };

function session(ids: string[]) {
  return E.createSession(P, entries(ids), 0);
}

describe("apply planner", () => {
  it("orders steps: create → add → remove, and chunks at 100", () => {
    const ids = Array.from({ length: 250 }, (_, i) => `t${i}`);
    let s = session(ids);
    ids.forEach((id, i) => (s = E.decide(s, k(id), i < 230 ? { kind: "remove" } : { kind: "move", targets: [LATER_REF], keepInSource: false })));
    const { journal, summary } = planApply(s, ctx);
    const types = journal.steps.map((x) => x.type);
    expect(types).toEqual(["create", "add", "remove", "remove", "remove"]);
    expect(journal.steps[2].uris).toHaveLength(100);
    expect(journal.steps[4].uris).toHaveLength(50);
    expect(summary.removeSongs).toBe(250);
    expect(journal.steps[0].create?.public).toBe(false); // temp sorting playlists default private
  });

  it("copies without removing when keepInSource is true; ignores moves to the source itself", () => {
    let s = session(["a", "b"]);
    s = E.decide(s, k("a"), { kind: "move", targets: ["dest", "src"], keepInSource: true });
    const { journal } = planApply(s, ctx);
    expect(journal.steps.map((x) => [x.type, x.target])).toEqual([["add", "dest"]]);
  });

  it("uses pending new playlists with the chosen visibility", () => {
    let s = session(["a"]);
    s = { ...s, pendingPlaylists: [{ tempId: "new:1", name: "Best of", description: "", public: true }] };
    s = E.decide(s, k("a"), { kind: "move", targets: ["new:1"], keepInSource: false });
    const { journal } = planApply(s, ctx);
    expect(journal.steps[0]).toMatchObject({ type: "create", target: "new:1", create: { name: "Best of", public: true } });
  });

  it("handles partial duplicate removal by re-inserting kept copies at their final index", () => {
    // order: a, b, a(dup), c  → remove the 2nd "a" only
    let s = session(["a", "b", "a", "c"]);
    s = E.decide(s, k("a", 1), { kind: "remove" });
    const { journal } = planApply(s, ctx);
    expect(journal.steps.map((x) => x.type)).toEqual(["remove", "readd"]);
    expect(journal.steps[1]).toMatchObject({ uris: ["spotify:track:a"], position: 0 });
  });

  it("skips local files with a warning", () => {
    const s0 = session(["a"]);
    const s = { ...s0, entries: { ...s0.entries, [k("a")]: { ...s0.entries[k("a")], uri: "spotify:local:foo" } } };
    const { journal, summary } = planApply(E.decide(s, k("a"), { kind: "remove" }), ctx);
    expect(journal.steps).toHaveLength(0);
    expect(summary.warnings[0]).toMatch(/local/);
  });

  it("restore plan re-adds removed songs in original order", () => {
    let s = session(["a", "b", "c"]);
    s = E.decide(s, k("c"), { kind: "remove" });
    s = E.goTo(s, k("a"));
    s = E.decide(s, k("a"), { kind: "remove" });
    const { journal } = planApply(s, ctx);
    const r = planRestore(journal);
    expect(r.steps).toHaveLength(1);
    expect(r.steps[0]).toMatchObject({ type: "add", target: "src", uris: ["spotify:track:a", "spotify:track:c"] });
  });
});

function harness(routes: Parameters<typeof mockFetch>[0], existing: Record<string, string[]> = {}) {
  const m = mockFetch(routes);
  const api = new SpotifyApi(new SpotifyClient({ auth: staticAuth, fetch: m.fetch, sleep: noSleep, maxRetries: 0 }));
  const saved: ApplyJournal[] = [];
  const deps = {
    api,
    playlists: { uris: async (id: string) => new Set(existing[id] ?? []) },
    persist: (j: ApplyJournal) => void saved.push(structuredClone(j)),
  };
  return { m, deps, saved };
}

const metaSnap = (snap: string) => () => ({ json: { id: "src", snapshot_id: snap } });

describe("apply executor", () => {
  it("runs a full plan, threading snapshot ids through removals", async () => {
    let s = session(["a", "b", "c"]);
    s = E.decide(s, k("a"), { kind: "move", targets: ["dest"], keepInSource: false });
    s = E.decide(s, k("b"), { kind: "remove" });
    const { journal } = planApply(s, ctx);
    const { m, deps, saved } = harness({
      "POST /v1/playlists/dest/items": () => ({ status: 201, json: { snapshot_id: "d1" } }),
      "GET /v1/playlists/src": metaSnap("s0"),
      "DELETE /v1/playlists/src/items": () => ({ json: { snapshot_id: "s1" } }),
    });
    const res = await runJournal(journal, deps);
    expect(res.status).toBe("done");
    const order = m.calls.map((c) => `${c.method} ${c.url.pathname}`);
    expect(order).toEqual(["POST /v1/playlists/dest/items", "GET /v1/playlists/src", "DELETE /v1/playlists/src/items"]);
    expect(m.calls[2].body).toMatchObject({ snapshot_id: "s0" });
    expect(saved[saved.length - 1].finishedAt).toBeTruthy();
    expect(saved[saved.length - 1].expectedSnapshot).toBe("s1");
  });

  it("skips songs already in the destination", async () => {
    let s = session(["a", "b"]);
    s = E.decide(s, k("a"), { kind: "move", targets: ["dest"], keepInSource: true });
    s = E.decide(s, k("b"), { kind: "move", targets: ["dest"], keepInSource: true });
    const { journal } = planApply(s, ctx);
    const { m, deps } = harness({ "POST /v1/playlists/dest/items": () => ({ status: 201, json: { snapshot_id: "d" } }) }, { dest: ["spotify:track:a"] });
    await runJournal(journal, deps);
    expect(m.calls[0].body).toEqual({ uris: ["spotify:track:b"] });
  });

  it("stops with a conflict before removing anything if the playlist changed externally", async () => {
    let s = session(["a"]);
    s = E.decide(s, k("a"), { kind: "remove" });
    const { journal } = planApply(s, ctx);
    const { m, deps } = harness({ "GET /v1/playlists/src": metaSnap("someone-else") });
    const res = await runJournal(journal, deps);
    expect(res.status).toBe("conflict");
    expect(m.calls.some((c) => c.method === "DELETE")).toBe(false);
    if (res.status === "conflict") {
      // user explicitly accepts the new version → proceeds
      const { deps: d2, m: m2 } = harness({ "GET /v1/playlists/src": metaSnap("someone-else"), "DELETE /v1/playlists/src/items": () => ({ json: { snapshot_id: "x" } }) });
      const again = await runJournal(res.journal, d2, { acceptSnapshot: res.remoteSnapshot });
      expect(again.status).toBe("done");
      expect(m2.calls.some((c) => c.method === "DELETE")).toBe(true);
    }
  });

  it("pauses on 403 and resumes from the failed step without redoing finished ones", async () => {
    let s = session(["a", "b"]);
    s = E.decide(s, k("a"), { kind: "move", targets: ["dest"], keepInSource: false });
    const { journal } = planApply(s, ctx);
    const first = harness({
      "POST /v1/playlists/dest/items": () => ({ status: 201, json: { snapshot_id: "d" } }),
      "GET /v1/playlists/src": metaSnap("s0"),
      "DELETE /v1/playlists/src/items": () => ({ status: 403, json: { error: { status: 403, message: "Forbidden" } } }),
    });
    const r1 = await runJournal(journal, first.deps);
    expect(r1.status).toBe("paused");
    if (r1.status !== "paused") return;
    expect(r1.journal.steps.map((x) => x.status)).toEqual(["done", "failed"]);
    const second = harness({ "GET /v1/playlists/src": metaSnap("s0"), "DELETE /v1/playlists/src/items": () => ({ json: { snapshot_id: "s1" } }) });
    const r2 = await runJournal(r1.journal, second.deps);
    expect(r2.status).toBe("done");
    expect(second.m.calls.some((c) => c.method === "POST")).toBe(false);
  });

  it("marks a POST that failed on the network as uncertain and verifies before retrying", async () => {
    let s = session(["a", "b"]);
    s = E.decide(s, k("a"), { kind: "move", targets: ["dest"], keepInSource: true });
    s = E.decide(s, k("b"), { kind: "move", targets: ["dest"], keepInSource: true });
    const { journal } = planApply(s, ctx);
    const r1 = await runJournal(journal, harness({ "POST /v1/playlists/dest/items": netError }).deps, { skipExisting: false });
    expect(r1.status).toBe("paused");
    expect(r1.journal.steps[0].status).toBe("uncertain");
    // the POST actually landed for "a"
    const h2 = harness({ "POST /v1/playlists/dest/items": () => ({ status: 201, json: { snapshot_id: "d" } }) }, { dest: ["spotify:track:a"] });
    const r2 = await runJournal(r1.journal, h2.deps, { skipExisting: false });
    expect(r2.status).toBe("done");
    expect(h2.m.calls[0].body).toEqual({ uris: ["spotify:track:b"] });
  });

  it("resolves created playlists before adding to them", async () => {
    let s = session(["a"]);
    s = E.decide(s, k("a"), { kind: "move", targets: [LATER_REF], keepInSource: true });
    const { journal } = planApply(s, ctx);
    const created: string[] = [];
    const h = harness({ "POST /v1/me/playlists": () => ({ status: 201, json: { id: "later123" } }), "POST /v1/playlists/later123/items": () => ({ status: 201, json: { snapshot_id: "l" } }) });
    const r = await runJournal(journal, { ...h.deps, onCreated: (ref, id) => created.push(`${ref}=${id}`) });
    expect(r.status).toBe("done");
    expect(created).toEqual(["later=later123"]);
  });
});
