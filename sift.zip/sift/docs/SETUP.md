# Sift · setup guide

## 1. Requirements
- Node.js ≥ 20.11 and npm
- A Spotify account with **Premium**. Since Feb 2026, Development Mode apps only work while the app *owner* has Premium, and full-track in-browser playback needs Premium too.

## 2. Create the Spotify app
1. Go to https://developer.spotify.com/dashboard → **Create app**.
2. **Redirect URI**: `http://127.0.0.1:5173/callback` (Spotify rejects `localhost`; loopback IP is allowed over http. Deployed builds need `https://…/callback`).
3. APIs used: **Web API** and **Web Playback SDK**.
4. **User Management**: add every Spotify account that will sign in (Dev Mode allows up to 5 users). Accounts that aren't listed get 403s.
5. Copy the **Client ID**. You do *not* need the Client Secret. Sift uses Authorization Code + PKCE, so no secret exists in this project.

## 3. Configure
```bash
cp .env.example .env.local
```
| Variable | Required | Meaning |
|---|---|---|
| `VITE_SPOTIFY_CLIENT_ID` | yes | Public Client ID from the dashboard |
| `VITE_SPOTIFY_REDIRECT_URI` | yes | Must exactly match the dashboard entry |
| `VITE_PLAYER_NAME` | no | Name of the in-browser Spotify Connect device |

## 4. Run
```bash
npm install
npm run dev        # http://127.0.0.1:5173 (open this exact host, not localhost)
npm test           # vitest: API layer, auth, engine, persistence, batch sync, discovery
npm run typecheck
npm run build && npm run preview
```

## 5. Branding (required by Spotify's design guidelines)
Download the official Spotify icon from https://developer.spotify.com/documentation/design and save it as `public/spotify-icon.svg`. Until then, "Open in Spotify" links show text only.

## 6. Deploying
Any static host works (Vercel, Netlify, Cloudflare Pages). Configure SPA fallback (all paths → `index.html`), add the HTTPS `/callback` URL to the dashboard and to `VITE_SPOTIFY_REDIRECT_URI`, and rebuild.

## Troubleshooting
| Symptom | Cause / fix |
|---|---|
| `INVALID_CLIENT: Invalid redirect URI` | Redirect URI mismatch; check scheme, host (127.0.0.1), port, path |
| 403 on every call | Your account isn't in the app's User Management list |
| Playlist shows **Locked** | Since Feb 2026 only owners/collaborators can read a playlist's items (Spotify restriction, no workaround) |
| "NO AUDIO" badge | No preview, and Premium playback isn't connected. Tap the badge to pick a device, or use "Spotify" to open the song |
| "Needs Spotify Premium" | The Web Playback SDK reported `account_error` |
| Quota banner | Dev Mode quota exceeded (`QUOTA_EXCEEDED`); decisions are safe locally, retry later |
