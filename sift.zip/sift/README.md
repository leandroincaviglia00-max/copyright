# SIFT

Swipe through your real Spotify playlists one sleeve at a time: **→ keep, ← cut, ↑ file**. Then send the whole batch to Spotify safely, and dig for new music seeded by any playlist.

**Setup:** see [docs/SETUP.md](docs/SETUP.md). Short version: `cp .env.example .env.local`, add your Client ID, `npm i && npm run dev`, open http://127.0.0.1:5173.

## What it does
- **Real Spotify OAuth** (Authorization Code + PKCE, no client secret), single-flight token refresh, rotation-safe refresh tokens, CSRF `state`, clean expiry recovery, logout.
- **Library:** search/filter, cover, count, owner, public/private/collab, locked playlists explained.
- **Swipe review:** pointer physics, rotation, velocity flings, rubber-stamp feedback (kept off the artwork), keyboard shortcuts, undo/redo, skip, jump-to-undecided, filters (undecided/kept/cut/filed), restart.
- **Move sheet:** searchable, multi-destination, copy-vs-move, "Save for later" (private *Sift · Later*), new playlist (name/description/visibility, private by default, created only at apply time).
- **Batch apply:** creates → **adds first** → snapshot check → removes (100/request, `snapshot_id` threaded) → re-inserts kept duplicates. Journaled after every step, so it resumes after crash/refresh/401/403/429/network errors. Uncertain POSTs get verified before retry. External edits pause with a conflict screen instead of overwriting. "Put removed songs back" restore.
- **Live sync:** re-reads from Spotify after apply, "Synced HH:MM" badge, manual refresh, snapshot polling + on-focus checks, reconcile report of external adds/removals.
- **Playback:** Web Playback SDK (Premium, full tracks, device shown, seek, reconnect on vanished device, autoplay-policy aware) → Spotify Connect devices → 30 s `preview_url` when Spotify provides one → Open in Spotify. The mode badge always shows which one you're hearing. Audio is never downloaded or cached.
- **Discover:** Music DNA (artists, recurring albums, eras, genre tags where Spotify still returns them, genre clusters). Candidates come from artist deep cuts, collaboration bridges, genre/era search, and optional top tracks. Transparent rule-based ranking with visible reasons and tiers, **no fake percentages**. Learns from yes/no/later/skip.
- **Smart lenses:** duplicates (ISRC or title+artist), one-song artists, added 2+ yrs ago, "like ones you cut", skipped in Sift, unavailable/local. With opt-in history scopes, also "not in recent plays" and "artists outside your top".
- **Stats**, **session history**, JSON **export/import**, IndexedDB persistence (survives refresh).

## API compliance (verified against Spotify docs, Feb/Mar/Jul 2026 changelogs)
- Uses `GET/POST/DELETE /playlists/{id}/items` (never `/tracks`), `{ items: [{uri}] }` DELETE body, renamed `item` / `items.total` fields.
- Uses `POST /me/playlists`. Search limit ≤ 10. Single-entity `/artists/{id}` fetches (batch endpoints removed), cached for 7 days.
- Doesn't use Recommendations, Related Artists, Audio Features/Analysis, top-tracks-by-artist, browse, or `/users/{id}`. Handles removed fields (popularity, markets, product…). Treats deprecated `genres` as optional.
- Scopes: playlist read/modify (private, public, collaborative), playback state/modify, `streaming` + `user-read-email` + `user-read-private` (required by the SDK). `user-read-recently-played` + `user-top-read` are requested only when you tap **Enable**.
- No ML training on Spotify content, no external AI calls. Artwork is never cropped or overlaid (the ambient glow is a sampled colour behind the card).

## Architecture
```
src/config        env validation
src/spotify/auth  PKCE, token store, AuthService
src/spotify/api   typed client (retry, 429/Retry-After, backoff, 401 refresh, abort), endpoints, errors
src/playlists     model mapping, paginated + snapshot-cached loading
src/playback      SDK loader, PlaybackController (full / remote / preview / none)
src/review        pure review engine, reconcile, apply planner + executor
src/discovery     DNA, preference profile, ranker, pluggable MetadataSource, engine
src/cleanup       smart lenses
src/persistence   IndexedDB KV, session repo, export/import
src/state         zustand stores, router, composition root
src/ui            screens, components, gesture + tone hooks, styles
tests/            73 vitest tests
```
Known limits: Spotify only exposes the last 50 plays and top items, so "listening" lenses say exactly that. Local files can't be edited via the API and are skipped with a warning. Liked Songs isn't a playlist and isn't included.
